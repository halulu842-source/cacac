# Current state — what is staged on the machine right now

Delta since `ISSUE_FOR_REVIEW.md`. Two corrections were exchanged and are
reflected here; read this before re-auditing.

## Corrections already settled

- **The trampoline fall-through is rejection-only.** `vmlaunch` on success never
  returns to the next instruction — the CPU is already at `GUEST_RIP`. So the
  `mov rax,1; ret` fall-through is reached only on rejection, and the existing
  "error path is unreachable" framing was wrong: the path is fine, it just never
  gets there because the CPU stops earlier. An explicit `jz` is present for
  clarity but was never the bug.
- **`VMCALL` needs no control bit** — it is in the SDM 25.1.2 *unconditional*
  exit list (reason 18). Primary proc-based **bit 15 is `CR3_LOAD_EXITING`
  (0x8000)**. Enabling it (as one earlier proposal suggested) would make every
  guest CR3 load exit with reason **28 (`CR_ACCESS`, not 27 — 27 is `VMON`)**.
  Primary controls are set to **0** desired.
- **A CR3 walker was proposed but never implemented.** No LA57 / PCID / PS-aware
  page-table walker exists in this tree, so it cannot be the source of a spin.

## What the machine actually does

The display shows a **frozen POST splash**, not a cycling one. POST does not
re-run, therefore the CPU is *spinning*, not triple-faulting. That rules out:
reset, `#GP`/`#UD` reaching the catcher (those log and stop), and a rejected
launch (that returns and writes `0xF1` + `instr_error`).

## What was added to isolate it

**1. Console reporting, because a trace file cannot debug a hang.** The trace is
written through the ESP via `SimpleFileSystem`, so everything after a freeze is
lost and every failure mode looks identical. `hv_say()` /
`hv_say_hex()` write to `ConOut` instead — emitted before the freeze, visible
afterwards. `hv_dump_vmcs()` now prints the launch state to the screen
immediately before `vmlaunch`, and `hv_prepare_guest()` prints a bracket line, so
the freeze localises to one function.

**2. Guest-magic probe.** The guest's **first** instruction writes
`0x600DF00D600DF00D` into a shared report page, then `VMCALL`s. It touches no
stack, makes no call, and depends on no register — so the magic landing proves
VM entry succeeded even if the guest dies on the next instruction. This is the
one fact the project has never established; the old `05d guest resumed` line was
written by C code after `hv_enter()` returned, so it proved nothing about the
guest.

**3. One-shot teardown exit.** The first VM exit records reason / qualification /
guest RIP into the report page, then `VMXOFF`s and returns to the host. It does
**not** resume the guest, so a broken resume path cannot turn the probe into a
hang, and the report survives to be published to the trace by the host.

**4. Minimal VMCS in probe mode** (`g_stage_a = 1`, in `hv_asm.asm`'s `.data`):
secondary controls 0 (so **no EPT, no VPID, no MSR bitmaps**), exception bitmap
0. The probe guest writes one page and `VMCALL`s; it needs none of it, and each
was one more field that could fail. Without EPT the guest's own page tables
produce host-physical addresses directly, valid here because the firmware runs
identity-mapped.

## What is staged

`HvFnStage3.efi`, 33,792 bytes, on the ESP with `arm.txt=1`, `boot.txt=0`, no
`probe.txt`, firmware entry first. Watchdog armed for 30 s immediately before the
launch.

## What the screen shows, in order

```
HvFn: guest prepared                     <- end of hv_prepare_guest
HvFn: launch state ------------
linkptr / cs.ar / cs.base / ss.ar / tr.sel / tr.ar / tr.limit / tr.base
g.efer / h.efer / g.cr0 / g.cr4 / h.cr0 / h.cr4 / h.rsp / h.rip / guestrip
entryctl / exitctl / proc / proc2 / pin
launch #: 0x1
HvFn: VMLAUNCHING NOW >>>>
```

then either nothing, or:

```
probe magic: 0x600df00d600df00d
probe ran: 0x1
probe exited: 0x1
probe reason: 0x12                       <- 18 = VMCALL
HvFn: probe launch returned - VMX is off, booting on
```

## Requested checklist, now readable off the display

| field | expected |
|---|---|
| `linkptr` | `0xffffffffffffffff` |
| `cs.ar` | `0x209b` (L=1) |
| `cs.base` | `0x0` |
| `tr.ar` | `0x8b` (busy 64-bit TSS) |
| `tr.limit` | `0x67` |
| `g.efer` / `h.efer` | both `0xd00` |
| `h.cr4` | VMXE (bit 13) set |
| `h.rsp` / `h.rip` | canonical |
| `entryctl` | bit 9 (IA-32e guest); bit 15 (load EFER) **not** set in this build — `GUEST_EFER` is therefore not loaded or checked |
| `proc2` | `0x0` in probe mode |

## Still outstanding from the review

Not yet implemented: the APIC-timer interrupt watchdog pointed at a spare IDT
vector (to separate host spin from in-entry stop), the CMOS byte at 0x4F as a
reset counter, and the staged bisect (stages 2–5: firmware host selectors with
no `lgdt`/`ltr`, then `lgdt`, then `ltr`, then private guest GDT/IDT).
