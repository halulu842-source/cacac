# HvFn — open issue: `VMLAUNCH` never returns

## Summary

A bare-metal Intel VT-x hypervisor is loaded from a **UEFI firmware boot entry**
(before `bootmgfw.efi`) and is meant to boot Windows inside the VM. Everything up
to and including full VMCS programming works on the target machine. `VMLAUNCH`
**never returns**: no VM exit is ever taken, and no VM-instruction-error code is
produced. The CPU stops inside VM entry with no catchable fault.

## Environment

- Gigabyte H610M S2H V3 DDR4, AMI BIOS F8 (2025-02-12), Intel Core i3-14100F
- Windows 11 build 26100
- Secure Boot **off**; VBS / Hyper-V **off** (`hypervisorlaunchtype off`,
  `HypervisorPresent = False`, DeviceGuard status 0)
- Payload is a freestanding PE32+ x64 EFI application (subsystem 10), no EDK2,
  no imports, self-relocated into `EfiRuntimeServicesCode` pages
- It runs before Windows Boot Manager, so it owns VMX from the first instruction
  of the OS boot

## What is confirmed working

Confirmed from the payload's own trace file written to the ESP:

```
05a1 cpuid ok: 32             CPUID.1:ECX.VMX present
05a2 feature_control: 5       IA32_FEATURE_CONTROL locked, VMX outside SMX enabled
05b0a vmx revision: 19        IA32_VMX_BASIC readable, VMCS rev 0x13
05b0v alt try_vmxon rc: 0     VMXON succeeds
05a vmxon ok                  real VMXON ok
05b vmcs ok                   VMCLEAR + VMPTRLD + entire VMCS programming ok
```

- `CR0 = 0x80010033` (PG|NE|WP|ET|MP|PE), `CR4 = 0x42668` (VMXE|OSXSAVE|MCE|PGE|PAE…), `EFER = 0xD00` (LME|LMA|NXE)
- MTRRs enabled, default type WB, 10 variable ranges
- **The pre-VMX fault catcher works**: a deliberate `ud2` placed behind the same
  IDT is caught (`rc = 3`, vector 6 recorded)
- A **dry-run build that programs the VMCS but skips `VMLAUNCH`** boots Windows
  normally and reliably — so nothing before the launch is at fault

## The failure

The trace always ends here:

```
05c prelaunch          <-- written immediately before hv_enter()
   (nothing further)
```

Two specific things make it unusual:

1. **A rejected VM entry is supposed to return with a reason.** The trampoline
   handles that: if `VMLAUNCH` does not launch it executes `mov rax,1; ret`, and
   the C side then reads `VMCS_VMEXIT_INSTRUCTION_ERROR` and logs it as
   `06b vmlaunch err: E`. **That log line has never once appeared**, so the
   documented error path is unreachable and the instruction-error field — the
   only diagnostic Intel provides for this — cannot be read.

2. **No VM exit is taken either.** A marker at the very top of the VM-exit
   handler (`05d1 first vm exit, reason N`) has never fired. So this is not
   "entry succeeded and the exit handler died" — **nothing downstream of
   `VMLAUNCH` has executed in any build.**

Conclusion so far: the processor stops during VM entry itself, without raising a
fault the guest IDT can catch.

## It is not a hardware limit

`VMXON` succeeds, the VMCS is programmable, and **Hyper-V has run on this same
machine** (VBS was active before it was disabled). The CPU therefore enters VMX
and launches guests correctly when Microsoft's loader does it.

## What has already been ruled out / fixed

Eleven separate defects were found and fixed on the way here, each of which had
been masking the next:

| # | defect | effect |
|---|---|---|
| 1 | `vmxon [rcx]` — region address passed directly | `VMXON` takes a *memory operand holding* the physical address, so it read the region's first qword (the VMCS revision, `0x13`) and operated at physical `0x13` |
| 2 | `CR0.NE = 0` (firmware leaves it clear) | `VMXON` requires `NE`; with it clear the instruction raised a machine check |
| 3 | no IDT of ours loaded before `VMXON` | that machine check went to the firmware's handler and was unrecoverable |
| 4 | `#MC` (vector 18) not in the catcher | the machine check stayed invisible |
| 5 | MTRR scan read past `IA32_MTRRCAP.VCNT` | `#GP`, then the catcher's resume stub unwound a frame it did not own |
| 6 | catcher pointed **all 256** vectors at the `#GP` stub | an interrupt frame carries no error code; first timer tick misread its `IRETQ` frame |
| 7 | `CR4.VMXE` cleared before the real `VMXON` | `#UD` |
| 8 | `INVLPG` keyed to exit reason **28** | it is **14** (28 is `CR_ACCESS`) — enabled intercept with no handler |
| 9 | `XSAVES`/`XRSTORS` trapping enabled (`proc2` bit 20) with no `case 63`/`64` | trap loop |
| 10 | host TR descriptor written as type **9** (available 64-bit TSS) | changed to type **11** (`0x8B`, busy) — host state is validated at VM entry |
| 11 | `TSS.RSP0` left zero | latent trap |

Item 10 is the most recent change and is not yet tested. It is grounded in a
working reference implementation (Sina Karvandi's *Hypervisor-From-Scratch*),
which obtains a busy descriptor for free by reusing the live TR selector —
because `LTR` sets the busy bit in the GDT. This project builds a private GDT
(necessarily: the firmware's GDT lives in boot-services memory the OS reclaims),
so the bit has to be set by hand.

## The question

Given that:

- `VMXON`, `VMCLEAR`, `VMPTRLD` and VMCS programming all succeed,
- a rejected VM entry would normally return an instruction-error code but here it
  never returns,
- and no VM exit is ever taken,

**what else in the VMCS host/guest state can cause the processor to stop during
VM entry rather than fail with `VMfailValid` / `VMfailInvalid` and return?**

More specifically, is there a known condition under which `VMLAUNCH` hangs or
shuts the processor down *instead of* reporting a VM-instruction error — and if
so, is there any way to recover the instruction-error field or otherwise observe
which check failed?
