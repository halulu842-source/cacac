# HvFn — Stage-3 hypervisor ESP

A UEFI-resident Intel VT-x hypervisor that exposes a memory-read hypercall to a
ring-3 overlay. The game is never opened with a handle, no driver is installed,
and no process is injected: reads are performed by the hypervisor, in VMX root,
using the game's own CR3.

The starting point was `HvFn_package.tar.gz` (a launcher with a stubbed `ReadFn`,
a 38-line Stage-3 sketch and a work log listing seven blockers). This tree
finishes those blockers and adds the machinery they needed.

---

## 1. How it works

```
 firmware POST
      |
      v
 HvFnStage3.efi            <- boot entry added ahead of Windows Boot Manager
   - copies itself into EfiRuntimeServicesCode pages (survives ExitBootServices)
   - applies its own base relocations
   - VMXON + VMCLEAR/VMPTRLD + VMLAUNCH on the BSP
      |                       guest = everything after this point
      v
 bootmgfw.efi -> Windows
      |
      v
 HvFn.exe (ring 3, pinned to CPU 0)
   vmcall  ->  #UD  ->  VM exit  ->  hypervisor reads with the game's CR3
                                    writes the result into the caller's buffer
                                    advances RIP past the 3-byte instruction
```

**Why `#UD`.** `VMCALL` is a VMX instruction; executed outside VMX root it
raises `#UD`. Stage-3 puts `#UD` in the VM-exception bitmap, so the fault traps
into the hypervisor, which recognises the instruction (`0F 01 C1`), the magic in
`RAX` and the request pointer in `RCX`, performs the work and skips the
instruction. Other `#UD`s are re-injected unchanged.

**Files**

| Path | Purpose |
|---|---|
| `src/common/hvfn_protocol.h` | hypercall ABI shared by both halves |
| `src/stage3/hv_core.c` | VMX/EPT bring-up, VMCS programming, exit handler, hypercalls |
| `src/stage3/hv_mem.c` | physical access + 4-level guest page-table walker |
| `src/stage3/hv_resolve.c` | finds the game: KPCR → EPROCESS → process list → PEB |
| `src/stage3/hv_asm.asm` | VMX instruction wrappers, launch trampoline, exit stub |
| `src/stage3/efi_main.c` | UEFI entry, self-relocation, boot guard, chain-load |
| `src/stage3/vmcs_fields.h` | VMCS field encodings (generated, see `tools/gen_vmcs.py`) |
| `src/launcher/main.cpp` | overlay, ESP rendering, UI |
| `src/launcher/hvclient.h` | hypercall client (`vmcall` stub, SEH-guarded) |
| `src/launcher/offsets.h` | **every build-dependent number lives here** |

---

## 2. Build

Requires Visual Studio (any recent version) with the C++ x64 toolset. No EDK2,
no Windows SDK headers, no third-party libraries.

```powershell
powershell -ExecutionPolicy Bypass -File build\build_stage3.ps1     # -> build\out\HvFnStage3.efi
powershell -ExecutionPolicy Bypass -File build\build_launcher.ps1   # -> build\out\HvFn.exe
```

`build_stage3.ps1` compiles freestanding C (`/GS- /GR- /Zl`, no CRT), assembles
the VMX stubs with `ml64`, links with `/NODEFAULTLIB` and then re-tags the PE
optional-header subsystem to 10 (EFI application) with `build/patch_pei.py`,
because `link.exe` cannot emit EFI subsystems.

`tools/gen_vmcs.py` regenerates `vmcs_fields.h` from the encoding table — only
needed if you want to double-check the constants.

---

## 3. Deploy

`HvFn.exe` is self-installing: the Stage-3 payload is embedded in it as a
resource, so a single elevated run writes the `.efi` to the ESP and registers
the firmware boot entry. There is no VC++ redistributable, no script, no EDK2
output to copy around.

```
HvFn.exe              GUI: Arm + Reboot / Attach / Overlay / Install / Uninstall
HvFn.exe --arm        stage the payload and reboot into it (one click path)
HvFn.exe --install    write payload + boot entry, without rebooting
HvFn.exe --uninstall  delete boot entry + payload
HvFn.exe --reset      clear the failed-boot counter
```

`install.ps1` does the same from PowerShell if you prefer scripts
(`-Status` / `-Install` / `-Uninstall` / `-Reset`); it is the fallback when the
executable is not available.

> The boot configuration is only modified by an explicit Install.

`Install` mounts the ESP with `mountvol S: /S`, copies
`\EFI\HvFn\HvFnStage3.efi`, writes `arm.txt` and `boot.txt`, and adds a firmware
boot entry (`bcdedit /copy {bootmgr}`) whose path is the payload. The payload
chain-loads `\EFI\Microsoft\Boot\bootmgfw.efi`, so Windows boots normally
afterwards.

`Uninstall` deletes the entry and the files. Deleting `arm.txt` alone also
disarms the payload — the application then does nothing but chain-load Windows.

**Failed-boot guard.** Stage-3 increments `\EFI\HvFn\boot.txt` before it arms.
If it reaches 3 (three arming attempts that never made it back to Windows) it
disarms itself and boots Windows. `-Reset` writes it back to 0.

**Requirements / caveats**

* **Secure Boot must be off.** The payload is unsigned; firmware with Secure
  Boot enabled refuses to run it.
* **Hyper-V / VBS / Memory Integrity must be off.** They want to own VMX, and
  VT-x cannot be entered twice. Check: `msinfo32` → "Virtualization-based
  security: Not enabled".
* **BitLocker:** changing the boot path is the kind of change that can trigger a
  recovery prompt on some configurations. Have the recovery key before arming.
* Only the boot processor is virtualised (that is what a UEFI application can
  reach), which is why the launcher pins itself to CPU 0.

---

## 4. Using the launcher

On start the launcher pings the hypervisor:

* `Stage-3: resident` — the hypervisor is loaded, the boot path works.
* `Stage-3: not loaded` — the payload did not arm (marker missing, disarmed
  after failed boots, Secure Boot, VT-x off in firmware, or Hyper-V running).

Then it polls for `FortniteClient-Win64-Shipping.exe`, and on `Attach` asks the
hypervisor to resolve the game (see §5). With a target resolved, `Overlay`
creates a click-through layered window that tracks the game's client area.

Toggles: 2D box, corner box, skeleton, snapline, distance, FOV ring.

---

## 5. Target resolution (why no handle is needed)

The hypervisor never runs in the game's context, so it cannot read CR3 from the
VMCS. Instead it takes one kernel-mode VM exit on the BSP:

```
GS base -> KPCR -> CurrentThread (0x188) -> KTHREAD.Process (0xB8) -> EPROCESS
```

and validates the sample by checking that `EPROCESS + 0x28`
(`DirectoryTableBase`) equals the CR3 the CPU was actually using. The rest is
derived rather than assumed:

1. **ntoskrnl base** — scan down from an IDT handler address for a valid PE.
2. **PsActiveProcessHead** — parsed from ntoskrnl's export directory.
3. **`ActiveProcessLinks` offset** — brute-forced: the value `X` for which
   `list[0] - X` yields an EPROCESS whose DTB maps the list head.
4. **the game** — walk the list and look for `FortniteClient` in the EPROCESS
   image-name area.
5. **module base and PEB** — scan the EPROCESS for a PEB-shaped pointer whose
   `+0x10` is a PE image with a sane `SizeOfImage`.

Step 3 and 5 are offset-free by construction, which is what makes this survive
most Windows struct reshuffles.

---

## 6. Offsets

Everything build-dependent is in [src/launcher/offsets.h](src/launcher/offsets.h).
The defaults are the dump this package shipped with (`GWorld` RVA
`0x1C9DA790`, decrypt `bswap64(x) + 0x3F1FCDFB`).

After a game update, re-dump and change only that file. The ESP validates every
read (pointer canonicality, finite floats, `MZ`/`PE` checks, bone-array bounds),
so a stale offset degrades to "nothing drawn" rather than a crash.

`PlayerStateName` is `0` on purpose: names need a verified `FString` offset, and
a wrong one would draw garbage. Fill it in when you have the dump.

---

## 7. Failure codes

Stage-3 prints `HvFn: stage-3 init failed (code N)` on the firmware console and
then boots Windows **without** the hypervisor.

| code | meaning |
|---|---|
| 1 | CPU reports no VMX |
| 2 | VT-x disabled in firmware (`IA32_FEATURE_CONTROL` locked without VMXON) |
| 3 | runtime-page allocation failed |
| 4 | host page tables |
| 5 | EPT construction |
| 6 | arena exhausted (host tables, control pages, stack, XSAVE area) |
| 7 | `VMXON` failed |
| 8 | `VMCLEAR` failed |
| 9 | `VMPTRLD` failed |
| 10 | VMCS controls unusable (no EPT, no secondary controls, or no MSR bitmaps) |
| 11 | `VMLAUNCH` failed — `VMCS` instruction-error field is in `hv_launch_error()` |
| 12 | the launch worked but the self-test hypercall failed — VMX is left and Windows boots normally |

---

## 8. Verification status — read this

Built and statically verified here:

* both binaries compile and link; the EFI image is a well-formed PE32+ with
  subsystem 10, entry `EfiEntry`, no imports, and a `.reloc` table;
* the assembler output was disassembled and the VMX encodings checked by hand
  (`VMXON F3 0F C7 /6`, `VMCLEAR 66 0F C7 /6`, `VMPTRLD 0F C7 /6`,
  `VMREAD 0F 78`, `VMWRITE 0F 79`, `VMLAUNCH 0F 01 C2`, `VMRESUME 0F 01 C3`);
* VMCS field encodings were generated from a reference implementation rather
  than typed from memory, and spot-checked against the SDM values
  (`GUEST_CR3 0x6802`, `HOST_RSP 0x6C14`, `EPTP 0x201A`, `EXCEPTION_BITMAP 0x4004`);
* the launcher starts, resolves "not resident" cleanly and stays up;
* the exit stub, XSAVE/XRSTOR and `INVEPT` encodings were re-checked in the
  disassembly after the second pass.

Boot blockers fixed in the second pass (details in `WORKLOG.md`):

* "use MSR bitmaps" is enabled (the old `1<<9` was INVLPG exiting), so the guest
  no longer exits forever on its first `RDMSR`;
* `RDTSCP`/`INVPCID` are enabled in the secondary controls and masked in CPUID
  when unavailable, so CPUID and the VMCS agree;
* EPT leaves are write-back instead of uncached;
* the exit stub saves full SIMD state with `XSAVE`/`XRSTOR`;
* a private host GDT/TSS/IDT plus a fault-recovery path replaces the firmware
  tables the OS reclaims;
* EPT violations above the mapped window are mapped on demand or denied with
  `#GP` instead of looping;
* the resolver reads the PEB with the target's DTB, not the kernel CR3;
* the failed-boot counter no longer trips on ordinary reboots.

**Not verified:** execution on real hardware. Nothing here has been booted with
the hypervisor active — that needs a reboot into the payload, which this session
cannot do. The VMX bring-up follows the SDM ordering (VMXON → VMCS → controls →
guest/host state → VMLAUNCH with an identity-mapped host CR3 and EPT), and every
failure path falls back to a normal boot, but treat the first arm as an
experiment: keep a Windows recovery USB handy, and expect to read the console
output if `VMLAUNCH` rejects the state.

Known limits by design:

* BSP only; the launcher is pinned to CPU 0. A hypercall from another core
  would raise a real `#UD` and take the process down.
* The MSR bitmap intercepts nothing (pure passthrough), there are no EPT hooks
  and no CR3 interception — this build does not try to hide itself from
  anti-cheat beyond masking CPUID leaf 1 `ECX[31]`.
* The game reads are only as fast as one VM exit per request (≈1–2 µs).
