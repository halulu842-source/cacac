# HvFn Stage-3 — full status

## What it is

A Type-1 (bare-metal) Intel VT-x hypervisor that installs itself **from the UEFI
firmware stage**, before Windows Boot Manager runs, and boots Windows inside the
VM.

- **No kernel driver.**
- **No vulnerable driver / BYOVD.**
- No code-signing dependency beyond the firmware's own.
- Memory access for the cheat is served over hypercalls, translated by the
  hypervisor using the game's own CR3.

Because it runs before `bootmgfw.efi`, it owns VMX from the first instruction of
the OS boot. Nothing to hook, no Microsoft binary to signature-match, and no
dependency on Hyper-V being enabled.

## Files

**stage3 — the hypervisor payload**

| file | size | role |
|---|---|---|
| `src/stage3/efi_main.c` | 16,221 B | UEFI entry, self-relocation into `EfiRuntimeServicesCode`, arm marker + failed-boot guard, chainloads bootmgfw |
| `src/stage3/hv_core.c` | 59,144 B | VMX bring-up, VMCS programming, VM-exit dispatch, hypercall dispatch, VMCS state dump |
| `src/stage3/hv_asm.asm` | 15,230 B | VMX instruction wrappers, launch trampoline, VM-exit stub, pre-VMX fault catcher |
| `src/stage3/hv_mem.c` | 3,704 B | physical access + 4-level page-table walker |
| `src/stage3/hv_resolve.c` | 12,827 B | finds the game's EPROCESS/CR3 from one ring-0 sample |
| `src/stage3/hv.h` | 6,855 B | internal ABI |
| `src/stage3/vmcs_fields.h` | 22,028 B | VMCS encodings, generated from the SDM |

**launcher — ring 3**

| file | size | role |
|---|---|---|
| `src/launcher/main.cpp` | 44,388 B | hypercall client, target resolution, ESP overlay |
| `src/launcher/installer.cpp` | 13,794 B | ESP staging, BCD firmware entry |
| `src/launcher/offsets.h` | 5,427 B | every build-dependent number |
| `src/common/hvfn_protocol.h` | 3,409 B | shared ABI |

## Boot flow

1. Firmware boot entry **"HvFn Stage-3"** runs `\EFI\HvFn\HvFnStage3.efi` first.
2. It copies itself into `EfiRuntimeServicesCode` pages, applies relocations, and
   continues from the relocated copy.
3. If `arm.txt` exists: `hv_init()` → host tables → EPT → `VMXON` → `VMCLEAR` →
   `VMPTRLD` → program VMCS → `VMLAUNCH`.
4. Everything after that — firmware, boot manager, Windows — is the guest.
5. It chain-loads `bootmgfw.efi` so the machine still boots.
6. Ring 3 talks to it via `VMCALL` (ring 0) or a `#UD`-intercepted `VMCALL`
   (ring 3). The handler reads/writes through the caller's own page tables and
   advances RIP past the instruction.

**Failed-boot guard:** three arming attempts that never reach the Windows
handoff and it disarms itself and boots Windows normally.

## Verified working on the actual hardware

```
05b0v alt try_vmxon rc: 0     VMXON succeeds
05a vmxon ok                  real VMXON ok
05b vmcs ok                   VMCLEAR + VMPTRLD + full VMCS programming ok
```

- VT-x present; `IA32_FEATURE_CONTROL = 0x5` (locked, VMX outside SMX enabled)
- VMCS revision `0x13` (19)
- `CR0 = 0x80010033`, `CR4 = 0x42668` (VMXE|OSXSAVE|MCE|PGE|PAE|…), `EFER = 0xD00` (LME|LMA|NXE)
- MTRRs: 10 variable, default type WB, enabled
- **The pre-VMX fault catcher works** — a deliberate `ud2` is caught (rc=3, vector 6)
- Self-relocation, arm marker, boot guard and chainload all work

## THE FAILURE

**`VMLAUNCH` never returns.** The trace always ends at:

```
05c prelaunch
   <-- nothing further
```

Two things make this unusual, and they are why it has been hard:

1. **A rejected VM entry is supposed to report a reason and return.** The
   trampoline does exactly that: if `vmlaunch` does not launch it executes
   `mov rax,1; ret`, and `hv_init` traces `06b vmlaunch err: E` from
   `VMCS_VMEXIT_INSTRUCTION_ERROR`. **That line has never once appeared.** The
   error path is unreachable, so the one piece of diagnostic information Intel
   provides for this case is unavailable.

2. **No VM exit is ever taken either.** The marker `05d1 first vm exit, reason N`
   sits at the top of `hv_handle_exit` and has never fired. So it is not
   "entry succeeded and the exit handler died" — **nothing downstream of
   `VMLAUNCH` has ever executed in any build.**

The CPU stops during VM entry itself, with no fault the IDT can catch and no
error code returned.

### This is not a hardware limitation

`VMXON` works, the VMCS is programmable, and on this same machine Hyper-V has
run (it was active before VBS was disabled) — so this CPU enters VMX and
launches guests correctly when Microsoft's loader does it.

### Current staged build

The ESP holds a **diagnostic build that deliberately does not launch**
(`g_dry_run = 1`). It programs the VMCS, dumps all 52 validated fields, then
`VMXOFF`s and boots Windows. It cannot hang — proven twice.

The dump has been captured **zero** times, because of two placement bugs:

- dump #1 was placed before `hv_enter`, but `hv_prepare_guest` — which fills the
  guest and host halves of the VMCS — runs *inside* `hv_enter` → read all zeros
- dump #2 was correctly positioned, but the dry-run `return` sat before
  `hv_enter`, so the trampoline never ran at all

Both fixed: the bail now lives *inside* the trampoline, between
`hv_prepare_guest` and `vmlaunch`.

## Bug history — every one found and fixed

**Exit path / intercepts**

1. Tree did not compile — `nt_active_process_head` removed from `HvContext`
   mid-refactor, five uses left in `hv_resolve.c`
2. `INVLPG` keyed to exit reason **28**; it is **14** (28 is `CR_ACCESS`). An
   *enabled* intercept with no handler — an infinite exit loop on the first TLB
   flush
3. `proc2` bit 20 enabled `XSAVES`/`XRSTORS` trapping with no `case 63`/`64`
4. `handle_ring0_call` guessed RIP advancement by sniffing opcodes instead of
   using the VM-exit instruction-length field
5. `-11` never reported *why* `VMLAUNCH` failed

**Launch path — where the real fight was**

6. `vmxon [rcx]` — region address passed directly. `VMXON` takes a **memory
   operand holding** the physical address, so it read the region's first qword
   (the VMCS revision, `0x13`) and operated on physical `0x13` — inside the
   real-mode IVT
7. **`CR0.NE = 0`** — this firmware leaves it clear; `VMXON` requires `NE`,
   `PE` and `VMXE`. With `NE` clear it raised a machine check
8. No IDT of ours loaded before `VMXON` → that machine check went to the
   firmware's handler and was unrecoverable
9. `#MC` (vector 18) not in the catcher → the machine check stayed invisible
10. My own MTRR scan read past `VCNT` → `#GP`, then the catcher's resume stub
    unwound a stack frame it did not own
11. My catcher pointed **all 256** vectors at the `#GP` stub; an interrupt frame
    carries no error code, so the first timer tick misread its `IRETQ` frame
12. `CR4.VMXE` cleared before the real `VMXON` → `#UD`

Plus the two diagnostic-placement bugs above.

## The current fix, and why it differs from the others

Every earlier fix removed a cause of something going wrong *earlier in the
boot*. This one is the first aimed directly at VM entry, and it is grounded in a
working implementation rather than a guess.

Cross-referencing **Sina Karvandi's Hypervisor-From-Scratch** (`VmxSetupVmcs`),
the host TR comes from the **live** TR selector:

```c
__vmx_vmwrite(HOST_TR_SELECTOR, AsmGetTr() & 0xF8);
HvGetSegmentDescriptor(&SegmentSelector, AsmGetTr(), AsmGetGdtBase());
__vmx_vmwrite(HOST_TR_BASE, SegmentSelector.BASE);
```

That descriptor is **type 11 (busy 64-bit TSS)**, because `LTR` sets the busy
bit in the GDT. `hvfn` builds a **private** GDT — necessarily, since the
firmware's lives in boot-services memory the OS reclaims — and wrote a synthetic
descriptor with **type 9 (available)**. A host TR that is not a *busy* 64-bit
TSS is a host-state violation, and host state is validated at VM entry.

**Changed to `0x8B` (busy).** `TSS.RSP0` was also zero and is now set.

Differences checked and judged non-blocking: `CR0_READ_SHADOW` /
`CR4_READ_SHADOW` are inert with guest/host masks of 0; an unset
`GUEST_IA32_DEBUGCTL` is legal (`0` is a valid `DEBUGCTL`); his raw host
`CR0`/`CR4` versus my adjusted ones is the safer direction on my side.

## Where it stands

Build is green with the fix and the launch re-enabled (`g_dry_run = 0`, a
one-character flip at the top of `hv_asm.asm`'s `.data`).

**One boot is needed**, and it can go either way:

| option | outcome |
|---|---|
| stage + one real launch | `05d guest resumed` → `07 self-test ok` = hypervisor live. Or a hang → hard power-off |
| one more safe dry run first | boots for certain; dump shows `e9 trar: 0x8B`, confirming the descriptor took, then launch with certainty |

Outstanding regardless of which is chosen: even after a successful launch,
`hv_exit_entry` will be executing for the first time, and the self-test,
`Attach`, and `offsets.h` have never run against the live game.
