# Testing HvFn, step by step

Nothing here is destructive except the install step, and that one is reversible
two ways (see §7). Read §0 before the first boot.

---

## 0. Pre-flight

| Check | How | Needed |
|---|---|---|
| Secure Boot | `Confirm-SecureBootUEFI` (admin) or `msinfo32` → "Secure Boot State" | **Off.** The payload is unsigned; firmware will refuse it. |
| VBS / Memory Integrity | `msinfo32` → "Virtualization-based security" | **Not enabled.** It wants VMX for itself. |
| VT-x in firmware | Task Manager → Performance → CPU → "Virtualization: Enabled" | On (yours reports enabled) |
| BitLocker | `manage-bde -status` | Have the recovery key, or suspend it: `manage-bde -protectors -disable C:` |
| Recovery | A Windows install USB, or know your F12 boot-menu key | Strongly recommended for the first arm |

Run everything from an **elevated** PowerShell / Explorer "Run as administrator".

---

## 1. Build

```powershell
cd C:\Users\emanu\Downloads\hv\hvfn
powershell -ExecutionPolicy Bypass -File build\build_all.ps1
```

Produces:

```
build\out\HvFnStage3.efi     the UEFI payload
build\out\HvFn.exe           launcher with that payload embedded
```

`HvFn.exe` is self-contained: static CRT, no VC++ redistributable, no external
scripts. Installing it is what unpacks the embedded `.efi` onto the EFI system
partition.

---

## 2. Arm

Double-click `build\out\HvFn.exe` → **Arm + Reboot** → accept the UAC prompt if
it appears. The machine reboots immediately and the payload arms on the way back
up; no second run and no separate "install" step.

What that one click does, in order:

1. mounts the ESP on a free drive letter (`mountvol X: /S`),
2. writes `\EFI\HvFn\HvFnStage3.efi`, `arm.txt` (marker) and `boot.txt` (counter
   reset to 0),
3. adds the firmware boot entry "HvFn Stage-3" and puts it first (only the first
   time),
4. reboots.

It is idempotent — pressing it again rewrites the payload and reboots, which is
also how you deploy a rebuilt Stage-3.

Headless equivalent:

```powershell
.\HvFn.exe --arm
```

(`--install` stages without rebooting, `--uninstall` removes, `--reset` clears
the failed-boot counter.)

---

## 3. First boot — what you should see

The payload runs before Windows Boot Manager, so there is a fraction of a second
of text output on the console:

| Output | Meaning |
|---|---|
| *(nothing, Windows starts)* | normal — the payload prints nothing on success |
| `HvFn: not armed - chain-loading Windows` | `arm.txt` is missing on the ESP |
| `HvFn: disarmed after repeated failed boots - run install.ps1 -Reset` | the 3-boot guard tripped |
| `HvFn: stage-3 init failed (code N) - booting unvirtualised` | VMX bring-up failed; Windows still boots normally. See the code table in `docs/README.md` §7 |

If the machine hangs or resets instead of booting Windows, go straight to §7.

---

## 4. Verify the hypervisor is resident

Run `HvFn.exe` (normal window). The log should print:

```
Stage-3 resident, build 0x2026111501 vmx rev 0x...
failed-boot counter cleared
```

That means the boot path works and hypercalls are being serviced. If instead you
get `Stage-3 not resident (8)`, the payload did not arm — §3's console output
says why.

---

## 5. In-game test

1. Start Fortnite normally and get **into the lobby** (the game must have joined
   a session before the actor list is meaningful).
2. In `HvFn.exe` click **Attach**. Expect a log line:
   ```
   resolved game: base 0x7ff6xxxxxxxx cr3 0x1a... peb 0x...
   ```
   * `attach failed - is the game in a match / past the lobby?` → the hypervisor
     has no kernel sample yet or found no process. Wait a second and click
     again; the first sample lands on the first kernel-mode VM exit.
3. Click **Overlay**. A click-through window appears over the game, following
   the client area. Drag the game window; the overlay must follow.
4. Toggle **2D box**, **Skeleton**, **Distance**. Boxes should sit on players.

Expected on a working build: boxes aligned to bodies, skeleton lines inside the
boxes, distance in metres, overlay sticks to the game when you move it.

---

## 6. Interpreting a bad first run

| Symptom | Cause | Fix |
|---|---|---|
| `Stage-3 not resident (8)` | payload not armed / not loaded | re-run Install, check §3 console text |
| resolved, but nothing drawn | stale offsets (game patched) | re-dump `src\launcher\offsets.h` |
| boxes drift from bodies | wrong camera offsets | check `CameraCachePrivate`/`Pov*` values |
| boxes for every object, not just players | `ActorPlayerState` wrong | that offset gates the ESP; re-dump it |
| overlay invisible | game in exclusive fullscreen | switch the game to windowed/borderless |
| overlay lags the window | window drag with a slow frame | expected; it resyncs every frame |
| game crashes on attach | reading freed actors | the read path validates, but a bad `RootComponent`/`Mesh` offset can still do it |

Every offset lives in one file, `src/launcher/offsets.h`, with the ESP validating
each read (canonical pointers, finite floats, bone-array bounds, distance
sanity), so a wrong value normally means "drawn nothing" rather than a crash.

---

## 7. If the machine will not boot

Three independent ways out, in order of convenience:

1. **F12 / F11 boot menu at POST → pick "Windows Boot Manager".** This bypasses
   the added entry entirely; the payload never runs.
2. **Let the guard do its job.** Stage-3 climbs `boot.txt` before arming and
   disarms itself at 3, then boots Windows unvirtualised.
3. **From Windows, remove it:**
   ```powershell
   .\HvFn.exe --uninstall
   ```
   Deletes the boot entry and the files on the ESP. `.\install.ps1 -Uninstall`
   does the same thing if the exe is unavailable.

Deleting one file is also enough to make the payload passive: if
`\EFI\HvFn\arm.txt` is gone, Stage-3 does nothing but chain-load Windows.

---

## 8. Iterating

* `HvFn.exe --reset` clears the failed-boot counter without touching the payload.
* The launcher only ever *reads* the game; a crash in `HvFn.exe` cannot damage
  anything — relaunch it.
* After a Fortnite update: re-dump the offsets, rebuild the launcher
  (`build\build_launcher.ps1`), no need to re-arm the payload.
* If you change Stage-3 itself, rebuild both and re-run Install — that rewrites
  the `.efi` on the ESP from the fresh embedded copy.
