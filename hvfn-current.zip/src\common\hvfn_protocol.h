/* hvfn_protocol.h - shared ABI between the HvFn launcher (ring 3) and the
 * Stage-3 hypervisor (VMX root).
 *
 * Transport: executing VMCALL (0F 01 C1) from ring 3 raises #UD because VMX
 * instructions are illegal outside VMX root operation.  Stage-3 puts #UD in the
 * exception bitmap, so the fault becomes a VM exit.  The handler checks the
 * faulting instruction, the magic in RAX and the request pointer in RCX, does
 * the work, writes the result back through the caller's own page tables and
 * advances guest RIP past the three-byte instruction.
 *
 * Every pointer in a request is a *virtual* address in the caller's address
 * space.  The hypervisor translates it with the guest CR3 taken from the VMCS
 * at exit time, so no shared-memory handshake or fixed physical page is needed.
 */
#ifndef HVFN_PROTOCOL_H
#define HVFN_PROTOCOL_H

#define HVFN_MAGIC        0x4856464E4B543301ull   /* "HVFNKTS\3" - bump on ABI break */
#define HVFN_MAGIC_MASK   0xFFFFFFFFFFFFFFFFull

/* Guest -> host scratch register for the sleep-variant of the call is unused;
 * RAX always carries HVFN_MAGIC. */

enum HvOp {
    HV_OP_PING        = 1,   /* out[0] = HVFN_MAGIC, out[1] = build id            */
    HV_OP_READ        = 2,   /* arg0 = cr3, arg1 = src, arg2 = dst, arg3 = len    */
    HV_OP_WRITE       = 3,   /* arg0 = cr3, arg1 = dst, arg2 = src, arg3 = len    */
    HV_OP_TRANSLATE   = 4,   /* arg0 = cr3, arg1 = va  -> out[0] = phys or 0      */
    HV_OP_RESOLVE     = 5,   /* arg0 = pid (0 = auto)  -> out = cr3, base, peb    */
    HV_OP_STATS       = 6,   /* out = exit count, hypercall count, samples, state */
    HV_OP_FLUSH_TARGET= 7    /* drop the cached target resolution                 */
};

enum HvStatus {
    HV_OK             = 0,
    HV_ERR_ARGS       = 1,
    HV_ERR_NOT_MAPPED = 2,
    HV_ERR_TOO_BIG    = 3,
    HV_ERR_NO_TARGET  = 4,
    HV_ERR_PENDING    = 5,   /* no kernel-context sample yet, retry               */
    HV_ERR_NO_KERNEL  = 6,   /* could not locate ntoskrnl / PsInitialSystemProcess */
    HV_ERR_FAULT      = 7,
    HV_ERR_NO_HV      = 8    /* set by the launcher, never by the hypervisor      */
};

/* Resolution state mirrored in out[4] of HV_OP_STATS. */
enum HvTargetState {
    HV_TARGET_NONE    = 0,
    HV_TARGET_READY   = 1
};

#define HV_MAX_XFER       0x4000u   /* bytes per READ/WRITE request             */
#define HV_MAX_REQ        0x100u

typedef struct HvRequest {
    unsigned int  op;        /* in:  enum HvOp                                  */
    int           status;    /* out: enum HvStatus                              */
    unsigned int  reserved;  /* in:  zero                                       */
    unsigned int  size;      /* out: bytes actually transferred                 */
    unsigned long long arg[6];  /* in                                           */
    unsigned long long out[6];  /* out                                          */
} HvRequest;

/* out[] layout per op:
 *   PING      : [0] magic, [1] build id, [2] vmx revision, [3] ept 1GB support
 *   TRANSLATE : [0] physical address (0 = not mapped)
 *   RESOLVE   : [0] cr3, [1] module base, [2] peb, [3] pid
 *   STATS     : [0] exits, [1] hypercalls, [2] kernel samples, [3] target state,
 *               [4] resolve attempts, [5] last resolve error
 */

static const unsigned long long HVFN_BUILD_ID = 0x2026111501ull;

#endif /* HVFN_PROTOCOL_H */
