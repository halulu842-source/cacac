/* hvclient.h - ring-3 side of the Stage-3 hypercall interface.
 *
 * VMCALL is a VMX instruction: executing it outside VMX root raises #UD.  The
 * hypervisor puts #UD in the VM-exception bitmap, so the fault becomes a VM
 * exit, the handler performs the request and advances RIP past the three-byte
 * instruction.  From ring 3 this looks like a normal function call that returns
 * instantly, and no handle to the game process is ever opened.
 *
 * The stub is emitted into an RWX page at start-up so the launcher stays a
 * single translation unit (MSVC has no x64 inline assembly):
 *
 *      mov rax, rcx    48 89 C8
 *      mov rcx, rdx    48 89 D1
 *      vmcall          0F 01 C1
 *      ret             C3
 */
#ifndef HVFN_HVCLIENT_H
#define HVFN_HVCLIENT_H

#include <windows.h>
#include <cstdint>
#include "../common/hvfn_protocol.h"

typedef uint64_t (*HvCallFn)(uint64_t magic, uint64_t request);

namespace hv {

inline HvCallFn& stub()
{
    static HvCallFn fn = nullptr;
    return fn;
}

inline bool InitStub()
{
    if (stub())
        return true;

    unsigned char code[] = {
        0x48, 0x89, 0xC8,        /* mov rax, rcx */
        0x48, 0x89, 0xD1,        /* mov rcx, rdx */
        0x0F, 0x01, 0xC1,        /* vmcall       */
        0xC3                     /* ret          */
    };

    void* mem = VirtualAlloc(nullptr, 0x1000, MEM_COMMIT | MEM_RESERVE,
                             PAGE_EXECUTE_READWRITE);
    if (!mem)
        return false;
    memcpy(mem, code, sizeof(code));
    FlushInstructionCache(GetCurrentProcess(), mem, sizeof(code));
    stub() = (HvCallFn)mem;
    return true;
}

/* Returns HV_ERR_NO_HV when Stage-3 is not resident (the VMCALL faults). */
inline int Call(HvRequest& req)
{
    if (!InitStub())
        return HV_ERR_NO_HV;

    /* If the handler dies before writing the status back, the caller must see a
     * failure rather than a stale HV_OK from a previous call. */
    req.status = HV_ERR_FAULT;

    __try {
        stub()(HVFN_MAGIC, (uint64_t)&req);
    }
    __except (EXCEPTION_EXECUTE_HANDLER) {
        req.status = HV_ERR_NO_HV;
        return HV_ERR_NO_HV;
    }
    return req.status;
}

inline int Ping(uint64_t* build = nullptr, uint32_t* rev = nullptr)
{
    HvRequest r{};
    r.op = HV_OP_PING;
    int st = Call(r);
    if (st == HV_OK) {
        if (build) *build = r.out[1];
        if (rev)   *rev = (uint32_t)r.out[2];
    }
    return st;
}

inline int Resolve(uint32_t pid, uint64_t* cr3, uint64_t* base, uint64_t* peb)
{
    HvRequest r{};
    r.op = HV_OP_RESOLVE;
    r.arg[0] = pid;
    int st = Call(r);
    if (st == HV_OK) {
        if (cr3)  *cr3 = r.out[0];
        if (base) *base = r.out[1];
        if (peb)  *peb = r.out[2];
    }
    return st;
}

/* Drop the cached target.  The hypervisor short-circuits Resolve while the
 * target is ready, so a restarted game would otherwise keep the old CR3 and
 * draw nothing. */
inline int FlushTarget()
{
    HvRequest r{};
    r.op = HV_OP_FLUSH_TARGET;
    return Call(r);
}

inline bool ReadRaw(uint64_t cr3, uint64_t va, void* dst, size_t len)
{
    if (!cr3 || !dst || !len)
        return false;

    uint8_t* out = (uint8_t*)dst;
    while (len) {
        HvRequest r{};
        uint32_t chunk = (uint32_t)((len > HV_MAX_XFER) ? HV_MAX_XFER : len);
        r.op = HV_OP_READ;
        r.arg[0] = cr3;
        r.arg[1] = va;
        r.arg[2] = (uint64_t)out;
        r.arg[3] = chunk;
        if (Call(r) != HV_OK)
            return false;
        out += chunk;
        va += chunk;
        len -= chunk;
    }
    return true;
}

template <typename T>
inline bool Read(uint64_t cr3, uint64_t va, T& out)
{
    return ReadRaw(cr3, va, &out, sizeof(T));
}

template <typename T>
inline T ReadOr(uint64_t cr3, uint64_t va, T fallback = T{})
{
    T v{};
    if (!Read<T>(cr3, va, v))
        return fallback;
    return v;
}

} /* namespace hv */

#endif /* HVFN_HVCLIENT_H */
