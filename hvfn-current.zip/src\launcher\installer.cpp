/* installer.cpp - mount the ESP, drop the embedded payload, register the boot
 * entry, and keep the failed-boot counter honest.
 *
 * Shelling out to mountvol/bcdedit keeps the launcher dependency-free: both
 * ship with Windows, unlike a native GPT/BCD parser which would be a few
 * hundred lines of risky code for no gain.
 */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <shellapi.h>
#include <cstdio>
#include <cstring>
#include <string>
#include <vector>

#include "installer.h"
#include "resource.h"

static char g_esp = 0;
static std::string g_lastCmd;

namespace inst {

/* ------------------------------------------------------------------- utils */

static bool RunHidden(const std::string& cmd, std::string& out)
{
    char tmp[MAX_PATH] = { 0 };
    GetTempPathA(MAX_PATH, tmp);
    std::string file = std::string(tmp) + "hvfn_cmd.txt";

    std::string full = "cmd.exe /c \"" + cmd + " > \"" + file + "\" 2>&1\"";

    STARTUPINFOA si{};
    si.cb = sizeof(si);
    si.dwFlags = STARTF_USESHOWWINDOW;
    si.wShowWindow = SW_HIDE;

    PROCESS_INFORMATION pi{};
    std::vector<char> line(full.begin(), full.end());
    line.push_back(0);

    if (!CreateProcessA(nullptr, line.data(), nullptr, nullptr, FALSE,
                        CREATE_NO_WINDOW, nullptr, nullptr, &si, &pi))
        return false;

    WaitForSingleObject(pi.hProcess, 60000);
    DWORD code = 1;
    GetExitCodeProcess(pi.hProcess, &code);
    CloseHandle(pi.hProcess);
    CloseHandle(pi.hThread);

    out.clear();
    FILE* f = nullptr;
    if (fopen_s(&f, file.c_str(), "rb") == 0 && f) {
        char buf[512];
        size_t n;
        while ((n = fread(buf, 1, sizeof(buf), f)) > 0)
            out.append(buf, n);
        fclose(f);
    }
    DeleteFileA(file.c_str());
    g_lastCmd = out;
    return code == 0;
}

const char* LastCommandOutput() { return g_lastCmd.c_str(); }

bool DumpFirmware(std::string& out, std::string& err)
{
    if (!IsElevated()) {
        err = "administrator rights required";
        return false;
    }
    if (!RunHidden("bcdedit /enum firmware", out)) {
        err = out.empty() ? "bcdedit failed" : out;
        return false;
    }
    return true;
}

static std::string EspPath(const char* tail)
{
    std::string base;
    base += g_esp;
    base += ":\\EFI\\HvFn";
    base += tail;
    return base;
}

static bool WriteTextFile(const std::string& path, const char* text)
{
    HANDLE h = CreateFileA(path.c_str(), GENERIC_WRITE, 0, nullptr, CREATE_ALWAYS,
                           FILE_ATTRIBUTE_NORMAL, nullptr);
    if (h == INVALID_HANDLE_VALUE)
        return false;
    DWORD written = 0;
    BOOL ok = WriteFile(h, text, (DWORD)strlen(text), &written, nullptr);
    CloseHandle(h);
    return ok != FALSE;
}

/* --------------------------------------------------------------- elevation */

bool IsElevated()
{
    BOOL admin = FALSE;
    PSID sid = nullptr;
    SID_IDENTIFIER_AUTHORITY nt = SECURITY_NT_AUTHORITY;

    if (AllocateAndInitializeSid(&nt, 2, SECURITY_BUILTIN_DOMAIN_RID,
                                 DOMAIN_ALIAS_RID_ADMINS, 0, 0, 0, 0, 0, 0, &sid)) {
        CheckTokenMembership(nullptr, sid, &admin);
        FreeSid(sid);
    }
    return admin != FALSE;
}

bool RelaunchElevated(const char* args)
{
    char path[MAX_PATH] = { 0 };
    GetModuleFileNameA(nullptr, path, MAX_PATH);

    SHELLEXECUTEINFOA sei{};
    sei.cbSize = sizeof(sei);
    sei.lpVerb = "runas";
    sei.lpFile = path;
    sei.lpParameters = args;
    sei.nShow = SW_SHOWNORMAL;
    return ShellExecuteExA(&sei) != FALSE;
}

/* --------------------------------------------------------------------- ESP */

char EspLetter() { return g_esp; }

static char FreeLetter()
{
    DWORD mask = GetLogicalDrives();
    for (char c = 'S'; c <= 'Z'; ++c) {
        if (!(mask & (1u << (c - 'A'))))
            return c;
    }
    return 0;
}

bool MountEsp(std::string& err)
{
    if (g_esp) {
        std::string probe;
        probe += g_esp;
        probe += ":\\";
        if (GetFileAttributesA(probe.c_str()) != INVALID_FILE_ATTRIBUTES)
            return true;
        g_esp = 0;
    }

    char letter = FreeLetter();
    if (!letter) {
        err = "no free drive letter to mount the ESP";
        return false;
    }

    std::string cmd = "mountvol ";
    cmd += letter;
    cmd += ": /S";

    std::string out;
    if (!RunHidden(cmd, out)) {
        err = "mountvol failed: " + out;
        return false;
    }

    std::string probe;
    probe += letter;
    probe += ":\\";
    if (GetFileAttributesA(probe.c_str()) == INVALID_FILE_ATTRIBUTES) {
        err = "ESP did not appear on ";
        err += letter;
        return false;
    }

    g_esp = letter;
    return true;
}

void UnmountEsp()
{
    if (!g_esp)
        return;
    std::string cmd = "mountvol ";
    cmd += g_esp;
    cmd += ": /D";
    std::string out;
    RunHidden(cmd, out);
    g_esp = 0;
}

bool PayloadOnEsp()
{
    std::string p = EspPath("\\HvFnStage3.efi");
    return GetFileAttributesA(p.c_str()) != INVALID_FILE_ATTRIBUTES;
}

/* -------------------------------------------------------------- boot entry */

/* Every firmware entry whose description or path mentions HvFn. */
static void FindEntries(std::vector<std::string>& out)
{
    std::string dump;

    out.clear();
    if (!RunHidden("bcdedit /enum firmware", dump)) {
        if (!RunHidden("bcdedit /enum {fwbootmgr}", dump))
            return;
    }

    std::string current;
    size_t pos = 0;
    while (pos < dump.size()) {
        size_t eol = dump.find('\n', pos);
        if (eol == std::string::npos)
            eol = dump.size();
        std::string line = dump.substr(pos, eol - pos);
        pos = eol + 1;
        while (!line.empty() && (line.back() == '\r' || line.back() == ' '))
            line.pop_back();

        if (line.find("identifier") == 0) {
            size_t b = line.find('{');
            size_t e = (b == std::string::npos) ? std::string::npos : line.find('}', b);
            current = (b != std::string::npos && e != std::string::npos)
                          ? line.substr(b, e - b + 1) : std::string();
        } else if ((line.find("description") == 0 || line.find("path") == 0) &&
                   line.find("HvFn") != std::string::npos && !current.empty()) {
            bool dup = false;
            for (auto& g : out)
                if (g == current) dup = true;
            if (!dup)
                out.push_back(current);
        }
    }
}

bool BootEntryExists(std::string& guid)
{
    std::vector<std::string> all;
    FindEntries(all);
    if (all.empty())
        return false;
    guid = all.front();
    return true;
}

/* ------------------------------------------------------------------ actions */

static bool WritePayload(std::string& err)
{
    HRSRC hr = FindResourceA(nullptr, MAKEINTRESOURCEA(IDR_STAGE3), RT_RCDATA);
    if (!hr) {
        err = "embedded payload missing from the executable";
        return false;
    }
    HGLOBAL hg = LoadResource(nullptr, hr);
    DWORD size = SizeofResource(nullptr, hr);
    const void* data = LockResource(hg);
    if (!hg || !data || !size) {
        err = "embedded payload unreadable";
        return false;
    }

    std::string path = EspPath("\\HvFnStage3.efi");
    HANDLE h = CreateFileA(path.c_str(), GENERIC_WRITE, 0, nullptr, CREATE_ALWAYS,
                           FILE_ATTRIBUTE_NORMAL, nullptr);
    if (h == INVALID_HANDLE_VALUE) {
        err = "cannot write " + path;
        return false;
    }
    DWORD written = 0;
    BOOL ok = WriteFile(h, data, size, &written, nullptr);
    CloseHandle(h);
    if (!ok || written != size) {
        err = "short write to the ESP";
        return false;
    }
    return true;
}

bool Install(std::string& err)
{
    if (!IsElevated()) {
        err = "administrator rights required";
        return false;
    }

    if (!MountEsp(err))
        return false;

    std::string efiDir;
    efiDir += g_esp;
    efiDir += ":\\EFI";
    CreateDirectoryA(efiDir.c_str(), nullptr);

    std::string ourDir = EspPath("");
    CreateDirectoryA(ourDir.c_str(), nullptr);

    bool ok = WritePayload(err);
    if (ok)
        ok = WriteTextFile(EspPath("\\arm.txt"), "1");
    if (ok)
        ok = WriteTextFile(EspPath("\\boot.txt"), "0");
    /* First boot is always a probe: VMX on, hypercall round trip, VMX off,
     * clean reboot.  Only Arm removes this marker. */
    if (ok)
        ok = WriteTextFile(EspPath("\\probe.txt"), "1");
    if (!ok && err.empty())
        err = "failed to write marker files";

    std::string present = EspPath("\\HvFnStage3.efi");
    bool exists = GetFileAttributesA(present.c_str()) != INVALID_FILE_ATTRIBUTES;

    UnmountEsp();

    if (!ok || !exists)
        return false;

    /* Repeated installs each added an entry; collapse them to exactly one so the
     * firmware does not try a chain of identical options. */
    {
        std::vector<std::string> all;
        FindEntries(all);
        std::string out;
        for (auto& g : all)
            RunHidden("bcdedit /delete " + g + " /f", out);
    }

    {
        std::string out;
        if (!RunHidden("bcdedit /copy {bootmgr} /d \"HvFn Stage-3\"", out)) {
            err = "bcdedit /copy failed: " + out;
            return false;
        }
        size_t b = out.find('{');
        size_t e = (b == std::string::npos) ? std::string::npos : out.find('}', b);
        if (b == std::string::npos || e == std::string::npos) {
            err = "could not parse the new boot entry: " + out;
            return false;
        }
        std::string guid = out.substr(b, e - b + 1);

        if (!RunHidden("bcdedit /set " + guid + " path \\EFI\\HvFn\\HvFnStage3.efi", out)) {
            err = "bcdedit /set path failed: " + out;
            return false;
        }
        RunHidden("bcdedit /set " + guid + " description \"HvFn Stage-3\"", out);
        if (!RunHidden("bcdedit /set {fwbootmgr} displayorder " + guid + " /addfirst", out)) {
            err = "bcdedit displayorder failed: " + out;
            return false;
        }

        std::string check;
        if (!BootEntryExists(check)) {
            err = "entry was created but is not listed by firmware. bcdedit said:\n" + out;
            return false;
        }
    }
    return true;
}

bool Uninstall(std::string& err)
{
    if (!IsElevated()) {
        err = "administrator rights required";
        return false;
    }

    std::vector<std::string> all;
    FindEntries(all);
    {
        std::string out;
        for (auto& g : all)
            RunHidden("bcdedit /delete " + g + " /f", out);
    }

    if (MountEsp(err)) {
        DeleteFileA(EspPath("\\HvFnStage3.efi").c_str());
        DeleteFileA(EspPath("\\arm.txt").c_str());
        DeleteFileA(EspPath("\\boot.txt").c_str());
        std::string dir = EspPath("");
        RemoveDirectoryA(dir.c_str());
        UnmountEsp();
    }
    return true;
}

bool ResetCounter(std::string& err)
{
    if (!IsElevated()) {
        err = "administrator rights required";
        return false;
    }
    if (!MountEsp(err))
        return false;

    bool ok = WriteTextFile(EspPath("\\boot.txt"), "0");
    if (GetFileAttributesA(EspPath("\\arm.txt").c_str()) == INVALID_FILE_ATTRIBUTES)
        ok = ok && WriteTextFile(EspPath("\\arm.txt"), "1");
    if (!ok)
        err = "could not write the counter file";

    UnmountEsp();
    return ok;
}

/* --------------------------------------------------------------- arm/reboot */

static bool EnableShutdownPrivilege()
{
    HANDLE tok = nullptr;
    if (!OpenProcessToken(GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &tok))
        return false;

    LUID luid{};
    if (!LookupPrivilegeValueA(nullptr, SE_SHUTDOWN_NAME, &luid)) {
        CloseHandle(tok);
        return false;
    }

    TOKEN_PRIVILEGES tp{};
    tp.PrivilegeCount = 1;
    tp.Privileges[0].Luid = luid;
    tp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;

    BOOL ok = AdjustTokenPrivileges(tok, FALSE, &tp, sizeof(tp), nullptr, nullptr);
    CloseHandle(tok);
    return ok != FALSE;
}

bool ArmAndReboot(std::string& err)
{
    /* Staging is idempotent: rewriting the payload also refreshes arm.txt and
     * resets the failed-boot counter, which is exactly what "arm" means. */
    if (!Install(err))
        return false;

    /* Real arm: drop the probe marker so the next boot hands off to Windows
     * with the hypervisor still running. */
    {
        std::string e2;
        if (MountEsp(e2)) {
            DeleteFileA(EspPath("\\probe.txt").c_str());
            UnmountEsp();
        }
    }

    if (!EnableShutdownPrivilege()) {
        err = "could not acquire SeShutdownPrivilege";
        return false;
    }

    if (!ExitWindowsEx(EWX_REBOOT | EWX_FORCEIFHUNG,
                       SHTDN_REASON_MAJOR_APPLICATION | SHTDN_REASON_MINOR_MAINTENANCE |
                       SHTDN_REASON_FLAG_PLANNED)) {
        err = "reboot request was refused";
        return false;
    }
    return true;
}

/* --------------------------------------------------------------- machinery */

bool ReadTrace(std::string& out, std::string& err)
{
    out.clear();
    if (!IsElevated()) {
        err = "administrator rights required";
        return false;
    }
    if (!MountEsp(err))
        return false;

    std::string path = EspPath("\\trace.txt");
    FILE* f = nullptr;
    if (fopen_s(&f, path.c_str(), "rb") != 0 || !f) {
        err = "no trace.txt (the payload never ran, or never got past stage 0)";
        UnmountEsp();
        return false;
    }
    char buf[1024];
    size_t n;
    while ((n = fread(buf, 1, sizeof(buf), f)) > 0)
        out.append(buf, n);
    fclose(f);
    UnmountEsp();
    return true;
}

} /* namespace inst */
