/* installer.h - self-install of the Stage-3 payload from inside the launcher.
 *
 * Everything the cheat needs at boot lives in one file: the UEFI payload is
 * embedded in HvFn.exe as an RCDATA resource, so installing is
 *   mount ESP -> write payload + arm marker -> add firmware boot entry
 * with no external scripts, no VC++ redistributable and no SDK components.
 */
#pragma once
#include <string>

namespace inst {

bool IsElevated();
bool RelaunchElevated(const char* args);

/* ESP access (mounts on a free drive letter with mountvol) */
bool  MountEsp(std::string& err);
void  UnmountEsp();
char  EspLetter();

/* state */
bool BootEntryExists(std::string& guid);
bool PayloadOnEsp();

/* actions - all require elevation */
bool Install(std::string& err);
bool Uninstall(std::string& err);
bool ResetCounter(std::string& err);

/* Install (if needed) and reboot: the payload arms on the way back up. */
bool ArmAndReboot(std::string& err);

/* Read \EFI\HvFn\trace.txt - the payload's progress log from the last boot. */
bool ReadTrace(std::string& out, std::string& err);

/* Raw `bcdedit /enum firmware` output, for diagnosing entry creation. */
bool DumpFirmware(std::string& out, std::string& err);

/* Output of the last mountvol/bcdedit command that ran. */
const char* LastCommandOutput();

} /* namespace inst */
