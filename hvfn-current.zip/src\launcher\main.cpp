/* main.cpp - HvFn launcher: hypercall client, target resolution, ESP overlay.
 *
 * Reads never open a handle to the game.  Every value comes back through the
 * Stage-3 hypercall, translated by the hypervisor with the game's own CR3, so
 * the launcher itself only ever touches its own address space.
 */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <tlhelp32.h>
#include <cmath>
#include <cstddef>
#include <cstdio>
#include <cstdint>
#include <cstring>
#include <string>
#include <vector>

#include "hvclient.h"
#include "installer.h"
#include "offsets.h"

/* ------------------------------------------------------------------ config */

struct Config {
    bool box2d         = true;
    bool corner        = true;
    bool skeleton      = true;
    bool snapline      = true;
    bool distance      = true;
    bool name          = false;
    bool fovRing       = true;
    /* Draw players whose team matches the local player's.  Defaults to true so
     * that a stale ActorTeamId takes the filter out of the picture instead of
     * blanking the ESP. */
    bool showTeammates = true;
    int  maxDist    = 400;   /* metres */
    int  fovRadius  = 0;     /* 0 = derive from the camera FOV */
};

static Config  g_cfg;
static bool    g_running      = true;
static bool    g_hvReady      = false;
static bool    g_overlayOn    = false;

static HWND    g_menu         = nullptr;
static HWND    g_overlay      = nullptr;
static HWND    g_status       = nullptr;
static HWND    g_logBox       = nullptr;
static HWND    g_gameWnd      = nullptr;

static DWORD   g_gamePid      = 0;
static uint64_t g_cr3         = 0;
static uint64_t g_base         = 0;
static uint64_t g_peb          = 0;

static std::vector<std::string> g_log;

/* -------------------------------------------------------------------- math */

struct Vec3 { double x, y, z; };
struct Vec2 { float x, y; };

struct Mat4 {
    float m[4][4];
};

struct FQuat { double x, y, z, w; };
/* Must match the game's FTransform byte for byte: Rotation at 0x00, Translation
 * at 0x20, Scale3D at 0x40, with 8 bytes of padding either side of the scale,
 * total 0x60 (confirmed by the SDK dump's static_assert).  Without the padding
 * the compiler places scale at 0x38 - the first pad word - so every bone matrix
 * is built with a garbage scale and each projected bone lands in the wrong
 * place. */
struct FTransform {
    FQuat  rot;          /* 0x00 */
    Vec3   translation;  /* 0x20 */
    double pad0;         /* 0x38 */
    Vec3   scale;        /* 0x40 */
    double pad1;         /* 0x58 */
};
static_assert(sizeof(FQuat) == 0x20, "FQuat must be four doubles");
static_assert(sizeof(Vec3)  == 0x18, "Vec3 must be three doubles");
static_assert(sizeof(FTransform) == 0x60, "FTransform must match the game (0x60)");
static_assert(offsetof(FTransform, translation) == 0x20, "translation at 0x20");
static_assert(offsetof(FTransform, scale)       == 0x40, "Scale3D at 0x40");

static Mat4 MatrixFromRotation(Vec3 rot)
{
    const double pi = 3.14159265358979323846;
    double radPitch = rot.x * pi / 180.0;
    double radYaw   = rot.y * pi / 180.0;
    double radRoll  = rot.z * pi / 180.0;

    double SP = sin(radPitch), CP = cos(radPitch);
    double SY = sin(radYaw),   CY = cos(radYaw);
    double SR = sin(radRoll),  CR = cos(radRoll);

    Mat4 m{};
    m.m[0][0] = (float)(CP * CY);
    m.m[0][1] = (float)(CP * SY);
    m.m[0][2] = (float)(SP);

    m.m[1][0] = (float)(SR * SP * CY - CR * SY);
    m.m[1][1] = (float)(SR * SP * SY + CR * CY);
    m.m[1][2] = (float)(-SR * CP);

    m.m[2][0] = (float)(-(CR * SP * CY + SR * SY));
    m.m[2][1] = (float)(CY * SR - CR * SP * SY);
    m.m[2][2] = (float)(CR * CP);

    m.m[3][3] = 1.0f;
    return m;
}

static Mat4 TransformToMatrix(const FTransform& t)
{
    Mat4 m{};
    m.m[3][0] = (float)t.translation.x;
    m.m[3][1] = (float)t.translation.y;
    m.m[3][2] = (float)t.translation.z;

    const FQuat& q = t.rot;
    float x2 = (float)(q.x + q.x), y2 = (float)(q.y + q.y), z2 = (float)(q.z + q.z);
    float xx2 = (float)(q.x * x2), yy2 = (float)(q.y * y2), zz2 = (float)(q.z * z2);
    float yz2 = (float)(q.y * z2), wx2 = (float)(q.w * x2);
    float xy2 = (float)(q.x * y2), wz2 = (float)(q.w * z2);
    float xz2 = (float)(q.x * z2), wy2 = (float)(q.w * y2);

    m.m[0][0] = (float)((1.0 - (yy2 + zz2)) * t.scale.x);
    m.m[1][1] = (float)((1.0 - (xx2 + zz2)) * t.scale.y);
    m.m[2][2] = (float)((1.0 - (xx2 + yy2)) * t.scale.z);

    m.m[1][2] = (yz2 - wx2) * (float)t.scale.z;
    m.m[2][1] = (yz2 + wx2) * (float)t.scale.y;
    m.m[2][0] = (xy2 - wz2) * (float)t.scale.y;
    m.m[0][1] = (xy2 + wz2) * (float)t.scale.x;
    m.m[1][0] = (xz2 + wy2) * (float)t.scale.z;
    m.m[0][2] = (xz2 - wy2) * (float)t.scale.x;

    m.m[3][3] = 1.0f;
    return m;
}

static Mat4 Mul(const Mat4& a, const Mat4& b)
{
    Mat4 o{};
    for (int r = 0; r < 4; ++r)
        for (int c = 0; c < 4; ++c) {
            float s = 0.f;
            for (int k = 0; k < 4; ++k)
                s += a.m[r][k] * b.m[k][c];
            o.m[r][c] = s;
        }
    return o;
}

/* ------------------------------------------------------------------ camera */

struct Camera {
    Vec3  location{};
    Vec3  rotation{};
    float fov = 90.f;
};

static bool Project(const Vec3& world, const Camera& cam, int w, int h, Vec2& out)
{
    if (cam.fov < 1.f || cam.fov > 179.f)
        return false;

    Mat4 axis = MatrixFromRotation(cam.rotation);
    Vec3 axX{ axis.m[0][0], axis.m[0][1], axis.m[0][2] };
    Vec3 axY{ axis.m[1][0], axis.m[1][1], axis.m[1][2] };
    Vec3 axZ{ axis.m[2][0], axis.m[2][1], axis.m[2][2] };

    Vec3 delta{ world.x - cam.location.x, world.y - cam.location.y, world.z - cam.location.z };
    Vec3 t{
        delta.x * axY.x + delta.y * axY.y + delta.z * axY.z,
        delta.x * axZ.x + delta.y * axZ.y + delta.z * axZ.z,
        delta.x * axX.x + delta.y * axX.y + delta.z * axX.z
    };

    if (t.z < 1.0)
        return false;

    const double pi = 3.14159265358979323846;
    float focal = (float)((w / 2.0) / tan(cam.fov * pi / 360.0));

    out.x = (float)(w / 2.0) + (float)t.x * focal / (float)t.z;
    out.y = (float)(h / 2.0) - (float)t.y * focal / (float)t.z;
    return out.x > -4000.f && out.x < w + 4000.f && out.y > -4000.f && out.y < h + 4000.f;
}

/* -------------------------------------------------------------------- util */

static void Log(const char* fmt, ...)
{
    char buf[512];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(buf, sizeof(buf), fmt, ap);
    va_end(ap);

    SYSTEMTIME st;
    GetLocalTime(&st);
    char line[600];
    snprintf(line, sizeof(line), "[%02d:%02d:%02d] %s", st.wHour, st.wMinute, st.wSecond, buf);

    g_log.push_back(line);
    if (g_log.size() > 200)
        g_log.erase(g_log.begin());

    if (g_logBox) {
        std::string all;
        for (auto& s : g_log) { all += s; all += "\r\n"; }
        SetWindowTextA(g_logBox, all.c_str());
        SendMessageA(g_logBox, EM_LINESCROLL, 0, 0x7FFF);
    }
}

static bool Plausible(uint64_t p)
{
    p &= ~1ull;
    return p > 0x10000 && p < 0x00007FFFFFFFFFFFull;
}

static DWORD FindGamePid()
{
    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (snap == INVALID_HANDLE_VALUE)
        return 0;

    PROCESSENTRY32W pe{ sizeof(pe) };
    DWORD pid = 0;
    if (Process32FirstW(snap, &pe)) {
        do {
            if (_wcsicmp(pe.szExeFile, L"FortniteClient-Win64-Shipping.exe") == 0) {
                pid = pe.th32ProcessID;
                break;
            }
        } while (Process32NextW(snap, &pe));
    }
    CloseHandle(snap);
    return pid;
}

struct FindCtx { DWORD pid; HWND wnd; };

static BOOL CALLBACK EnumWindowsProc(HWND hwnd, LPARAM lp)
{
    FindCtx* ctx = (FindCtx*)lp;
    DWORD pid = 0;
    GetWindowThreadProcessId(hwnd, &pid);
    if (pid == ctx->pid && IsWindowVisible(hwnd) && GetWindow(hwnd, GW_OWNER) == nullptr) {
        RECT rc{};
        GetClientRect(hwnd, &rc);
        if (rc.right > 200 && rc.bottom > 200) {
            ctx->wnd = hwnd;
            return FALSE;
        }
    }
    return TRUE;
}

static HWND FindGameWindow(DWORD pid)
{
    FindCtx ctx{ pid, nullptr };
    EnumWindows(EnumWindowsProc, (LPARAM)&ctx);
    return ctx.wnd;
}

/* ------------------------------------------------------------- game reads */

static uint64_t Read64(uint64_t va)          { return hv::ReadOr<uint64_t>(g_cr3, va, 0); }
static uint32_t Read32(uint64_t va)          { return hv::ReadOr<uint32_t>(g_cr3, va, 0); }

static bool ReadMemory(uint64_t va, void* dst, size_t n)
{
    return hv::ReadRaw(g_cr3, va, dst, n);
}

static uint64_t DecryptGWorld(uint64_t stored)
{
    /* bswap64 then add key, per the dump this build uses */
    uint32_t lo = (uint32_t)stored, hi = (uint32_t)(stored >> 32);
    auto sw = [](uint32_t v) {
        return (v << 24) | ((v << 8) & 0x00FF0000u) | ((v >> 8) & 0x0000FF00u) | (v >> 24);
    };
    uint64_t bswapped = ((uint64_t)sw(lo) << 32) | sw(hi);
    return bswapped + off::GWorldKey;
}

static bool ReadCamera(uint64_t world, Camera& cam, uint64_t& localPawn)
{
    uint64_t gi = Read64(world + off::OwningGameInstance);
    if (!Plausible(gi)) return false;

    uint64_t arr = Read64(gi + off::GameInstanceLocalPlayers);
    if (!Plausible(arr)) return false;

    uint64_t lp = Read64(arr);
    if (!Plausible(lp)) return false;

    uint64_t pc = Read64(lp + off::LocalPlayerController);
    if (!Plausible(pc)) return false;

    localPawn = Read64(pc + off::PlayerControllerPawn);

    uint64_t pcm = Read64(pc + off::PlayerControllerCamera);
    if (!Plausible(pcm)) return false;

    /* CameraCachePrivate is an inline FCameraCacheEntry inside the camera
     * manager, not a pointer to one: dereferencing it read the low half of a
     * float Timestamp as an address and failed the plausibility check on every
     * single frame. */
    uint64_t pov = pcm + off::CameraCachePrivate + off::CameraPovOffset;
    if (!ReadMemory(pov + off::PovLocation, &cam.location, sizeof(cam.location))) return false;
    if (!ReadMemory(pov + off::PovRotation, &cam.rotation, sizeof(cam.rotation))) return false;
    if (!ReadMemory(pov + off::PovFov, &cam.fov, sizeof(cam.fov))) return false;

    return std::isfinite(cam.location.x) && std::isfinite(cam.fov);
}

/* World matrix of a component, built from its public RelativeLocation and
 * RelativeRotation plus its parent's world matrix.  Row-vector convention, as
 * used throughout this file: world = local * parent.
 *
 * USceneComponent::ComponentToWorld would give this directly, but it is private
 * and absent from the reflection dump, and USceneComponent is only 0x240 bytes
 * (UPrimitiveComponent starts there), so there is nothing to read at all.  Both
 * components we need this for - an actor's root, and the character mesh
 * attached to it - expose the relative transform publicly, which is enough. */
static bool ComponentWorldMatrix(uint64_t comp, const Mat4* parentWorld, Mat4& out)
{
    Vec3 loc{}, rot{};

    if (!Plausible(comp))
        return false;
    if (!ReadMemory(comp + off::ComponentLocation, &loc, sizeof(loc)))
        return false;
    if (!ReadMemory(comp + off::ComponentRotation, &rot, sizeof(rot)))
        return false;
    if (!std::isfinite(loc.x) || !std::isfinite(loc.y) || !std::isfinite(loc.z) ||
        !std::isfinite(rot.x) || !std::isfinite(rot.y) || !std::isfinite(rot.z))
        return false;

    Mat4 local = MatrixFromRotation(rot);
    local.m[3][0] = (float)loc.x;
    local.m[3][1] = (float)loc.y;
    local.m[3][2] = (float)loc.z;

    out = parentWorld ? Mul(local, *parentWorld) : local;
    return true;
}

/* Component-space bone transform composed with the mesh's world matrix.  The
 * array must be CachedComponentSpaceTransforms: CachedBoneSpaceTransforms are
 * relative to each bone's parent, so combining one of those with the mesh
 * transform would put the "head" near the neck instead of on the head. */
static bool ReadBoneMatrix(uint64_t mesh, int bone, const Mat4& meshWorld, Mat4& out)
{
    if (bone < 0)
        return false;

    /* MeshBoneArray is a TArray<FTransform>, so its header sits at
     * mesh+MeshBoneArray: element pointer first, element count 8 bytes later -
     * the same layout the actor list uses below.  The count used to be read off
     * the element pointer instead (bones+8), which lands inside the first
     * bone's rotation and made this guard meaningless: depending on whatever
     * float happened to sit there it either passed an out-of-range index or
     * rejected valid bones, silently dropping the skeleton. */
    uint64_t bones = Read64(mesh + off::MeshBoneArray);
    int32_t  count = (int32_t)Read32(mesh + off::MeshBoneArray + 8);
    if (!Plausible(bones) || count <= 0 || bone >= count)
        return false;

    FTransform bt{};
    if (!ReadMemory(bones + bone * off::BoneStride, &bt, sizeof(bt)))
        return false;

    out = Mul(TransformToMatrix(bt), meshWorld);
    return true;
}

/* ------------------------------------------------------------------ actors */

struct Player {
    Vec3  feet{};
    Vec3  head{};
    float distance = 0.f;
    int   team     = -1;
    bool  hasBones = false;      /* bones[0] (head) resolved: box top is exact  */
    bool  boneOk[8]{};           /* per bone, so one stale id costs one segment */
    Mat4  bones[8];
    int   boneIdx[8];
};

static const int kBoneIds[8] = {
    68,   /* head        */
    67,   /* neck        */
    7,    /* pelvis/hip  */
    9,    /* left upper  */
    38,   /* right upper */
    78,   /* right thigh */
    71,   /* left thigh  */
    2     /* root        */
};

/* ------------------------------------------------------------------ render */

static HDC      g_memDC   = nullptr;
static HBITMAP  g_memBmp  = nullptr;
static int      g_bmpW    = 0, g_bmpH = 0;
static HBRUSH   g_bgBrush = nullptr;

static void EnsureBackbuffer(HDC refDC, int w, int h)
{
    if (g_memDC && g_bmpW == w && g_bmpH == h)
        return;

    if (g_memBmp) { DeleteObject(g_memBmp); g_memBmp = nullptr; }
    if (g_memDC)  { DeleteDC(g_memDC); g_memDC = nullptr; }

    g_memDC = CreateCompatibleDC(refDC);
    BITMAPINFO bi{};
    bi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    bi.bmiHeader.biWidth = w;
    bi.bmiHeader.biHeight = -h;
    bi.bmiHeader.biPlanes = 1;
    bi.bmiHeader.biBitCount = 32;
    bi.bmiHeader.biCompression = BI_RGB;
    void* bits = nullptr;
    g_memBmp = CreateDIBSection(refDC, &bi, DIB_RGB_COLORS, &bits, nullptr, 0);
    SelectObject(g_memDC, g_memBmp);
    g_bmpW = w;
    g_bmpH = h;

    if (!g_bgBrush)
        g_bgBrush = CreateSolidBrush(RGB(1, 1, 1));
}

static void DrawESP(HDC dc, int w, int h)
{
    if (!g_cr3 || !g_base)
        return;

    uint64_t stored = Read64(g_base + off::GWorldRva);
    if (!stored)
        return;
    uint64_t world = DecryptGWorld(stored);
    if (!Plausible(world))
        return;

    Camera cam;
    uint64_t localPawn = 0;
    if (!ReadCamera(world, cam, localPawn))
        return;

    /* The local player's team, read from the same field we read on every actor
     * so the two values are always comparable.  If it does not read back
     * sanely the filter stays off and everyone is drawn - never nobody. */
    uint32_t localTeam   = 0;
    bool     localTeamOk = false;
    if (Plausible(localPawn)) {
        uint64_t lps = Read64(localPawn + off::ActorPlayerState);
        uint8_t  lt  = 0;
        if (Plausible(lps) &&
            ReadMemory(lps + off::PlayerStateTeamIndex, &lt, sizeof(lt))) {
            localTeam   = lt;
            localTeamOk = true;
        }
    }

    uint64_t level = Read64(world + off::PersistentLevel);
    if (!Plausible(level))
        return;

    uint64_t actors = Read64(level + off::LevelActors);
    int32_t  count  = (int32_t)Read32(level + off::LevelActorsCount);
    if (!Plausible(actors) || count <= 0 || count > 20000)
        return;

    if (count > off::MaxActors)
        count = off::MaxActors;

    std::vector<uint64_t> list((size_t)count);
    if (!ReadMemory(actors, list.data(), list.size() * sizeof(uint64_t)))
        return;

    HPEN penBox  = CreatePen(PS_SOLID, 1, RGB(255, 80, 80));
    HPEN penBone = CreatePen(PS_SOLID, 1, RGB(255, 255, 255));
    HPEN penLine = CreatePen(PS_SOLID, 1, RGB(255, 80, 80));
    HPEN penRing = CreatePen(PS_SOLID, 1, RGB(90, 90, 90));
    HGDIOBJ oldPen = SelectObject(dc, penBox);
    HGDIOBJ oldBrush = SelectObject(dc, GetStockObject(NULL_BRUSH));
    SetBkMode(dc, TRANSPARENT);

    int focalRadius = g_cfg.fovRadius;
    if (focalRadius <= 0)
        focalRadius = (int)((h / 2.0) / tan(cam.fov * 3.14159265358979 / 360.0) * tan(45.0 * 3.14159265358979 / 360.0));

    if (g_cfg.fovRing) {
        SelectObject(dc, penRing);
        Ellipse(dc, w / 2 - focalRadius, h / 2 - focalRadius, w / 2 + focalRadius, h / 2 + focalRadius);
    }

    int drawn = 0;

    for (int i = 0; i < count; ++i) {
        uint64_t actor = list[(size_t)i];
        if (!Plausible(actor) || actor == localPawn)
            continue;

        uint64_t ps = Read64(actor + off::ActorPlayerState);
        if (!Plausible(ps))
            continue;

        uint64_t root = Read64(actor + off::ActorRootComponent);
        if (!Plausible(root))
            continue;

        Vec3 pos{};
        if (!ReadMemory(root + off::ComponentLocation, &pos, sizeof(pos)))
            continue;
        if (!std::isfinite(pos.x) || !std::isfinite(pos.y) || !std::isfinite(pos.z))
            continue;
        if (pos.x == 0.0 && pos.y == 0.0 && pos.z == 0.0)
            continue;

        double dx = pos.x - cam.location.x;
        double dy = pos.y - cam.location.y;
        double dz = pos.z - cam.location.z;
        float dist = (float)(sqrt(dx * dx + dy * dy + dz * dz) / off::UnitToMetres);
        if (dist < 1.f || dist > (float)g_cfg.maxDist)
            continue;

        uint8_t team = hv::ReadOr<uint8_t>(g_cr3, ps + off::PlayerStateTeamIndex, 0);

        /* Team-mates were drawn as enemies: the team was read only to pick a
         * colour, so this option filtered nothing at all. */
        if (!g_cfg.showTeammates && localTeamOk && (uint32_t)team == localTeam)
            continue;

        Player p{};
        p.feet = pos;
        p.distance = dist;
        p.team = team;

        /* The mesh is attached to the actor's root component, so its world
         * matrix is the mesh's own relative transform composed with the root's.
         * For a character the root has no attach parent, so its relative
         * transform *is* its world transform. */
        Mat4 rootWorld{};
        bool haveRoot = ComponentWorldMatrix(root, nullptr, rootWorld);

        uint64_t mesh = Read64(actor + off::ActorMesh);
        if (haveRoot && Plausible(mesh)) {
            Mat4 meshWorld{};
            if (ComponentWorldMatrix(mesh, &rootWorld, meshWorld)) {
                /* Resolve each bone on its own.  All-or-nothing meant one stale
                 * bone id cost the whole skeleton *and* the exact head position,
                 * dropping the box back to the crude 88-unit guess. */
                for (int b = 0; b < 8; ++b) {
                    p.boneIdx[b] = kBoneIds[b];
                    p.boneOk[b]  = ReadBoneMatrix(mesh, kBoneIds[b], meshWorld, p.bones[b]);
                }
            }
            p.hasBones = p.boneOk[0];
        }

        /* A stale bone array or a bad component transform yields a head that is
         * nowhere near the actor.  Rejecting it here and falling back to the
         * crude height keeps the box on screen, instead of letting a nonsense
         * head collapse boxH and drop the player out of the ESP entirely. */
        Vec3 headPos = pos;
        bool headOk = false;
        if (p.boneOk[0]) {
            Vec3 hb{ p.bones[0].m[3][0], p.bones[0].m[3][1], p.bones[0].m[3][2] };
            double hx = hb.x - pos.x, hy = hb.y - pos.y, hz = hb.z - pos.z;
            double dh = sqrt(hx * hx + hy * hy + hz * hz);
            if (std::isfinite(dh) && dh > 10.0 && dh < 400.0) {
                headPos = hb;
                headOk  = true;
            } else {
                p.hasBones = false;   /* the skeleton would be nonsense too */
            }
        }
        if (!headOk)
            headPos.z += 88.0;

        Vec2 feet2, head2;
        if (!Project(pos, cam, w, h, feet2))
            continue;
        if (!Project(headPos, cam, w, h, head2))
            continue;

        float boxH = feet2.y - head2.y;
        if (boxH < 6.f || boxH > h * 2.f)
            continue;
        float boxW = boxH * 0.42f;

        COLORREF col = RGB(255, 80, 80);
        if (team != 0)
            col = RGB(255, 170, 60);

        HPEN use = CreatePen(PS_SOLID, 1, col);

        if (g_cfg.box2d) {
            SelectObject(dc, use);
            Rectangle(dc, (int)(head2.x - boxW / 2), (int)head2.y,
                          (int)(head2.x + boxW / 2), (int)feet2.y);
        }

        if (g_cfg.corner) {
            SelectObject(dc, use);
            float cx = head2.x, top = head2.y, bot = feet2.y;
            float cw = boxW / 2, ch = boxH * 0.22f;
            MoveToEx(dc, (int)(cx - cw), (int)top, nullptr);      LineTo(dc, (int)(cx - cw + boxW * 0.25f), (int)top);
            MoveToEx(dc, (int)(cx + cw), (int)top, nullptr);      LineTo(dc, (int)(cx + cw - boxW * 0.25f), (int)top);
            MoveToEx(dc, (int)(cx - cw), (int)top, nullptr);      LineTo(dc, (int)(cx - cw), (int)(top + ch));
            MoveToEx(dc, (int)(cx + cw), (int)top, nullptr);      LineTo(dc, (int)(cx + cw), (int)(top + ch));
            MoveToEx(dc, (int)(cx - cw), (int)bot, nullptr);      LineTo(dc, (int)(cx - cw + boxW * 0.25f), (int)bot);
            MoveToEx(dc, (int)(cx + cw), (int)bot, nullptr);      LineTo(dc, (int)(cx + cw - boxW * 0.25f), (int)bot);
            MoveToEx(dc, (int)(cx - cw), (int)bot, nullptr);      LineTo(dc, (int)(cx - cw), (int)(bot - ch));
            MoveToEx(dc, (int)(cx + cw), (int)bot, nullptr);      LineTo(dc, (int)(cx + cw), (int)(bot - ch));
        }

        if (g_cfg.snapline) {
            SelectObject(dc, penLine);
            MoveToEx(dc, w / 2, h / 2, nullptr);
            LineTo(dc, (int)head2.x, (int)feet2.y);
        }

        if (g_cfg.skeleton && p.hasBones) {
            Vec2 pts[8];
            bool valid[8];
            for (int b = 0; b < 8; ++b) {
                if (!p.boneOk[b]) { valid[b] = false; continue; }
                Vec3 wp{ p.bones[b].m[3][0], p.bones[b].m[3][1], p.bones[b].m[3][2] };
                valid[b] = Project(wp, cam, w, h, pts[b]);
            }
            SelectObject(dc, penBone);
            /* head-neck, neck-pelvis, pelvis-knees, pelvis-shoulders */
            if (valid[0] && valid[1]) { MoveToEx(dc, (int)pts[0].x, (int)pts[0].y, nullptr); LineTo(dc, (int)pts[1].x, (int)pts[1].y); }
            if (valid[1] && valid[2]) { MoveToEx(dc, (int)pts[1].x, (int)pts[1].y, nullptr); LineTo(dc, (int)pts[2].x, (int)pts[2].y); }
            if (valid[2] && valid[5]) { MoveToEx(dc, (int)pts[2].x, (int)pts[2].y, nullptr); LineTo(dc, (int)pts[5].x, (int)pts[5].y); }
            if (valid[2] && valid[6]) { MoveToEx(dc, (int)pts[2].x, (int)pts[2].y, nullptr); LineTo(dc, (int)pts[6].x, (int)pts[6].y); }
            if (valid[1] && valid[3]) { MoveToEx(dc, (int)pts[1].x, (int)pts[1].y, nullptr); LineTo(dc, (int)pts[3].x, (int)pts[3].y); }
            if (valid[1] && valid[4]) { MoveToEx(dc, (int)pts[1].x, (int)pts[1].y, nullptr); LineTo(dc, (int)pts[4].x, (int)pts[4].y); }
            if (valid[3] && valid[4]) { MoveToEx(dc, (int)pts[3].x, (int)pts[3].y, nullptr); LineTo(dc, (int)pts[4].x, (int)pts[4].y); }
        }

        if (g_cfg.distance) {
            char txt[32];
            snprintf(txt, sizeof(txt), "%dm", (int)dist);
            SetTextColor(dc, col);
            TextOutA(dc, (int)(head2.x + boxW / 2 + 4), (int)head2.y, txt, (int)strlen(txt));
        }

        DeleteObject(use);
        ++drawn;
    }

    SelectObject(dc, oldPen);
    SelectObject(dc, oldBrush);
    DeleteObject(penBox);
    DeleteObject(penBone);
    DeleteObject(penLine);
    DeleteObject(penRing);
    (void)drawn;
}

static void RenderOverlay()
{
    if (!g_overlay || !g_gameWnd || !IsWindowVisible(g_gameWnd))
        return;

    RECT rc{};
    if (!GetClientRect(g_gameWnd, &rc))
        return;
    POINT tl{ rc.left, rc.top };
    ClientToScreen(g_gameWnd, &tl);

    int w = rc.right - rc.left;
    int h = rc.bottom - rc.top;
    if (w < 8 || h < 8)
        return;

    RECT cur{};
    GetWindowRect(g_overlay, &cur);
    if (cur.left != tl.x || cur.top != tl.y ||
        (cur.right - cur.left) != w || (cur.bottom - cur.top) != h) {
        SetWindowPos(g_overlay, HWND_TOPMOST, tl.x, tl.y, w, h, SWP_NOACTIVATE);
    }

    HDC screen = GetDC(nullptr);
    EnsureBackbuffer(screen, w, h);
    ReleaseDC(nullptr, screen);

    if (!g_memDC)
        return;

    RECT full{ 0, 0, w, h };
    FillRect(g_memDC, &full, g_bgBrush);
    DrawESP(g_memDC, w, h);

    HDC odc = GetDC(g_overlay);
    BitBlt(odc, 0, 0, w, h, g_memDC, 0, 0, SRCCOPY);
    ReleaseDC(g_overlay, odc);
}

/* -------------------------------------------------------------------- hwnd */

static LRESULT CALLBACK OverlayProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp)
{
    switch (msg) {
    case WM_ERASEBKGND:
        return 1;
    case WM_TIMER:
        return 0;
    case WM_LBUTTONDOWN:
        return 0;
    }
    return DefWindowProcA(hwnd, msg, wp, lp);
}

static void CreateOverlay()
{
    if (g_overlay)
        return;

    WNDCLASSA wc{};
    wc.lpfnWndProc = OverlayProc;
    wc.hInstance = GetModuleHandleA(nullptr);
    wc.lpszClassName = "HvFnOverlay";
    RegisterClassA(&wc);

    g_overlay = CreateWindowExA(
        WS_EX_TOPMOST | WS_EX_LAYERED | WS_EX_TRANSPARENT | WS_EX_TOOLWINDOW | WS_EX_NOACTIVATE,
        "HvFnOverlay", "", WS_POPUP,
        0, 0, 100, 100, nullptr, nullptr, wc.hInstance, nullptr);

    if (!g_overlay)
        return;

    SetLayeredWindowAttributes(g_overlay, RGB(1, 1, 1), 0, LWA_COLORKEY);
    ShowWindow(g_overlay, SW_SHOWNOACTIVATE);
    /* repaints are driven by the menu timer so there is exactly one frame loop */
    g_overlayOn = true;
}

static void DestroyOverlay()
{
    if (!g_overlay)
        return;
    KillTimer(g_overlay, 1);
    DestroyWindow(g_overlay);
    g_overlay = nullptr;
    g_overlayOn = false;
    if (g_memBmp) { DeleteObject(g_memBmp); g_memBmp = nullptr; }
    if (g_memDC)  { DeleteDC(g_memDC); g_memDC = nullptr; }
    g_bmpW = g_bmpH = 0;
}

/* ------------------------------------------------------------------- state */

/* -1 = unknown (not elevated), 0 = no boot entry, 1 = installed */
static int   g_installState = -1;
static DWORD g_recheckAt = 0;

static int ProbeInstall(bool logIt)
{
    if (!inst::IsElevated()) {
        g_installState = -1;
        if (logIt)
            Log("not elevated: cannot verify the ESP/BCD state (Install asks for UAC)");
        return -1;
    }

    std::string guid;
    if (inst::BootEntryExists(guid)) {
        g_installState = 1;
        if (logIt)
            Log("payload installed (%s) - reboot to load it", guid.c_str());
        return 1;
    }

    g_installState = 0;
    if (logIt)
        Log("payload not installed - press Install");
    return 0;
}

static void UpdateStatus()
{    char buf[512];
    const char* hvState = g_hvReady ? "resident" : "not loaded";
    if (g_cr3)
        snprintf(buf, sizeof(buf), "Stage-3: %s    target: 0x%llx    cr3: 0x%llx    pid: %lu",
                 hvState, (unsigned long long)g_base, (unsigned long long)g_cr3, g_gamePid);
    else
        snprintf(buf, sizeof(buf), "Stage-3: %s    target: waiting for game", hvState);

    SetWindowTextA(g_status, buf);
}

static bool TryAttach()
{
    if (!g_hvReady)
        return false;

    DWORD pid = FindGamePid();
    if (!pid)
        return false;

    /* A different process than the one we cached: make the hypervisor forget
     * the old CR3 before asking again. */
    if (g_gamePid && g_gamePid != pid) {
        hv::FlushTarget();
        g_cr3 = g_base = 0;
        g_peb = 0;
    }

    uint64_t cr3 = 0, base = 0, peb = 0;
    int st = hv::Resolve(0, &cr3, &base, &peb);
    if (st == HV_OK) {
        g_cr3 = cr3;
        g_base = base;
        g_peb = peb;
        g_gamePid = pid;
        g_gameWnd = FindGameWindow(pid);
        Log("resolved game: base 0x%llx cr3 0x%llx peb 0x%llx",
            (unsigned long long)base, (unsigned long long)cr3, (unsigned long long)peb);
        UpdateStatus();
        return true;
    }
    return false;
}

static LRESULT CALLBACK MenuProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp)
{
    switch (msg) {
    case WM_CREATE:
        g_status = CreateWindowA("STATIC", "starting...", WS_CHILD | WS_VISIBLE,
                                 12, 10, 580, 18, hwnd, nullptr, nullptr, nullptr);
        CreateWindowA("BUTTON", "Attach", WS_CHILD | WS_VISIBLE, 12, 34, 90, 26,
                      hwnd, (HMENU)1, nullptr, nullptr);
        CreateWindowA("BUTTON", "Overlay", WS_CHILD | WS_VISIBLE, 108, 34, 90, 26,
                      hwnd, (HMENU)2, nullptr, nullptr);
        CreateWindowA("BUTTON", "Install", WS_CHILD | WS_VISIBLE, 204, 34, 90, 26,
                      hwnd, (HMENU)4, nullptr, nullptr);
        CreateWindowA("BUTTON", "Uninstall", WS_CHILD | WS_VISIBLE, 300, 34, 90, 26,
                      hwnd, (HMENU)5, nullptr, nullptr);
        CreateWindowA("BUTTON", "Clear log", WS_CHILD | WS_VISIBLE, 396, 34, 90, 26,
                      hwnd, (HMENU)3, nullptr, nullptr);
        CreateWindowA("BUTTON", "Arm + Reboot", WS_CHILD | WS_VISIBLE, 492, 34, 100, 26,
                      hwnd, (HMENU)6, nullptr, nullptr);

        CreateWindowA("BUTTON", "2D box", WS_CHILD | WS_VISIBLE | BS_AUTOCHECKBOX, 12, 72, 100, 20,
                      hwnd, (HMENU)10, nullptr, nullptr);
        CreateWindowA("BUTTON", "Corner box", WS_CHILD | WS_VISIBLE | BS_AUTOCHECKBOX, 120, 72, 100, 20,
                      hwnd, (HMENU)11, nullptr, nullptr);
        CreateWindowA("BUTTON", "Skeleton", WS_CHILD | WS_VISIBLE | BS_AUTOCHECKBOX, 228, 72, 100, 20,
                      hwnd, (HMENU)12, nullptr, nullptr);
        CreateWindowA("BUTTON", "Snapline", WS_CHILD | WS_VISIBLE | BS_AUTOCHECKBOX, 336, 72, 100, 20,
                      hwnd, (HMENU)13, nullptr, nullptr);
        CreateWindowA("BUTTON", "Distance", WS_CHILD | WS_VISIBLE | BS_AUTOCHECKBOX, 12, 96, 100, 20,
                      hwnd, (HMENU)14, nullptr, nullptr);
        CreateWindowA("BUTTON", "FOV ring", WS_CHILD | WS_VISIBLE | BS_AUTOCHECKBOX, 120, 96, 100, 20,
                      hwnd, (HMENU)15, nullptr, nullptr);
        CreateWindowA("BUTTON", "Show teammates", WS_CHILD | WS_VISIBLE | BS_AUTOCHECKBOX, 228, 96, 140, 20,
                      hwnd, (HMENU)16, nullptr, nullptr);

        CheckDlgButton(hwnd, 10, g_cfg.box2d ? BST_CHECKED : BST_UNCHECKED);
        CheckDlgButton(hwnd, 11, g_cfg.corner ? BST_CHECKED : BST_UNCHECKED);
        CheckDlgButton(hwnd, 12, g_cfg.skeleton ? BST_CHECKED : BST_UNCHECKED);
        CheckDlgButton(hwnd, 13, g_cfg.snapline ? BST_CHECKED : BST_UNCHECKED);
        CheckDlgButton(hwnd, 14, g_cfg.distance ? BST_CHECKED : BST_UNCHECKED);
        CheckDlgButton(hwnd, 15, g_cfg.fovRing ? BST_CHECKED : BST_UNCHECKED);
        CheckDlgButton(hwnd, 16, g_cfg.showTeammates ? BST_CHECKED : BST_UNCHECKED);

        g_logBox = CreateWindowA("EDIT", "", WS_CHILD | WS_VISIBLE | WS_VSCROLL | ES_MULTILINE |
                                 ES_READONLY | ES_AUTOVSCROLL,
                                 12, 126, 580, 230, hwnd, nullptr, nullptr, nullptr);

        SetTimer(hwnd, 1, 1000, nullptr);
        SetTimer(hwnd, 2, 16, nullptr);
        Log("HvFn launcher up (%s)", inst::IsElevated() ? "elevated" : "NOT elevated - install/arm need UAC");
        {
            uint64_t build = 0;
            uint32_t rev = 0;
            int st = hv::Ping(&build, &rev);
            if (st == HV_OK) {
                g_hvReady = true;
                Log("Stage-3 resident, build 0x%llx vmx rev 0x%x",
                    (unsigned long long)build, rev);

                /* Running under the hypervisor means the boot completed; clear
                 * the failed-boot counter so the guard never trips. */
                if (inst::IsElevated()) {
                    std::string err;
                    if (inst::ResetCounter(err))
                        Log("failed-boot counter cleared");
                    else
                        Log("counter reset skipped: %s", err.c_str());
                }
            } else {
                g_hvReady = false;
                Log("Stage-3 not resident (%d) - normal until the machine has rebooted into it", st);
                ProbeInstall(true);
            }
        }
        UpdateStatus();

        /* The payload appends one line per step to trace.txt before anything
         * risky.  After a freeze, the last line says exactly where it died. */
        if (inst::IsElevated()) {
            std::string tr, terr;
            if (inst::ReadTrace(tr, terr)) {
                std::vector<std::string> lines;
                size_t pos = 0;
                while (pos < tr.size()) {
                    size_t eol = tr.find('\n', pos);
                    if (eol == std::string::npos) eol = tr.size();
                    std::string ln = tr.substr(pos, eol - pos);
                    while (!ln.empty() && (ln.back() == '\r' || ln.back() == ' '))
                        ln.pop_back();
                    if (!ln.empty()) lines.push_back(ln);
                    pos = eol + 1;
                }
                size_t start = lines.size() > 10 ? lines.size() - 10 : 0;
                Log("--- trace from the last boot ---");
                for (size_t i = start; i < lines.size(); ++i)
                    Log("  %s", lines[i].c_str());
                Log("--- end trace ---");
            } else {
                Log("trace unavailable: %s", terr.c_str());
            }

            /* When the entry is missing or invisible, show what firmware has. */
            if (!g_hvReady && !g_cr3) {
                std::string fw, ferr;
                if (inst::DumpFirmware(fw, ferr)) {
                    size_t pos = 0;
                    int shown = 0;
                    Log("--- firmware entries ---");
                    while (pos < fw.size() && shown < 24) {
                        size_t eol = fw.find('\n', pos);
                        if (eol == std::string::npos) eol = fw.size();
                        std::string ln = fw.substr(pos, eol - pos);
                        pos = eol + 1;
                        while (!ln.empty() && (ln.back() == '\r' || ln.back() == ' '))
                            ln.pop_back();
                        if (ln.find("identifier") == 0 || ln.find("description") == 0 ||
                            ln.find("path") == 0 || ln.find("Boot") == 0) {
                            Log("  %s", ln.c_str());
                            ++shown;
                        }
                    }
                    Log("--- end firmware ---");
                } else {
                    Log("firmware enumeration failed: %s", ferr.c_str());
                }
            }
        }

        return 0;

    case WM_TIMER:
        if (wp == 1) {
            if (g_recheckAt && GetTickCount() >= g_recheckAt) {
                g_recheckAt = 0;
                ProbeInstall(true);
            }
            if (g_cr3) {
                DWORD pid = FindGamePid();
                if (!pid || pid != g_gamePid) {
                    /* Either the game closed or it was restarted under a new
                     * PID: the cached CR3 belongs to the old process.  Drop it
                     * in the hypervisor too, or Resolve short-circuits on the
                     * stale HV_TARGET_READY forever. */
                    Log(pid ? "game restarted - dropping stale target" : "game exited");
                    hv::FlushTarget();
                    g_cr3 = g_base = 0;
                    g_gamePid = 0;
                    g_gameWnd = nullptr;
                    DestroyOverlay();
                    UpdateStatus();
                }
            } else if (g_hvReady) {
                TryAttach();
            }
        } else if (wp == 2 && g_overlayOn) {
            RenderOverlay();
        }
        return 0;

    case WM_COMMAND:
        switch (LOWORD(wp)) {
        case 1:
            if (!g_hvReady) {
                Log("cannot attach: Stage-3 not resident");
                break;
            }
            if (!TryAttach()) {
                Log("attach failed - is the game in a match / past the lobby?");
            } else {
                CreateOverlay();
                Log("overlay attached");
            }
            break;
        case 2:
            if (g_overlayOn) { DestroyOverlay(); Log("overlay off"); }
            else if (g_cr3) { CreateOverlay(); Log("overlay on"); }
            else Log("attach first");
            break;
        case 3:
            g_log.clear();
            SetWindowTextA(g_logBox, "");
            break;
        case 4: {   /* install the embedded payload */
            if (!inst::IsElevated()) {
                if (MessageBoxA(hwnd, "Installing Stage-3 needs administrator rights.\n"
                                      "Relaunch elevated now?", "HvFn",
                                MB_YESNO | MB_ICONQUESTION) == IDYES) {
                    if (inst::RelaunchElevated("--install")) {
                        Log("elevated installer started - it will show its own result box");
                        g_recheckAt = GetTickCount() + 8000;
                    } else {
                        Log("elevation was cancelled");
                    }
                }
                break;
            }
            std::string err;
            if (inst::Install(err)) {
                Log("installed: payload written to the ESP, boot entry registered");
                ProbeInstall(true);
                if (MessageBoxA(hwnd, "Stage-3 installed.\n\nReboot now to load it?",
                                "HvFn", MB_YESNO | MB_ICONQUESTION) == IDYES)
                    ExitWindowsEx(EWX_REBOOT | EWX_FORCE, SHTDN_REASON_MAJOR_APPLICATION);
            } else {
                Log("install failed: %s", err.c_str());
                MessageBoxA(hwnd, err.c_str(), "HvFn install failed", MB_OK | MB_ICONERROR);
            }
            break;
        }
        case 6: {   /* arm the payload and reboot into it, one click */
            if (!inst::IsElevated()) {
                if (inst::RelaunchElevated("--arm"))
                    Log("elevated instance is staging the payload; the machine will reboot");
                else
                    Log("elevation was cancelled - nothing armed");
                break;
            }

            std::string err;
            Log("arming: writing payload + markers, then rebooting");
            if (!inst::ArmAndReboot(err)) {
                Log("arm failed: %s", err.c_str());
                MessageBoxA(hwnd, err.c_str(), "HvFn arm failed", MB_OK | MB_ICONERROR);
                break;
            }
            Log("armed - machine is rebooting, Stage-3 loads before Windows");
            break;
        }
        case 5: {   /* remove payload + boot entry */
            if (!inst::IsElevated()) {
                if (MessageBoxA(hwnd, "Uninstalling needs administrator rights.\n"
                                      "Relaunch elevated now?", "HvFn",
                                MB_YESNO | MB_ICONQUESTION) == IDYES)
                    inst::RelaunchElevated("--uninstall");
                break;
            }
            std::string err;
            if (inst::Uninstall(err)) {
                Log("uninstalled: boot entry removed, payload deleted from the ESP");
                MessageBoxA(hwnd, "Stage-3 removed. Reboot to boot unvirtualised.",
                            "HvFn", MB_OK | MB_ICONINFORMATION);
            } else {
                Log("uninstall failed: %s", err.c_str());
                MessageBoxA(hwnd, err.c_str(), "HvFn uninstall failed", MB_OK | MB_ICONERROR);
            }
            break;
        }
        case 10: g_cfg.box2d    = IsDlgButtonChecked(hwnd, 10) == BST_CHECKED; break;
        case 11: g_cfg.corner   = IsDlgButtonChecked(hwnd, 11) == BST_CHECKED; break;
        case 12: g_cfg.skeleton = IsDlgButtonChecked(hwnd, 12) == BST_CHECKED; break;
        case 13: g_cfg.snapline = IsDlgButtonChecked(hwnd, 13) == BST_CHECKED; break;
        case 14: g_cfg.distance = IsDlgButtonChecked(hwnd, 14) == BST_CHECKED; break;
        case 15: g_cfg.fovRing  = IsDlgButtonChecked(hwnd, 15) == BST_CHECKED; break;
        case 16: g_cfg.showTeammates = IsDlgButtonChecked(hwnd, 16) == BST_CHECKED; break;
        }
        return 0;

    case WM_CTLCOLORSTATIC:
    case WM_CTLCOLOREDIT: {
        HDC dc = (HDC)wp;
        SetTextColor(dc, RGB(220, 220, 220));
        SetBkColor(dc, RGB(24, 24, 28));
        static HBRUSH br = CreateSolidBrush(RGB(24, 24, 28));
        return (LRESULT)br;
    }

    case WM_DESTROY:
        KillTimer(hwnd, 1);
        KillTimer(hwnd, 2);
        DestroyOverlay();
        PostQuitMessage(0);
        return 0;
    }
    return DefWindowProcA(hwnd, msg, wp, lp);
}

int WINAPI WinMain(HINSTANCE inst, HINSTANCE, LPSTR, int show)
{
    /* Command-line modes: --install / --uninstall / --reset.
     * These are what the GUI buttons shell out to when it is not elevated. */
    {
        const char* cmd = GetCommandLineA();
        const char* action = nullptr;
        if (strstr(cmd, "--uninstall"))     action = "--uninstall";
        else if (strstr(cmd, "--arm"))      action = "--arm";
        else if (strstr(cmd, "--install"))  action = "--install";
        else if (strstr(cmd, "--reset"))    action = "--reset";

        if (action) {
            if (!inst::IsElevated()) {
                inst::RelaunchElevated(action);
                return 0;
            }

            std::string err;
            bool ok;
            if (strcmp(action, "--install") == 0)
                ok = inst::Install(err);
            else if (strcmp(action, "--uninstall") == 0)
                ok = inst::Uninstall(err);
            else if (strcmp(action, "--arm") == 0) {
                ok = inst::ArmAndReboot(err);
                if (ok)   /* the reboot is already in flight */
                    return 0;
            }
            else
                ok = inst::ResetCounter(err);

            std::string msg = ok ? std::string(action) + " succeeded"
                                 : std::string(action) + " failed: " + err;
            MessageBoxA(nullptr, msg.c_str(), "HvFn",
                        MB_OK | (ok ? MB_ICONINFORMATION : MB_ICONERROR));
            return ok ? 0 : 1;
        }
    }

    /* Ask for elevation once so the window can actually report install state:
     * reading BCD and the ESP are admin-only.  The marker argument prevents a
     * relaunch loop when UAC is declined. */
    if (!inst::IsElevated() && !strstr(GetCommandLineA(), "--elevated")) {
        if (inst::RelaunchElevated("--elevated"))
            return 0;
    }

    /* Stage-3 virtualises the boot processor only: every hypercall has to run
     * on CPU 0 or the VMCALL would #UD natively. */
    SetProcessAffinityMask(GetCurrentProcess(), 1);

    WNDCLASSA wc{};
    wc.lpfnWndProc = MenuProc;
    wc.hInstance = inst;
    wc.lpszClassName = "HvFnMenu";
    wc.hbrBackground = CreateSolidBrush(RGB(24, 24, 28));
    wc.hCursor = LoadCursor(nullptr, IDC_ARROW);
    RegisterClassA(&wc);

    g_menu = CreateWindowA("HvFnMenu", "HvFn - Stage-3 ESP",
                           WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX,
                           CW_USEDEFAULT, CW_USEDEFAULT, 620, 410,
                           nullptr, nullptr, inst, nullptr);
    if (!g_menu)
        return 1;

    ShowWindow(g_menu, show);
    UpdateWindow(g_menu);

    MSG msg;
    while (GetMessageA(&msg, nullptr, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessageA(&msg);
    }
    return 0;
}
