/* offsets.h - every number that depends on the Fortnite build lives here.
 *
 * Re-dumped from work\dump\FortniteClient-Win64-Shipping_12-11 (12 Nov 2026) -
 * the GWorld RVA/key below match that dump's own Decrypts\GWorld.hpp exactly,
 * which is what ties these struct offsets to the same image.
 *
 * The previous revision carried UE4-era struct offsets, and three of them were
 * individually fatal: APlayerController was 0x10 low, USceneComponent
 * RelativeLocation was 0x128 instead of 0x140, and CameraCachePrivate was
 * dereferenced as a pointer at 0x1B0 when it is an inline FCameraCacheEntry at
 * 0x15A0.  Any one of those makes the camera read fail and the ESP draw
 * nothing at all.
 *
 * Members that are private in this build do not appear in a reflection dump.
 * Those are marked UNVERIFIED and keep their previous values.
 *
 * After a game update, re-dump these and change nothing else: the ESP code
 * validates every read, so a stale offset degrades to "nothing drawn" rather
 * than a crash.
 */
#pragma once
#include <cstdint>

namespace off {

/* --- module image ------------------------------------------------------- */
/* GWorld is stored obfuscated: real = bswap64(stored) + key.
 * Confirmed against <dump>\Decrypts\GWorld.hpp. */
constexpr uint64_t GWorldRva    = 0x1C9DA790;
constexpr uint64_t GWorldKey    = 0x3F1FCDFB;

/* --- UWorld / ULevel ---------------------------------------------------- */
constexpr uint64_t PersistentLevel  = 0x38;   /* UWorld::PersistentLevel      */
/* UNVERIFIED: ULevel::Actors is private in this build and absent from the
 * dump.  Kept at the classic value; the pair stays self-consistent (the count
 * sits 8 bytes past the data pointer, as for every other TArray here). */
constexpr uint64_t LevelActors      = 0x98;   /* TArray<AActor*>              */
constexpr uint64_t LevelActorsCount = 0xA0;
constexpr uint64_t OwningGameInstance = 0x238; /* UWorld (was 0x1B8)         */
constexpr uint64_t GameInstanceState  = 0x158; /* unused                     */

/* --- engine chain ------------------------------------------------------- */
constexpr uint64_t GameInstanceLocalPlayers = 0x38;  /* UGameInstance        */
constexpr uint64_t LocalPlayerController    = 0x30;  /* UPlayer              */
constexpr uint64_t PlayerControllerPawn     = 0x320; /* AcknowledgedPawn     */
constexpr uint64_t PlayerControllerCamera   = 0x330; /* PlayerCameraManager  */

/* --- camera ------------------------------------------------------------- */
/* Inline FCameraCacheEntry, NOT a pointer: sizeof(FCameraCacheEntry)==0x920,
 * which is exactly the span the dump reports for this member.  Dereferencing
 * it (the old behaviour) read the first 8 bytes of a float Timestamp as an
 * address and always failed the plausibility check. */
constexpr uint64_t CameraCachePrivate = 0x15A0;
constexpr uint64_t CameraPovOffset    = 0x10;  /* FCameraCacheEntry::POV      */
constexpr uint64_t PovLocation        = 0x00;  /* FMinimalViewInfo::Location  */
constexpr uint64_t PovRotation        = 0x18;  /* ::Rotation (LWC FRotator)   */
constexpr uint64_t PovFov             = 0x30;  /* ::FOV                       */

/* --- actors ------------------------------------------------------------- */
constexpr uint64_t ActorRootComponent = 0x1B0;  /* AActor::RootComponent      */
constexpr uint64_t ActorPlayerState   = 0x298;  /* APawn::PlayerState         */
constexpr uint64_t ActorMesh          = 0x2F8;  /* ACharacter::Mesh           */
constexpr uint64_t ComponentLocation  = 0x140;  /* USceneComponent RelativeLoc*/
constexpr uint64_t ComponentRotation  = 0x158;  /* USceneComponent RelativeRot*/

/* --- skeletal mesh ------------------------------------------------------ */
/* USkeletalMeshComponent::CachedComponentSpaceTransforms.  These are relative
 * to the component, which is what UE's own GetBoneMatrix composes with the
 * component transform.  The sibling CachedBoneSpaceTransforms (0xA30) are
 * relative to each bone's PARENT, so using them here yields a position near the
 * bone's parent rather than the bone itself. */
constexpr uint64_t MeshBoneArray = 0xA40;
/* NOTE: there is deliberately no MeshComponentToWorld offset.
 * USceneComponent::ComponentToWorld is private and does not appear in a
 * reflection dump, and the class is only 0x240 bytes (UPrimitiveComponent
 * starts there), so the old 0x240 read landed past the end of the class in the
 * subclass.  The mesh's world transform is instead composed from the two
 * public members above - the actor root's relative transform and the mesh's
 * own - by ComponentWorldMatrix() in main.cpp. */
constexpr uint64_t BoneStride   = 0x60; /* sizeof(FTransform)==0x60            */

/* --- player state ------------------------------------------------------- */
/* Team lives on the player state, not the pawn.  AFortPlayerStateAthena::
 * TeamIndex is a uint8 at 0xF81.  The old ActorTeamId (0x10B0, read off the
 * actor) produced garbage, so the team filter could never have worked. */
constexpr uint64_t PlayerStateTeamIndex = 0xF81;
constexpr uint64_t PlayerStatePawn      = 0x2A8; /* UNVERIFIED               */
constexpr uint64_t PlayerStateName      = 0x000; /* FString; 0 disables names*/

/* --- tuning ------------------------------------------------------------- */
constexpr int   MaxActors             = 1024;
constexpr float UnitToMetres          = 100.0f;

} /* namespace off */
