/* resource.h - resource identifiers for the launcher. */
#pragma once

#define IDR_STAGE3 101
