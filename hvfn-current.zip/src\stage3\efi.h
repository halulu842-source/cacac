/* efi.h - the small slice of the UEFI 2.x ABI that Stage-3 needs.
 *
 * Hand-rolled on purpose: the payload is built with MSVC + link.exe instead of
 * EDK2, so it must not depend on any external header or library.  The layouts
 * below follow the UEFI specification (Boot Services table order matters).
 */
#ifndef HVFN_EFI_H
#define HVFN_EFI_H

typedef unsigned char       UINT8;
typedef unsigned short      UINT16;
typedef unsigned int        UINT32;
typedef unsigned long long  UINT64;
typedef unsigned long long  UINTN;
typedef long long           INT64;
typedef UINT64              EFI_STATUS;
typedef void*               EFI_HANDLE;
typedef UINT16              CHAR16;
typedef UINT8               BOOLEAN;
typedef UINT64              EFI_PHYSICAL_ADDRESS;
typedef UINT64              EFI_VIRTUAL_ADDRESS;
typedef UINTN               EFI_TPL;

#define EFIAPI __fastcall

typedef struct {
    UINT32 Data1;
    UINT16 Data2;
    UINT16 Data3;
    UINT8  Data4[8];
} EFI_GUID;

typedef struct {
    UINT64 Signature;
    UINT32 Revision;
    UINT32 HeaderSize;
    UINT32 CRC32;
    UINT32 Reserved;
} EFI_TABLE_HEADER;

typedef struct {
    UINT32            Type;
    UINT32            Pad;
    EFI_PHYSICAL_ADDRESS PhysicalStart;
    EFI_VIRTUAL_ADDRESS  VirtualStart;
    UINT64            NumberOfPages;
    UINT64            Attribute;
} EFI_MEMORY_DESCRIPTOR;

typedef enum {
    EfiReservedMemoryType = 0,
    EfiLoaderCode = 1,
    EfiLoaderData = 2,
    EfiBootServicesCode = 3,
    EfiBootServicesData = 4,
    EfiRuntimeServicesCode = 5,
    EfiRuntimeServicesData = 6,
    EfiConventionalMemory = 7,
    EfiUnusableMemory = 8,
    EfiACPIReclaimMemory = 9,
    EfiACPIMemoryNVS = 10,
    EfiMemoryMappedIO = 11,
    EfiMemoryMappedIOPortSpace = 12,
    EfiPalCode = 13,
    EfiPersistentMemory = 14,
    EfiMaxMemoryType = 15
} EFI_MEMORY_TYPE;

typedef enum {
    AllocateAnyPages = 0,
    AllocateMaxAddress = 1,
    AllocateAddress = 2,
    MaxAllocateType = 3
} EFI_ALLOCATE_TYPE;

#define EFI_ERROR(x)   (((INT64)(x)) < 0)
#define EFI_SUCCESS    0ull
#define EFI_LOAD_ERROR 0x8000000000000001ull
#define EFI_INVALID_PARAMETER 0x8000000000000002ull
#define EFI_BUFFER_TOO_SMALL  0x8000000000000005ull
#define EFI_OUT_OF_RESOURCES  0x8000000000000009ull
#define EFI_NOT_FOUND  0x800000000000000Eull

#define EFI_PAGE_SIZE 4096ull

/* Boot services: the full table up to the entries used, in specification order. */
typedef struct EFI_BOOT_SERVICES {
    EFI_TABLE_HEADER Hdr;

    EFI_TPL     (EFIAPI *RaiseTPL)(EFI_TPL);
    void        (EFIAPI *RestoreTPL)(EFI_TPL);

    EFI_STATUS  (EFIAPI *AllocatePages)(EFI_ALLOCATE_TYPE, EFI_MEMORY_TYPE,
                                        UINTN Pages, EFI_PHYSICAL_ADDRESS* Memory);
    EFI_STATUS  (EFIAPI *FreePages)(EFI_PHYSICAL_ADDRESS, UINTN);
    EFI_STATUS  (EFIAPI *GetMemoryMap)(UINTN*, EFI_MEMORY_DESCRIPTOR*, UINTN*,
                                       UINTN*, UINT32*);
    EFI_STATUS  (EFIAPI *AllocatePool)(EFI_MEMORY_TYPE, UINTN, void**);
    EFI_STATUS  (EFIAPI *FreePool)(void*);

    EFI_STATUS  (EFIAPI *CreateEvent)(UINT32, EFI_TPL, void*, void*, void**);
    EFI_STATUS  (EFIAPI *SetTimer)(void*, UINT64, UINT64, void*);
    EFI_STATUS  (EFIAPI *WaitForEvent)(UINTN, void**, UINTN*);
    EFI_STATUS  (EFIAPI *SignalEvent)(void*);
    EFI_STATUS  (EFIAPI *CloseEvent)(void*);
    EFI_STATUS  (EFIAPI *CheckEvent)(void*);

    EFI_STATUS  (EFIAPI *InstallProtocolInterface)(EFI_HANDLE*, EFI_GUID*, UINTN, void*);
    EFI_STATUS  (EFIAPI *ReinstallProtocolInterface)(EFI_HANDLE, EFI_GUID*, void*, void*);
    EFI_STATUS  (EFIAPI *UninstallProtocolInterface)(EFI_HANDLE, EFI_GUID*, void*);
    EFI_STATUS  (EFIAPI *HandleProtocol)(EFI_HANDLE, EFI_GUID*, void**);
    void*       Reserved;
    EFI_STATUS  (EFIAPI *RegisterProtocolNotify)(EFI_GUID*, void*, void**);
    EFI_STATUS  (EFIAPI *LocateHandle)(UINTN, EFI_GUID*, void*, UINTN*, EFI_HANDLE*);
    EFI_STATUS  (EFIAPI *LocateDevicePath)(EFI_GUID*, void**, EFI_HANDLE*);
    EFI_STATUS  (EFIAPI *InstallConfigurationTable)(EFI_GUID*, void*);

    EFI_STATUS  (EFIAPI *LoadImage)(BOOLEAN, EFI_HANDLE, void*, void*, UINTN, EFI_HANDLE*);
    EFI_STATUS  (EFIAPI *StartImage)(EFI_HANDLE, UINTN*, CHAR16**);
    EFI_STATUS  (EFIAPI *Exit)(EFI_HANDLE, EFI_STATUS, UINTN, CHAR16*);
    EFI_STATUS  (EFIAPI *UnloadImage)(EFI_HANDLE);
    EFI_STATUS  (EFIAPI *ExitBootServices)(EFI_HANDLE, UINTN);

    EFI_STATUS  (EFIAPI *GetNextMonotonicCount)(UINT64*);
    EFI_STATUS  (EFIAPI *Stall)(UINTN);
    EFI_STATUS  (EFIAPI *SetWatchdogTimer)(UINTN, UINT64, UINTN, CHAR16*);

    EFI_STATUS  (EFIAPI *ConnectController)(EFI_HANDLE, EFI_HANDLE*, void*, BOOLEAN);
    EFI_STATUS  (EFIAPI *DisconnectController)(EFI_HANDLE, EFI_HANDLE, EFI_HANDLE);
    EFI_STATUS  (EFIAPI *OpenProtocol)(EFI_HANDLE, EFI_GUID*, void**, EFI_HANDLE, EFI_HANDLE, UINT32);
    EFI_STATUS  (EFIAPI *CloseProtocol)(EFI_HANDLE, EFI_GUID*, EFI_HANDLE, EFI_HANDLE);
    EFI_STATUS  (EFIAPI *OpenProtocolInformation)(EFI_HANDLE, EFI_GUID*, void**, UINTN*);
    EFI_STATUS  (EFIAPI *ProtocolsPerHandle)(EFI_HANDLE, EFI_GUID***, UINTN*);
    EFI_STATUS  (EFIAPI *LocateHandleBuffer)(UINTN, EFI_GUID*, void*, UINTN*, EFI_HANDLE**);
    EFI_STATUS  (EFIAPI *LocateProtocol)(EFI_GUID*, void*, void**);
    EFI_STATUS  (EFIAPI *InstallMultipleProtocolInterfaces)(EFI_HANDLE*, ...);
    EFI_STATUS  (EFIAPI *UninstallMultipleProtocolInterfaces)(EFI_HANDLE*, ...);

    EFI_STATUS  (EFIAPI *CalculateCrc32)(void*, UINTN, UINT32*);
    void        (EFIAPI *CopyMem)(void*, const void*, UINTN);
    void        (EFIAPI *SetMem)(void*, UINTN, UINT8);
    EFI_STATUS  (EFIAPI *CreateEventEx)(UINT32, EFI_TPL, void*, const EFI_GUID*, void**);
} EFI_BOOT_SERVICES;

typedef struct EFI_SIMPLE_TEXT_OUTPUT {
    void* Reset;
    EFI_STATUS (EFIAPI *OutputString)(struct EFI_SIMPLE_TEXT_OUTPUT*, CHAR16*);
    void* TestString;
    void* QueryMode;
    void* SetMode;
    void* SetAttribute;
    void* ClearScreen;
    void* SetCursorPosition;
    void* EnableCursor;
    void* Mode;
} EFI_SIMPLE_TEXT_OUTPUT;

typedef struct {
    EFI_TABLE_HEADER Hdr;
    CHAR16* FirmwareVendor;
    UINT32  FirmwareRevision;
    EFI_HANDLE ConsoleInHandle;
    void*   ConIn;
    EFI_HANDLE ConsoleOutHandle;
    EFI_SIMPLE_TEXT_OUTPUT* ConOut;
    EFI_HANDLE StandardErrorHandle;
    EFI_SIMPLE_TEXT_OUTPUT* StdErr;
    void*   RuntimeServices;
    EFI_BOOT_SERVICES* BootServices;
    UINTN   NumberOfTableEntries;
    void*   ConfigurationTable;
} EFI_SYSTEM_TABLE;

#endif /* HVFN_EFI_H */
