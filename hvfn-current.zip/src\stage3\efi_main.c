/* efi_main.c - Stage-3 UEFI application entry.
 *
 * Order of operations:
 *   1. copy this image into EfiRuntimeServicesCode pages and apply its base
 *      relocations (boot-services memory is handed to the OS at
 *      ExitBootServices, runtime pages are not);
 *   2. continue from the relocated copy;
 *   3. if the arm marker exists, run hv_init(), which VMXONs and VMLAUNCHes,
 *      turning the rest of the boot - firmware, boot manager, Windows - into a
 *      guest;
 *   4. chain-load Windows Boot Manager so the machine still boots.
 *
 * If the arm marker is missing the application does nothing but chain-load,
 * which makes "uninstall" a matter of deleting one file from the ESP.
 */
#include "hv.h"

#define HVFN_ARM_PATH   L"\\EFI\\HvFn\\arm.txt"
#define HVFN_BOOT_PATH  L"\\EFI\\Microsoft\\Boot\\bootmgfw.efi"
#define HVFN_COUNT_PATH L"\\EFI\\HvFn\\boot.txt"
#define HVFN_TRACE_PATH L"\\EFI\\HvFn\\trace.txt"
#define HVFN_PROBE_PATH L"\\EFI\\HvFn\\probe.txt"
#define HVFN_MAX_FAILED_BOOTS 3

extern u8 __ImageBase;

/* ------------------------------------------------------------- PE plumbing */

typedef struct {
    u32 VirtualAddress;
    u32 SizeOfRawData;
} SecHdrLite;

static u32 pe_size_of_image(u64 base)
{
    u8* p = (u8*)base;
    u32 lfanew = *(u32*)(p + 0x3C);
    u8* opt = p + lfanew + 24;
    return *(u32*)(opt + 56);              /* SizeOfImage */
}

static void apply_relocations(u64 image_base, u64 new_base)
{
    u8* p = (u8*)new_base;
    u32 lfanew = *(u32*)(p + 0x3C);
    u8* opt = p + lfanew + 24;
    u32 ndir = *(u32*)(opt + 108);
    u64 delta = new_base - image_base;
    u32 reloc_rva, reloc_size;
    u8* reloc;
    u8* end;

    if (ndir < 6)
        return;
    reloc_rva = *(u32*)(opt + 112 + 5 * 8);
    reloc_size = *(u32*)(opt + 112 + 5 * 8 + 4);
    if (!reloc_rva || !reloc_size)
        return;

    reloc = p + reloc_rva;
    end = reloc + reloc_size;

    while (reloc + 8 <= end) {
        u32 page_rva = *(u32*)reloc;
        u32 block = *(u32*)(reloc + 4);
        u16* entries;
        u32 n, i;

        if (block < 8 || reloc + block > end)
            break;
        entries = (u16*)(reloc + 8);
        n = (block - 8) / 2;
        for (i = 0; i < n; ++i) {
            u16 e = entries[i];
            u32 type = e >> 12;
            u32 off = e & 0xFFF;
            if (type == 0)
                continue;
            if (type == 10) {                       /* IMAGE_REL_BASED_DIR64 */
                u64* target = (u64*)(new_base + page_rva + off);
                *target += delta;
            }
        }
        reloc += block;
    }
}

/* ---------------------------------------------------------- boot services */

static EFI_GUID guid_sfs  = { 0x964e5b22, 0x6459, 0x11d2,
                              { 0x8e, 0x39, 0x00, 0xa0, 0xc9, 0x69, 0x72, 0x3b } };
static EFI_GUID guid_dpath = { 0x09576e91, 0x6d3f, 0x11d2,
                              { 0x8e, 0x39, 0x00, 0xa0, 0xc9, 0x69, 0x72, 0x3b } };
static EFI_GUID guid_limg = { 0x5b1b31a1, 0x9562, 0x11d2,
                              { 0x8e, 0x3f, 0x00, 0xa0, 0xc9, 0x69, 0x72, 0x3b } };

typedef struct {
    u64 Size;
    u64 FileSize;
    u64 PhysicalSize;
} EFI_FILE_INFO_HEAD;

static EFI_GUID guid_fileinfo = { 0x09576e92, 0x6d3f, 0x11d2,
                                { 0x8e, 0x39, 0x00, 0xa0, 0xc9, 0x69, 0x72, 0x3b } };

/* Only ResetSystem is needed: probe mode uses it to reboot before any OS gets
 * the chance to run under the hypervisor. */
typedef struct {
    EFI_TABLE_HEADER Hdr;
    void* GetTime;
    void* SetTime;
    void* GetWakeupTime;
    void* SetWakeupTime;
    void* SetVirtualAddressMap;
    void* ConvertPointer;
    void* GetVariable;
    void* GetNextVariableName;
    void* SetVariable;
    void* GetNextHighMonotonicCount;
    void (EFIAPI *ResetSystem)(int ResetType, EFI_STATUS Status, UINTN Size, void* Data);
} EFI_RUNTIME_SERVICES_MIN;

#define EfiResetCold 0

typedef struct EFI_FILE_PROTOCOL EFI_FILE;

struct EFI_FILE_PROTOCOL {
    u64 Revision;
    EFI_STATUS (EFIAPI *Open)(EFI_FILE*, EFI_FILE**, CHAR16*, u64, u64);
    EFI_STATUS (EFIAPI *Close)(EFI_FILE*);
    EFI_STATUS (EFIAPI *Delete)(EFI_FILE*);
    EFI_STATUS (EFIAPI *Read)(EFI_FILE*, u64*, void*);
    EFI_STATUS (EFIAPI *Write)(EFI_FILE*, u64*, void*);
    EFI_STATUS (EFIAPI *GetPosition)(EFI_FILE*, u64*);
    EFI_STATUS (EFIAPI *SetPosition)(EFI_FILE*, u64);
    EFI_STATUS (EFIAPI *GetInfo)(EFI_FILE*, EFI_GUID*, u64*, void*);
    EFI_STATUS (EFIAPI *SetInfo)(EFI_FILE*, EFI_GUID*, u64, void*);
    EFI_STATUS (EFIAPI *Flush)(EFI_FILE*);
};

typedef struct {
    u64 Revision;
    EFI_STATUS (EFIAPI *OpenVolume)(void*, EFI_FILE**);
} EFI_SIMPLE_FILE_SYSTEM;

typedef struct {
    u32 Revision;
    EFI_HANDLE ParentHandle;
    EFI_SYSTEM_TABLE* SystemTable;
    EFI_HANDLE DeviceHandle;
    void* FilePath;
    void* Reserved;
    u32 LoadOptionsSize;
    void* LoadOptions;
    void* ImageBase;
    u64 ImageSize;
    u32 ImageCodeType;
    u32 ImageDataType;
    EFI_STATUS (EFIAPI *Unload)(EFI_HANDLE);
} EFI_LOADED_IMAGE;

#define EFI_FILE_MODE_READ   1ull
#define EFI_FILE_MODE_WRITE  2ull
#define EFI_FILE_MODE_CREATE 0x8000000000000000ull

/* Minimal GOP for the pre-VMX framebuffer proof.
 * A pristine splash means either this image never ran or ConOut is dead.
 * Paint a 32x32 red square before any VMX work so the next boot proves the
 * channel independently of VMLAUNCH. */
typedef struct {
    u32 RedMask;
    u32 GreenMask;
    u32 BlueMask;
    u32 ReservedMask;
} EFI_PIXEL_BITMASK;

typedef enum {
    PixelRedGreenBlueReserved8BitPerColor,
    PixelBlueGreenRedReserved8BitPerColor,
    PixelBitMask,
    PixelBltOnly,
    PixelFormatMax
} EFI_GRAPHICS_PIXEL_FORMAT;

typedef struct {
    u32 Version;
    u32 HorizontalResolution;
    u32 VerticalResolution;
    EFI_GRAPHICS_PIXEL_FORMAT PixelFormat;
    EFI_PIXEL_BITMASK PixelInformation;
    u32 PixelsPerScanLine;
} EFI_GRAPHICS_OUTPUT_MODE_INFORMATION;

typedef struct {
    u32 MaxMode;
    u32 Mode;
    EFI_GRAPHICS_OUTPUT_MODE_INFORMATION* Info;
    UINTN SizeOfInfo;
    u64 FrameBufferBase;
    UINTN FrameBufferSize;
} EFI_GRAPHICS_OUTPUT_PROTOCOL_MODE;

typedef struct EFI_GRAPHICS_OUTPUT_PROTOCOL EFI_GRAPHICS_OUTPUT_PROTOCOL;

struct EFI_GRAPHICS_OUTPUT_PROTOCOL {
    EFI_STATUS (EFIAPI *QueryMode)(EFI_GRAPHICS_OUTPUT_PROTOCOL*, u32, UINTN*, EFI_GRAPHICS_OUTPUT_MODE_INFORMATION**);
    EFI_STATUS (EFIAPI *SetMode)(EFI_GRAPHICS_OUTPUT_PROTOCOL*, u32);
    void* Blt;
    EFI_GRAPHICS_OUTPUT_PROTOCOL_MODE* Mode;
};

static void paint_proof(EFI_SYSTEM_TABLE* st)
{
    EFI_GUID gop_guid = { 0x9042a9de, 0x23dc, 0x4a38,
                          { 0x96, 0xfb, 0x7a, 0xde, 0xd0, 0x80, 0x51, 0x6a } };
    EFI_GRAPHICS_OUTPUT_PROTOCOL* gop = 0;
    EFI_GRAPHICS_OUTPUT_MODE_INFORMATION* info = 0;
    UINTN size = 0;
    u32* fb;
    u32 x, y, pitch, off;

    if (!st || !st->BootServices || !st->BootServices->LocateProtocol)
        return;
    if (EFI_ERROR(st->BootServices->LocateProtocol(&gop_guid, 0, (void**)&gop)) || !gop)
        return;

    if (gop->Mode && gop->Mode->Mode < gop->Mode->MaxMode) {
        if (!EFI_ERROR(gop->QueryMode(gop, gop->Mode->Mode, &size, &info)) && info)
            gop->SetMode(gop, gop->Mode->Mode);
    }

    if (!gop->Mode || !gop->Mode->FrameBufferBase || !gop->Mode->Info)
        return;

    fb    = (u32*)(UINTN)gop->Mode->FrameBufferBase;
    pitch = gop->Mode->Info->PixelsPerScanLine;
    off   = 64;

    for (y = 0; y < 32; ++y)
        for (x = 0; x < 32; ++x)
            fb[(off + y) * pitch + (off + x)] = 0x00FF0000;

    if (st->BootServices->Stall)
        st->BootServices->Stall(2000000);
}

static void print(EFI_SYSTEM_TABLE* st, const char* s)
{
    CHAR16 buf[128];
    int i = 0;
    while (s[i] && i < 127) {
        buf[i] = (CHAR16)s[i];
        ++i;
    }
    buf[i] = 0;
    if (st && st->ConOut && st->ConOut->OutputString)
        st->ConOut->OutputString(st->ConOut, buf);
}

static EFI_FILE* open_on_boot_volume_ex(EFI_HANDLE image, EFI_SYSTEM_TABLE* st,
                                        CHAR16* path, u64 mode)
{
    EFI_LOADED_IMAGE* li = 0;
    EFI_SIMPLE_FILE_SYSTEM* fs = 0;
    EFI_FILE* root = 0;
    EFI_FILE* file = 0;

    if (EFI_ERROR(st->BootServices->HandleProtocol(image, &guid_limg, (void**)&li)) || !li)
        return 0;
    if (EFI_ERROR(st->BootServices->HandleProtocol(li->DeviceHandle, &guid_sfs, (void**)&fs)) || !fs)
        return 0;
    if (EFI_ERROR(fs->OpenVolume(fs, &root)) || !root)
        return 0;
    if (EFI_ERROR(root->Open(root, &file, path, mode, 0))) {
        root->Close(root);
        return 0;
    }
    root->Close(root);
    return file;
}

static EFI_FILE* open_on_boot_volume(EFI_HANDLE image, EFI_SYSTEM_TABLE* st,
                                     CHAR16* path)
{
    return open_on_boot_volume_ex(image, st, path, EFI_FILE_MODE_READ);
}

/* ------------------------------------------------------------------- trace */
/* Progress log on the ESP.  The last line written before a freeze is the only
 * thing that says where the machine died, so every risky step writes one and
 * flushes immediately. */
static EFI_HANDLE      g_image;
static EFI_SYSTEM_TABLE* g_tst;

void hv_trace(const char* msg)
{
    EFI_FILE* f;
    char info[512];
    u64 info_size = sizeof(info);
    char line[160];
    u64 size;
    int n = 0, i;

    if (!g_image || !g_tst || !msg)
        return;

    f = open_on_boot_volume_ex(g_image, g_tst, HVFN_TRACE_PATH,
                               EFI_FILE_MODE_READ | EFI_FILE_MODE_WRITE | EFI_FILE_MODE_CREATE);
    if (!f)
        return;

    for (i = 0; msg[i] && n < 150; ++i)
        line[n++] = msg[i];
    line[n++] = '\r';
    line[n++] = '\n';

    size = 0;
    mm_memset(info, 0, sizeof(info));
    if (!EFI_ERROR(f->GetInfo(f, &guid_fileinfo, &info_size, info))) {
        u64 fsize = *(u64*)(info + 8);
        /* Append up to 1 MiB, then wrap.  The old 16 KiB cap wrapped after a
         * handful of boots and then OVERWROTE the start of the file, so the
         * "newest" lines were scattered and reading the tail produced stale
         * fragments - which silently corrupted several rounds of diagnosis. */
        if (fsize < 0x100000)
            size = fsize;
    }
    f->SetPosition(f, size);
    size = (u64)n;
    f->Write(f, &size, line);
    f->Flush(f);
    f->Close(f);
}

static int file_present(EFI_HANDLE image, EFI_SYSTEM_TABLE* st, CHAR16* path)
{
    EFI_FILE* f = open_on_boot_volume(image, st, path);
    if (!f)
        return 0;
    f->Close(f);
    return 1;
}

/* Failed-boot counter: incremented before VMXON, cleared by the launcher after
 * it successfully pings the resident hypervisor.  Three consecutive arming
 * attempts that never got that far mean the payload is unsafe on this
 * firmware, so it disarms itself and simply boots Windows. */
static int boot_count_get(EFI_HANDLE image, EFI_SYSTEM_TABLE* st)
{
    EFI_FILE* f = open_on_boot_volume(image, st, HVFN_COUNT_PATH);
    char buf[16];
    u64 size = sizeof(buf) - 1;
    int n = 0, i;

    if (!f)
        return 0;
    mm_memset(buf, 0, sizeof(buf));
    if (EFI_ERROR(f->Read(f, &size, buf)))
        size = 0;
    f->Close(f);
    for (i = 0; i < (int)size && buf[i] >= '0' && buf[i] <= '9'; ++i)
        n = n * 10 + (buf[i] - '0');
    return (n < 0 || n > 1000) ? 0 : n;
}

static void boot_count_set(EFI_HANDLE image, EFI_SYSTEM_TABLE* st, int value)
{
    EFI_FILE* f = open_on_boot_volume_ex(image, st, HVFN_COUNT_PATH,
                                         EFI_FILE_MODE_READ | EFI_FILE_MODE_WRITE |
                                         EFI_FILE_MODE_CREATE);
    char buf[8];
    u64 size;
    int n = 0, i;

    if (!f)
        return;
    if (value == 0) {
        buf[0] = '0';
        size = 1;
    } else {
        char tmp[8];
        int t = 0;
        while (value && t < 7) { tmp[t++] = (char)('0' + value % 10); value /= 10; }
        while (t) buf[n++] = tmp[--t];
        size = (u64)n;
    }
    f->SetPosition(f, 0);
    f->Write(f, &size, buf);
    f->Flush(f);
    f->Close(f);
    (void)i;
}

/* Windows Boot Manager is loaded from a buffer, not from a device path.
 *
 * The previous version called HandleProtocol() on the EFI_FILE_PROTOCOL as if
 * it were a handle: file objects are not in the handle database, so that always
 * failed and the firmware was left with a boot entry that never produced a
 * loader.  Reading the image ourselves and passing SourceBuffer sidesteps
 * device-path construction (FileDevicePath) entirely. */

static EFI_STATUS chainload(EFI_HANDLE image, EFI_SYSTEM_TABLE* st)
{
    EFI_FILE* f;
    EFI_FILE_INFO_HEAD* info = 0;
    u64 info_size = 0;
    void* buffer = 0;
    u64 size = 0;
    EFI_HANDLE child = 0;
    EFI_STATUS s;

    f = open_on_boot_volume(image, st, HVFN_BOOT_PATH);
    if (!f) {
        print(st, "HvFn: bootmgfw.efi not found\r\n");
        return EFI_NOT_FOUND;
    }

    s = f->GetInfo(f, &guid_fileinfo, &info_size, 0);
    if (s != EFI_BUFFER_TOO_SMALL || !info_size)
        info_size = 1024;

    s = st->BootServices->AllocatePool(EfiLoaderData, (UINTN)info_size, (void**)&info);
    if (EFI_ERROR(s) || !info) {
        f->Close(f);
        return EFI_OUT_OF_RESOURCES;
    }

    s = f->GetInfo(f, &guid_fileinfo, &info_size, info);
    if (EFI_ERROR(s) || !info->FileSize || info->FileSize > 64ull * 1024 * 1024) {
        st->BootServices->FreePool(info);
        f->Close(f);
        print(st, "HvFn: cannot size bootmgfw.efi\r\n");
        return EFI_NOT_FOUND;
    }
    size = info->FileSize;
    st->BootServices->FreePool(info);

    s = st->BootServices->AllocatePool(EfiLoaderData, (UINTN)size, &buffer);
    if (EFI_ERROR(s) || !buffer) {
        f->Close(f);
        return EFI_OUT_OF_RESOURCES;
    }

    s = f->Read(f, &size, buffer);
    f->Close(f);
    if (EFI_ERROR(s) || !size) {
        st->BootServices->FreePool(buffer);
        print(st, "HvFn: cannot read bootmgfw.efi\r\n");
        return EFI_NOT_FOUND;
    }

    s = st->BootServices->LoadImage(0, image, 0, buffer, (UINTN)size, &child);
    if (EFI_ERROR(s)) {
        st->BootServices->FreePool(buffer);
        print(st, "HvFn: LoadImage failed\r\n");
        return s;
    }

    s = st->BootServices->StartImage(child, 0, 0);
    if (EFI_ERROR(s))
        st->BootServices->UnloadImage(child);
    return s;
}

/* ------------------------------------------------------------ payload body */

static EFI_STATUS EFIAPI hv_arm_and_boot(EFI_HANDLE image, EFI_SYSTEM_TABLE* st)
{
    int rc;

    /* These globals live in *this* copy of the image; the original copy's were
     * set before the jump, so set them here or every trace() call below is a
     * silent no-op. */
    g_image = image;
    g_tst = st;
    g_bs = st->BootServices;
    g_st = st;

    {
        int probe = file_present(image, st, HVFN_PROBE_PATH);
        hv_set_probe(probe);
        hv_trace(probe ? "05 hv_init (probe: full launch test)" : "05 hv_init");
    }
    rc = hv_init();

    if (rc == 0) {
        print(st, "HvFn: hypervisor up (self-test passed)\r\n");
        hv_trace("07 self-test ok");

        if (file_present(image, st, HVFN_PROBE_PATH)) {
            /* Probe boot: the hypervisor proved it can take exits and resume.
             * Leave the machine rebooting clean instead of running Windows
             * under an unproven hypervisor. */
            EFI_RUNTIME_SERVICES_MIN* rt = (EFI_RUNTIME_SERVICES_MIN*)st->RuntimeServices;
            hv_trace("08 probe passed, resetting");
            print(st, "HvFn: probe passed - rebooting clean\r\n");
            if (rt && rt->ResetSystem)
                rt->ResetSystem(EfiResetCold, 0, 0, 0);
        }
    } else if (rc == -12) {
        print(st, "HvFn: self-test failed - watchdog left armed, boot may reset\r\n");
        hv_trace("07 selftest failed, watchdog armed");
    } else {
        print(st, "HvFn: stage-3 init failed (code ");
        {
            CHAR16 num[8];
            int n = 0, v = -rc;
            char tmp[8];
            int t = 0;
            while (v && t < 7) { tmp[t++] = (char)('0' + v % 10); v /= 10; }
            while (t) num[n++] = (CHAR16)tmp[--t];
            num[n] = 0;
            st->ConOut->OutputString(st->ConOut, num);
        }
        print(st, ") - booting unvirtualised\r\n");
        {
            char msg[48];
            int v = -rc, i = 0, j = 0;
            char rev[8];
            while (v && j < 7) { rev[j++] = (char)('0' + v % 10); v /= 10; }
            msg[i++] = '0'; msg[i++] = '6'; msg[i++] = ' ';
            msg[i++] = 'i'; msg[i++] = 'n'; msg[i++] = 'i'; msg[i++] = 't'; msg[i++] = ' ';
            msg[i++] = 'r'; msg[i++] = 'c'; msg[i++] = '=';
            msg[i++] = '-';
            while (j) msg[i++] = rev[--j];
            msg[i] = 0;
            hv_trace(msg);
        }
    }

    hv_trace("09 chainload");
    {
        EFI_STATUS cs = chainload(image, st);
        hv_trace("10 chainload returned");
        return cs;
    }
}

EFI_STATUS EFIAPI EfiEntry(EFI_HANDLE image, EFI_SYSTEM_TABLE* st)
{
    /* ---- console proof-of-life, before any VMX work ---------------------
     *
     * Nothing this project has ever printed has been observed on screen, so the
     * console channel itself is unproven - and every screen-based diagnostic
     * depends on it completely.  Three seconds of banner before VMXON settles
     * it: if this appears, ConOut is live on this board and a blank screen
     * later means a wedge; if it never appears, the channel is dead and the
     * instrumentation has to move to the GOP framebuffer instead.
     *
     * It also proves, independently of any trace file, that this image is the
     * thing executing. */
    print(st, "\r\nHvFn: ENTRY - console test, 3 seconds\r\n");
    if (st && st->BootServices && st->BootServices->Stall)
        st->BootServices->Stall(1500000);
    print(st, "HvFn: ENTRY - console test TWO\r\n");
    if (st && st->BootServices && st->BootServices->Stall)
        st->BootServices->Stall(1500000);

    /* ---- CMOS proof-of-entry read-back ----------------------------------
     * The probe guest writes 0x5A to CMOS user RAM byte 0x4F as its FIRST
     * instruction.  CMOS survives the reset, so if we read 0x5A here the
     * previous boot's VMLAUNCH really entered the guest and the freeze was
     * downstream of entry.  Any other value means the guest never executed -
     * VMLAUNCH itself aborted.  This is the one fact that ends the deadlock
     * between those two hypotheses. */
    {
        static const char hexd[] = "0123456789ABCDEF";
        u8 cm;
        char tmp[48];
        hv_outb(0x70, 0x4F);
        cm = hv_inb(0x71);
        tmp[0]='H'; tmp[1]='v'; tmp[2]='F'; tmp[3]='n'; tmp[4]=':'; tmp[5]=' ';
        tmp[6]='C'; tmp[7]='M'; tmp[8]='O'; tmp[9]='S'; tmp[10]='='; tmp[11]='0'; tmp[12]='x';
        tmp[13]=hexd[(cm >> 4) & 0xF]; tmp[14]=hexd[cm & 0xF];
        tmp[15]='\r'; tmp[16]='\n'; tmp[17]=0;
        if (cm == 0x5A) {
            print(st, "HvFn: CMOS=0x5A -> GUEST RAN LAST BOOT (VM entry WORKS)\r\n");
        } else {
            print(st, tmp);
        }
        /* Do NOT clear it here: hv_init reads it again and writes it to the
         * trace file so the verdict survives without anyone reading a screen. */
    }

    paint_proof(st);

    u64 base = (u64)&__ImageBase;
    u64 size = pe_size_of_image(base);
    u64 pages;
    EFI_PHYSICAL_ADDRESS addr = 0;
    EFI_STATUS s;
    EFI_IMAGE_ENTRY_POINT body;

    if (!size)
        return EFI_LOAD_ERROR;

    size = (size + 0xFFF) & ~0xFFFull;
    pages = size >> 12;

    s = st->BootServices->AllocatePages(AllocateAnyPages, EfiRuntimeServicesCode,
                                        (UINTN)pages, &addr);
    if (EFI_ERROR(s) || !addr) {
        print(st, "HvFn: runtime allocation failed\r\n");
        return s;
    }

    mm_memcpy((void*)addr, (void*)base, size);
    apply_relocations(base, addr);

    g_image = image;
    g_tst = st;

    hv_trace("00 entry");

    body = (EFI_IMAGE_ENTRY_POINT)(addr + ((u64)&hv_arm_and_boot - base));

    if (!file_present(image, st, HVFN_ARM_PATH)) {
        print(st, "HvFn: not armed - chain-loading Windows\r\n");
        hv_trace("01 not armed");
        return chainload(image, st);
    }

    /* Failed-boot guard: every armed boot counts.  The launcher clears the
     * counter after a successful ping, which is the only reliable proof that
     * Windows really finished booting with the hypervisor resident.  A probe
     * boot is a test by design, so it does not accumulate failures. */
    {
        int probe = file_present(image, st, HVFN_PROBE_PATH);
        int n;

        hv_trace("02 armed");

        if (probe) {
            boot_count_set(image, st, 0);
        } else {
            n = boot_count_get(image, st);
            if (n >= HVFN_MAX_FAILED_BOOTS) {
                print(st, "HvFn: disarmed after repeated failed boots - press Reset in HvFn.exe\r\n");
                hv_trace("03 guard trip, disarming");
                return chainload(image, st);
            }
            boot_count_set(image, st, n + 1);
        }
    }

    hv_trace("04 entering body");
    return body(image, st);
}
