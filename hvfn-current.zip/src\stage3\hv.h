/* hv.h - Stage-3 hypervisor internals: VMX/EPT plumbing, physical access and
 * the target-resolution state machine.
 */
#ifndef HVFN_STAGE3_HV_H
#define HVFN_STAGE3_HV_H

#include "efi.h"
#include "vmcs_fields.h"
#include "../common/hvfn_protocol.h"

typedef unsigned char      u8;
typedef unsigned short     u16;
typedef unsigned int       u32;
typedef unsigned long long u64;
typedef long long          i64;

/* ------------------------------------------------------------------ layout */

#define HV_PAGE            0x1000ull
#define HV_HOST_STACK_SIZE 0x8000ull          /* 32 KiB host stack            */
#define HV_EPT_COVER       0x10000000000ull   /* guest physical: 1 TiB      */
#define HV_HOST_COVER      0x8000000000ull    /* host physical: 512 GiB     */
#define HV_MAX_XFER_BYTES  HV_MAX_XFER
#define HV_XSAVE_SIZE      0x8000ull          /* 32 KiB SIMD state area     */

typedef struct GuestRegs {
    u64 rax, rbx, rcx, rdx, rsi, rdi, rbp;
    u64 r8, r9, r10, r11, r12, r13, r14, r15;
    u64 rsp;
    u64 pad;
} GuestRegs;

typedef struct HvContext {
    u64 vmxon_page;
    u64 vmcs_page;
    u64 msr_bitmap;
    u64 host_cr3;
    u64 ept_pml4;
    u64 eptp;
    u64 host_stack_top;
    u64 arena_base;
    u64 arena_end;

    /* host-private control tables, built once in hv_init */
    u64 host_gdt;
    u64 host_idt;
    u64 host_tss;
    u64 xsave_area;

    GuestRegs* regs;

    volatile u64 exits_total;
    volatile u64 hypercalls_total;
    volatile u64 kernel_samples;
    volatile u64 ept_violations;
    volatile u64 bad_ud;
    volatile u64 irq_reinjects;
    volatile u64 fault_recoveries;

    /* set by the exit dispatcher before it touches guest memory; a fault in
     * root mode advances the guest RIP by this much and resumes, so a broken
     * hypercall fails instead of hanging the machine. */
    volatile u64 pending_advance;
    volatile u64 last_violation_gpa;
    volatile u64 violation_retries;
    volatile u64 last_fault_rip;
    volatile u64 panic_code;
    volatile u64 last_reason;      /* exit-loop detector                     */
    volatile u64 last_rip;         /* exit-loop detector                     */
    volatile u64 loop_reason;      /* set when an infinite exit loop is found */
    volatile u64 loop_rip;

    /* most recent kernel-mode context observed on the BSP */
    volatile u64 kern_cr3;
    volatile u64 kern_eprocess;
    volatile u64 kern_idt;
    volatile u64 nt_base;
    /* &PsActiveProcessHead, found by parsing ntoskrnl's export directory.
     * hv_resolve.c walks this list directly, so the field has to exist even
     * while the PsInitialSystemProcess route below is still unused. */
    volatile u64 nt_active_process_head;
    volatile u64 nt_initial_system;     /* &PsInitialSystemProcess             */
    volatile u64 system_eprocess;       /* value of PsInitialSystemProcess     */

    /* derived EPROCESS layout */
    volatile u64 eproc_links_off;
    volatile u64 eproc_dtb_off;
    volatile u64 resolve_attempts;
    volatile u64 resolve_last_error;

    /* resolved target */
    volatile u32 target_state;
    volatile u32 target_pid;
    volatile u64 target_cr3;
    volatile u64 target_base;
    volatile u64 target_peb;

    u64 vmx_revision;
    u32 ept_1g;
    u32 initialized;
    u32 have_invpcid;
    u32 have_rdtscp;
    u32 have_xsaves;
} HvContext;

/* -------------------------------------------------------------------- asm */

typedef EFI_STATUS (EFIAPI *EFI_IMAGE_ENTRY_POINT)(EFI_HANDLE, EFI_SYSTEM_TABLE*);

int  hv_vmxon(u64 phys);
int  hv_vmclear(u64 phys);
int  hv_vmptrld(u64 phys);
u64  hv_vmread(u32 field);
void hv_vmwrite(u32 field, u64 value);
int  hv_enter(void);
void hv_exit_entry(void);
void hv_fatal_entry(void);
void hv_read_segments(u16* out8);
void hv_read_gdtr(void* desc10);
void hv_read_idtr(void* desc10);
void hv_load_idt(void* desc10);
u64  hv_rdtsc(void);
void hv_vmcall(u64 magic, u64 request);
void hv_vmxoff(void);
void hv_invept(u64 eptp);          /* invalidate all EPT-derived translations */
u64  hv_xgetbv(void);              /* XCR0 */
void hv_xsetbv(u32 index, u64 value);

/* Pre-VMX fault catcher (hv_asm.asm).  VMXON runs before any IDT of ours is
 * loaded, so a fault there would vector through the firmware's handler and
 * triple-fault with nothing in the trace.  These turn it into a return value. */
void hv_fault_ud(void);
void hv_fault_gp(void);
int  hv_try_vmxon(u64 region, u64 resume_stub);
void hv_try_vmxon_resume(void);
int  hv_try_ud2(u64 resume_stub);
extern u64 g_fault_resume;
extern u64 g_fault_code;           /* vector the catcher saw, 0 = none      */
extern u64 g_fault_rip;            /* RIP that faulted                      */

/* exit-stub state shared with hv_core.c */
extern u64 g_use_xsave;            /* 1 = exit stub uses XSAVE/XRSTOR       */
extern u64 g_xsave_area;           /* 64-byte aligned SIMD save area        */
extern u64 g_fatal_frame0;         /* root-mode fault frame (RIP or error)  */
extern u64 g_fatal_frame1;
extern u64 g_fault_recoveries;
void hv_fault_recover(void);       /* implemented in hv_core.c              */

/* exit-stub state shared with hv_core.c */
extern u64 g_use_xsave;            /* 1 = exit stub uses XSAVE/XRSTOR       */
extern u64 g_xsave_area;           /* 64-byte aligned SIMD save area        */
extern u64 g_fatal_frame0;         /* root-mode fault frame (RIP or error)  */
extern u64 g_fatal_frame1;
extern u64 g_fault_recoveries;
void hv_fault_recover(void);       /* implemented in hv_core.c              */

/* implemented in efi_main.c: append a line to \EFI\HvFn\trace.txt */
void hv_trace(const char* msg);

/* Probe mode narrows the exit surface: only the ring-0 VMCALL self-test exits,
 * CPUID is passed straight through.  If a probe freezes, the launch or the exit
 * stub is at fault; if it passes, CPUID emulation is the suspect. */
void hv_set_probe(int on);

/* ------------------------------------------------------------ hv_core.c */

extern HvContext  g_ctx;
extern GuestRegs  g_guest_regs;
extern HvContext* g_hv;
extern EFI_BOOT_SERVICES* g_bs;
extern EFI_SYSTEM_TABLE*  g_st;

int  hv_init(void);
u32  hv_launch_error(void);
void hv_prepare_guest(u64 guest_rsp, u64 guest_rip);
void hv_dump_vmcs(void);   /* writes the validated VMCS fields to the trace */
void hv_dry_bail(void);    /* diagnostic: leave VMX instead of launching */

/* Launch-probe report page.
 *
 * The guest writes `magic` as its VERY FIRST instruction - before touching the
 * stack, before any call, before anything that could fault.  So `magic` being
 * set proves VM entry succeeded, independently of whether the guest survives
 * one more instruction.  That is the evidence this project has never had: the
 * existing "05d guest resumed" line is written by C code running after
 * hv_enter() returns, so it proves nothing about the guest itself.
 *
 * The first VM exit writes the exit fields and then tears VMX down, so the
 * experiment is bounded to exactly one exit and the page survives to be read
 * by the host afterwards. */
typedef struct HvReport {
    volatile u64 magic;         /* 0x600DF00D600DF00D - written by the guest  */
    volatile u64 guest_ran;     /* written by the guest right after the magic */
    volatile u64 vmcall_missed; /* set if the guest's VMCALL did not exit     */
    volatile u64 launches;      /* host increments immediately before vmlaunch*/
    volatile u64 exit_reason;
    volatile u64 exit_qual;
    volatile u64 exit_rip;
    volatile u64 exited;        /* host: the exit stub reached C              */
    volatile u64 exit_intr_info;/* VMCS 0x4404 - which exception fired        */
    volatile u64 exit_intr_err; /* VMCS 0x4406 - exception error code         */
    volatile u64 exit_cr2;      /* VMCS 0x6402 - faulting linear address      */
} HvReport;

extern u64       g_report_ptr;    /* asm-visible: address of the report page */
extern u64       g_stage_a;       /* asm-visible: 1 = minimal probe launch   */
extern HvReport* g_report;        /* C-visible pointer to the same page      */
void hv_publish_report(const char* tag);
void hv_say(const char* msg);   /* console output - survives a hang */

extern void hv_guest_probe(void); /* guest entry stub (hv_asm.asm)           */
extern void hv_probe_exit(void);  /* one-shot exit stub (hv_asm.asm)         */
u8    hv_inb(u32 port);           /* CMOS proof-of-entry read-back           */
void  hv_outb(u32 port, u8 val);
void hv_handle_exit(void);
u64  hv_get_context_addr(void);
void hv_panic(u32 code);

void* mm_memset(void* dst, int c, u64 n);
void* mm_memcpy(void* dst, const void* src, u64 n);

/* ------------------------------------------------------------ hv_mem.c */

u64  mm_translate(u64 cr3, u64 va);
int  mm_read(u64 cr3, u64 va, void* dst, u64 len);
int  mm_write(u64 cr3, u64 va, const void* src, u64 len);
u64  phys_read64(u64 pa);
u32  phys_read32(u64 pa);
u16  phys_read16(u64 pa);
u8   phys_read8(u64 pa);

/* -------------------------------------------------------- hv_resolve.c */

int  hv_capture_kernel_sample(u64 guest_cr3, u64 gs_base);
int  hv_resolve_target(u32 pid, u64 fallback_cr3);

#endif /* HVFN_STAGE3_HV_H */



