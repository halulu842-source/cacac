; hv_asm.asm - VMX instruction wrappers, the launch trampoline and the VM-exit
; entry stub for Stage-3.
;
; The trampoline is the delicate part: it saves the complete guest register
; state, asks C to fill the VMCS with that same state (guest RIP -> hv_resume,
; guest RSP -> the saved RSP), restores every register and executes VMLAUNCH.
; Because the guest state is byte-identical to the running state, the guest
; resumes at hv_resume with a valid stack and a plain RET returns to whoever
; called hv_enter - now running inside the virtual machine.
;
; The exit stub is entered by hardware with the host RSP from the VMCS, so it
; always has a private kernel stack.  It saves GPRs/XMMs, calls into C and
; restores them before VMRESUME.  RFLAGS is not touched: hardware saves the
; guest RFLAGS into the VMCS on exit and reloads it on entry, so the CLI that
; blocks interrupts during handling is invisible to the guest.

option casemap:none

.data
PUBLIC g_use_xsave
PUBLIC g_xsave_area
PUBLIC g_fatal_frame0
PUBLIC g_fatal_frame1
PUBLIC g_fault_recoveries
g_use_xsave         dq 0
g_xsave_area        dq 0
g_fatal_frame0      dq 0
g_fatal_frame1      dq 0
g_fault_recoveries  dq 0

ALIGN 16
g_invept_desc   dq 0, 0

; VMXON/VMCLEAR/VMPTRLD take a *memory* operand holding the physical address of
; the region, not the address itself.  C passes the physical address in RCX; the
; stub parks it here and points the instruction at this qword.
ALIGN 8
g_vmx_ptr       dq 0

; Diagnostic switch.  While this is 1 the trampoline prepares the complete
; launch state, dumps every field VM entry validates, then leaves VMX and
; returns WITHOUT ever executing VMLAUNCH.
;
; It has to be checked here rather than in hv_init: hv_prepare_guest is what
; fills the guest and host halves of the VMCS, so bailing out earlier would dump
; nothing but zeroes - which is exactly what happened the first two dry runs.
; Bailing here means the dump is the real launch state, and a VM entry cannot
; hang a machine that never attempts one.
;
; Set to 0 to restore the real launch.
PUBLIC g_dry_run
g_dry_run       dq 0

; Pre-VMX fault catcher state, written by the probes below and read back by C.
PUBLIC g_fault_resume
PUBLIC g_fault_code
PUBLIC g_fault_rip
g_fault_resume  dq 0
g_fault_code    dq 0
g_fault_rip     dq 0

; Launch probe (diagnostic).  While g_stage_a is 1 the launch is minimal and
; bounded: the guest's first instruction writes a magic into the shared report
; page, then executes VMCALL; the resulting exit is recorded and VMX is torn
; down immediately instead of resuming the guest.  One exit and out, so the
; experiment cannot hang in the exit path, and the report page survives to be
; read by the host.  Set to 0 to use the real launch path.
PUBLIC g_stage_a
g_stage_a       dq 0

; Address of the shared report page, filled in by C before the launch.
PUBLIC g_report_ptr
g_report_ptr    dq 0

; VMCS field encodings used by the probe stub (kept local so this file does not
; depend on the generated header).
VMCS_EXIT_REASON_F  equ 04402h
VMCS_EXIT_QUAL_F    equ 06400h
VMCS_GUEST_RIP_F    equ 0681Eh
VMCS_GUEST_CR3_F    equ 06802h
VMCS_EXIT_INTR_INFO_F equ 04404h
VMCS_EXIT_INTR_ERR_F  equ 04406h
VMCS_CR2_F            equ 06402h

.code

extern g_guest_regs:qword
extern g_fw_idtr:byte
extern g_fw_gdtr:byte
extern hv_prepare_guest:proc
extern hv_dump_vmcs:proc
extern hv_dry_bail:proc
extern hv_handle_exit:proc
extern hv_fault_recover:proc

; ---------------------------------------------------------------- VMX instrs

PUBLIC hv_vmxon
hv_vmxon PROC
    mov     [g_vmx_ptr], rcx
    vmxon   qword ptr [g_vmx_ptr]
    jc      short vmx_fail
    jz      short vmx_fail
    xor     eax, eax
    ret
vmx_fail:
    mov     eax, 1
    ret
hv_vmxon ENDP

PUBLIC hv_vmclear
hv_vmclear PROC
    mov     [g_vmx_ptr], rcx
    vmclear qword ptr [g_vmx_ptr]
    jc      short vmc_fail
    jz      short vmc_fail
    xor     eax, eax
    ret
vmc_fail:
    mov     eax, 1
    ret
hv_vmclear ENDP

PUBLIC hv_vmptrld
hv_vmptrld PROC
    mov     [g_vmx_ptr], rcx
    vmptrld qword ptr [g_vmx_ptr]
    jc      short vmp_fail
    jz      short vmp_fail
    xor     eax, eax
    ret
vmp_fail:
    mov     eax, 1
    ret
hv_vmptrld ENDP

; ------------------------------------------------- pre-VMX fault catchers
; VMXON executes before any IDT of ours is loaded and before a VMCS exists, so a
; fault there is invisible: the CPU vectors through the FIRMWARE's IDT, whose
; handler cannot recover, re-faults, and triple-faults - a dead machine with no
; trace line.  hv_fatal_entry is no help either, because its recovery path
; issues VMREAD/VMWRITE, which is illegal before VMXON.
;
; These stubs are installed as the IDT for the VMXON window only.  They record
; the vector and the faulting RIP, redirect the return address to a resume stub
; and IRETQ, so a faulting VMXON comes back as an ordinary return value.

PUBLIC hv_fault_ud
hv_fault_ud PROC
    mov     qword ptr [g_fault_code], 6
    mov     rax, [rsp]                  ; saved RIP (no error code)
    mov     [g_fault_rip], rax
    mov     rax, [g_fault_resume]
    mov     [rsp], rax
    iretq
hv_fault_ud ENDP

PUBLIC hv_fault_gp
hv_fault_gp PROC
    mov     qword ptr [g_fault_code], 13
    mov     rax, [rsp+8]                ; saved RIP (error code at [rsp])
    mov     [g_fault_rip], rax
    mov     rax, [g_fault_resume]
    mov     [rsp+8], rax
    iretq
hv_fault_gp ENDP

; int hv_try_vmxon(u64 region, u64 resume_stub)
PUBLIC hv_try_vmxon
hv_try_vmxon PROC
    mov     [g_vmx_ptr], rcx            ; the region, parked in the operand slot
    mov     [g_fault_resume], rdx
    xor     eax, eax
    mov     [g_fault_code], rax
    vmxon   qword ptr [g_vmx_ptr]       ; NOT [rcx]: VMXON reads a memory
                                        ; location holding the PHYSICAL address
    jc      short try_vmx_cf
    jz      short try_vmx_cf
    xor     eax, eax                    ; 0 = entered VMX
    ret
try_vmx_cf:
    mov     eax, 2                      ; 2 = VMfail (CF or ZF set)
    ret
hv_try_vmxon ENDP

; Resume target for a faulted probe: the catcher IRETs here, and this plain RET
; unwinds back to whoever called the probe.
PUBLIC hv_try_vmxon_resume
hv_try_vmxon_resume PROC
    mov     eax, 3                      ; 3 = faulted; vector in g_fault_code
    ret
hv_try_vmxon_resume ENDP

; Deliberate #UD behind the same catcher: proves it works before it is trusted
; to explain a VMXON result.
PUBLIC hv_try_ud2
hv_try_ud2 PROC
    mov     [g_fault_resume], rcx
    xor     eax, eax
    mov     [g_fault_code], rax
    ud2
    mov     eax, 9                      ; not reached when the catcher works
    ret
hv_try_ud2 ENDP

PUBLIC hv_vmread
hv_vmread PROC
    vmread  rax, rcx
    ret
hv_vmread ENDP

PUBLIC hv_vmwrite
hv_vmwrite PROC
    vmwrite rcx, rdx
    ret
hv_vmwrite ENDP

; --------------------------------------------------------------- segment I/O

PUBLIC hv_read_segments
; void hv_read_segments(u16 out[8])  cs,ds,es,ss,fs,gs,tr,ldtr
hv_read_segments PROC
    mov     word ptr [rcx+0],  cs
    mov     word ptr [rcx+2],  ds
    mov     word ptr [rcx+4],  es
    mov     word ptr [rcx+6],  ss
    mov     word ptr [rcx+8],  fs
    mov     word ptr [rcx+10], gs
    str     word ptr [rcx+12]
    sldt    word ptr [rcx+14]
    ret
hv_read_segments ENDP

PUBLIC hv_read_gdtr
hv_read_gdtr PROC
    sgdt    fword ptr [rcx]
    ret
hv_read_gdtr ENDP

PUBLIC hv_read_idtr
hv_read_idtr PROC
    sidt    fword ptr [rcx]
    ret
hv_read_idtr ENDP

PUBLIC hv_load_idt
hv_load_idt PROC
    lidt    fword ptr [rcx]
    ret
hv_load_idt ENDP

PUBLIC hv_rdtsc
hv_rdtsc PROC
    rdtsc
    shl     rdx, 32
    or      rax, rdx
    ret
hv_rdtsc ENDP

; void hv_vmcall(u64 magic, u64 request)
; Used from firmware context (ring 0) for the post-launch self-test: in a guest,
; VMCALL raises VM exit reason 18 and the handler services it.
PUBLIC hv_vmcall
hv_vmcall PROC
    mov     rax, rcx
    mov     rcx, rdx
    vmcall
    ret
hv_vmcall ENDP

; Leave VMX operation.  Legal only when the processor is not a guest, i.e. on
; the VMLAUNCH-failure path; from inside the VM it would #UD.
PUBLIC hv_vmxoff
hv_vmxoff PROC
    vmxoff
    ret
hv_vmxoff ENDP

; ------------------------------------------------- launch probe (stage A)
; Guest entry point: the FIRST instruction executed after a successful VM entry.
; It touches nothing but the report page - no stack, no call, no register it
; depends on being valid - so if the magic lands, VM entry provably succeeded
; even if the very next thing the guest does is die.
PUBLIC hv_guest_probe
hv_guest_probe PROC
    ; ---- CMOS proof-of-entry, BEFORE anything memory-dependent -------------
    mov     al, 4Fh
    out     70h, al
    mov     al, 5Ah
    out     71h, al                      ; CMOS[0x4F] = 0x5A

    ; CPUID is on the SDM 25.1.2 UNCONDITIONAL exit list (reason 10): no control
    ; bit, and - unlike VMCALL - no nested-VMX interaction with guest CR4.VMXE.
    ; So this is the one guest instruction that is guaranteed to produce a clean
    ; exit regardless of the guest's VMXE state.  No memory access, no vmcall.
    xor     eax, eax
    xor     ecx, ecx
    cpuid                               ; unconditional VM exit, reason 10
    ud2
hv_guest_probe ENDP

; Port I/O helpers for the CMOS proof-of-entry read-back.
; hv_inb:  rcx = port, returns byte zero-extended in rax.
; hv_outb: rcx = port, dl = value.
PUBLIC hv_inb
hv_inb PROC
    mov     rdx, rcx
    in      al, dx
    movzx   rax, al
    ret
hv_inb ENDP

PUBLIC hv_outb
hv_outb PROC
    mov     rax, rdx
    mov     rdx, rcx
    out     dx, al
    ret
hv_outb ENDP

; One-shot host exit stub for the probe launch.  Records the exit, then leaves
; VMX and returns to the C caller.  It deliberately does NOT resume the guest:
; one exit and out, so a broken resume path cannot turn the probe into a hang.
PUBLIC hv_probe_exit
hv_probe_exit PROC
    cli
    ; ---- proof the exit stub is even REACHED ------------------------------
    ; Overwrite CMOS[0x4F] with 0x5B (the guest wrote 0x5A there first).  The
    ; next boot reads 0x4F: 0x5B means BOTH the guest and this exit stub ran,
    ; 0x5A means only the guest ran (the exit died in host-state load before
    ; reaching HOST_RIP).  (0x4E was tried first but reads back 0xFF - it is
    ; not battery-backed on this board.)
    mov     al, 4Fh
    out     70h, al
    mov     al, 5Bh
    out     71h, al                      ; CMOS[0x4F] = 0x5B (exit stub ran)

    mov     rbx, [g_report_ptr]

    ; marker: did the .data read (g_report_ptr) succeed?
    mov     al, 4Fh
    out     70h, al
    mov     al, 5Ch
    out     71h, al                      ; CMOS[0x4F] = 0x5C

    mov     rax, VMCS_EXIT_REASON_F
    vmread  rdx, rax
    mov     [rbx+32], rdx               ; report->exit_reason

    mov     rax, VMCS_EXIT_QUAL_F
    vmread  rdx, rax
    mov     [rbx+40], rdx               ; report->exit_qual

    mov     rax, VMCS_GUEST_RIP_F
    vmread  rdx, rax
    mov     [rbx+48], rdx               ; report->exit_rip

    mov     qword ptr [rbx+56], 1       ; report->exited

    ; marker: did the vmreads + report write succeed?
    mov     al, 4Fh
    out     70h, al
    mov     al, 5Dh
    out     71h, al                      ; CMOS[0x4F] = 0x5D

    ; Save the GUEST CR3 (the firmware's CR3) before tearing down, so we can
    ; hand it back to the host after VMXOFF.  VM exit loaded HOST_CR3; if we
    ; leave it that way, the `ret` into hv_init runs the console and trace code
    ; on the wrong address space and wedges.
    mov     rax, VMCS_GUEST_CR3_F
    vmread  r8, rax                     ; r8 = firmware CR3

    vmxoff
    mov     rax, cr4
    and     rax, 0FFFFFFFFFFFFDFFFh     ; clear CR4.VMXE
    mov     cr4, rax

    ; marker: did vmxoff + clear VMXE succeed?
    mov     al, 4Fh
    out     70h, al
    mov     al, 5Eh
    out     71h, al                      ; CMOS[0x4F] = 0x5E

    ; Restore the firmware CR3 before returning to C.
    mov     rax, r8
    mov     cr3, rax

    ; Restore the firmware GDT and IDT.  The exit loaded OUR host GDTR/IDTR; if
    ; we return with those still loaded, the first timer interrupt vectors into
    ; our fatal handler, which does VMRESUME - but VMX is already off, so that
    ; is #UD, re-entering the handler: an unbreakable two-fault loop.  Pointing
    ; the tables back at the firmware's own closes the window before the ret.
    lgdt    fword ptr [g_fw_gdtr]
    lidt    fword ptr [g_fw_idtr]

    ; marker: did the CR3 restore succeed (next fetch works on firmware CR3)?
    mov     al, 4Fh
    out     70h, al
    mov     al, 5Fh
    out     71h, al                      ; CMOS[0x4F] = 0x5F

    ; The exit loaded HOST_RSP; C needs the firmware stack back before it can
    ; return into hv_init.
    mov     rsp, [g_guest_regs+078h]
    mov     eax, 3                      ; 3 = probe completed
    ret
hv_probe_exit ENDP

; ------------------------------------------------------------ launch path

PUBLIC hv_enter
hv_enter PROC
    mov     [g_guest_regs+000h], rax
    mov     [g_guest_regs+008h], rbx
    mov     [g_guest_regs+010h], rcx
    mov     [g_guest_regs+018h], rdx
    mov     [g_guest_regs+020h], rsi
    mov     [g_guest_regs+028h], rdi
    mov     [g_guest_regs+030h], rbp
    mov     [g_guest_regs+038h], r8
    mov     [g_guest_regs+040h], r9
    mov     [g_guest_regs+048h], r10
    mov     [g_guest_regs+050h], r11
    mov     [g_guest_regs+058h], r12
    mov     [g_guest_regs+060h], r13
    mov     [g_guest_regs+068h], r14
    mov     [g_guest_regs+070h], r15
    mov     [g_guest_regs+078h], rsp

    ; ---- stack alignment -----------------------------------------------
    ; The firmware called us per the ABI, so RSP % 16 == 8 at entry.  C callees
    ; (hv_prepare_guest, hv_dump_vmcs, hv_dry_bail) require the CALLER to
    ; present a 16-byte-aligned RSP before the call.  Without this, every C
    ; function reached from the trampoline runs with a misaligned stack, and
    ; any SSE-aligned access in them - or in the firmware file/console I/O they
    ; reach - faults.  That is why hv_init's trace writes always reach the file
    ; (correctly aligned C call) while hv_prepare_guest's never have, and quite
    ; possibly why the launch has "hung" since the first boot: it was never
    ; VMLAUNCH, it was hv_prepare_guest faulting on a misaligned stack.
    and     rsp, -16
    sub     rsp, 32                     ; shadow space for the callees

    mov     rcx, [g_guest_regs+078h]     ; guest RSP (original, not the aligned one)
    lea     rdx, hv_resume              ; guest RIP
    call    hv_prepare_guest

    ; hv_prepare_guest is what fills the guest and host halves of the VMCS, so
    ; anything dumped before this call reads as zeros.  Dump here instead - the
    ; state is now exactly what VMLAUNCH is about to be handed, and the trace
    ; write still happens on the firmware stack.
    call    hv_dump_vmcs

    ; Diagnostic bail-out, from inside the trampoline so the dump above is the
    ; real launch state.  GPRs and RSP are still the firmware's at this point,
    ; so a plain RET goes back to hv_init.  See g_dry_run at the top of .data.
    cmp     qword ptr [g_dry_run], 0
    je      short enter_do_launch
    call    hv_dry_bail
    mov     rax, 2                      ; 2 = dry run, not a launch failure
    mov     rsp, [g_guest_regs+078h]    ; restore the ORIGINAL RSP before ret
    ret
enter_do_launch:

    mov     rax, [g_guest_regs+000h]
    mov     rbx, [g_guest_regs+008h]
    mov     rcx, [g_guest_regs+010h]
    mov     rdx, [g_guest_regs+018h]
    mov     rsi, [g_guest_regs+020h]
    mov     rdi, [g_guest_regs+028h]
    mov     rbp, [g_guest_regs+030h]
    mov     r8,  [g_guest_regs+038h]
    mov     r9,  [g_guest_regs+040h]
    mov     r10, [g_guest_regs+048h]
    mov     r11, [g_guest_regs+050h]
    mov     r12, [g_guest_regs+058h]
    mov     r13, [g_guest_regs+060h]
    mov     r14, [g_guest_regs+068h]
    mov     r15, [g_guest_regs+070h]
    mov     rsp, [g_guest_regs+078h]

    vmlaunch
    ; only reached when VMLAUNCH failed (invalid controls, bad guest state)
    mov     rax, 1
    ret
hv_enter ENDP

; guest RIP target: registers and stack are already restored by VMENTRY.
; EAX becomes the return value of hv_enter(): 0 means the guest is live.
hv_resume PROC
    xor     eax, eax
    ret
hv_resume ENDP

; ------------------------------------------------------------- exit path

; Root-mode faults (a bad dereference inside the handler, an NMI that slipped
; through) land here through the private host IDT instead of through whatever
; garbage the firmware IDT pointed at after ExitBootServices.  The guest state
; in the VMCS is still intact, so record what happened, let C fix the VMCS up
; and continue the guest - a broken hypercall then fails cleanly instead of
; taking the machine down.

PUBLIC hv_fatal_entry
hv_fatal_entry PROC
    mov     rax, [rsp]                  ; RIP (or error code for EC-class faults)
    mov     [g_fatal_frame0], rax
    mov     rax, [rsp+8]
    mov     [g_fatal_frame1], rax
    inc     qword ptr [g_fault_recoveries]
    call    hv_fault_recover
    jmp     hv_guest_resume
hv_fatal_entry ENDP

PUBLIC hv_exit_entry
hv_exit_entry PROC
    cli
    cld                                 ; the C ABI requires DF=0; the guest may
                                        ; have exited inside a REP MOVS

    ; Save the guest GPRs first: the SIMD path needs RAX/RCX/RDX as scratch and
    ; would otherwise destroy the values it is supposed to preserve.
    mov     [g_guest_regs+000h], rax
    mov     [g_guest_regs+008h], rbx
    mov     [g_guest_regs+010h], rcx
    mov     [g_guest_regs+018h], rdx
    mov     [g_guest_regs+020h], rsi
    mov     [g_guest_regs+028h], rdi
    mov     [g_guest_regs+030h], rbp
    mov     [g_guest_regs+038h], r8
    mov     [g_guest_regs+040h], r9
    mov     [g_guest_regs+048h], r10
    mov     [g_guest_regs+050h], r11
    mov     [g_guest_regs+058h], r12
    mov     [g_guest_regs+060h], r13
    mov     [g_guest_regs+068h], r14
    mov     [g_guest_regs+070h], r15

    ; Preserve the guest's full SIMD state.  XMM alone is not enough: the C
    ; handler clobbers the upper halves of YMM, and Windows/UE5 run AVX2.
    ; hv_init enables CR4.OSXSAVE and forces XCR0 to include x87+SSE before the
    ; guest starts, so XSAVE is always usable here when g_use_xsave is set.
    ; The mask passed in EDX:EAX must be exactly XCR0 (anything not enabled in
    ; XCR0 raises #GP), so read it back instead of assuming a value.
    cmp     qword ptr [g_use_xsave], 0
    je      exit_save_xmm
    xor     ecx, ecx
    xgetbv                              ; EDX:EAX = XCR0
    mov     rcx, [g_xsave_area]
    xsave64 [rcx]
    jmp     exit_dispatch
exit_save_xmm:
    mov     rcx, [g_xsave_area]
    movdqu  [rcx+000h], xmm0
    movdqu  [rcx+010h], xmm1
    movdqu  [rcx+020h], xmm2
    movdqu  [rcx+030h], xmm3
    movdqu  [rcx+040h], xmm4
    movdqu  [rcx+050h], xmm5
    movdqu  [rcx+060h], xmm6
    movdqu  [rcx+070h], xmm7
    movdqu  [rcx+080h], xmm8
    movdqu  [rcx+090h], xmm9
    movdqu  [rcx+0A0h], xmm10
    movdqu  [rcx+0B0h], xmm11
    movdqu  [rcx+0C0h], xmm12
    movdqu  [rcx+0D0h], xmm13
    movdqu  [rcx+0E0h], xmm14
    movdqu  [rcx+0F0h], xmm15
exit_dispatch:
    call    hv_handle_exit
    ; fall through: restore and resume
hv_exit_entry ENDP

; Shared resume tail.  Entered with the guest GPRs in g_guest_regs and the
; guest SIMD state in the xsave area - both static, so the fault path can jump
; here with an arbitrary stack.  SIMD is restored first because that needs
; scratch registers; the GPRs are loaded last, immediately before VMRESUME.
hv_guest_resume PROC
    cmp     qword ptr [g_use_xsave], 0
    je      resume_xmm
    xor     ecx, ecx
    xgetbv                              ; EDX:EAX = XCR0
    mov     rcx, [g_xsave_area]
    xrstor64 [rcx]
    jmp     resume_go
resume_xmm:
    mov     rcx, [g_xsave_area]
    movdqu  xmm0,  [rcx+000h]
    movdqu  xmm1,  [rcx+010h]
    movdqu  xmm2,  [rcx+020h]
    movdqu  xmm3,  [rcx+030h]
    movdqu  xmm4,  [rcx+040h]
    movdqu  xmm5,  [rcx+050h]
    movdqu  xmm6,  [rcx+060h]
    movdqu  xmm7,  [rcx+070h]
    movdqu  xmm8,  [rcx+080h]
    movdqu  xmm9,  [rcx+090h]
    movdqu  xmm10, [rcx+0A0h]
    movdqu  xmm11, [rcx+0B0h]
    movdqu  xmm12, [rcx+0C0h]
    movdqu  xmm13, [rcx+0D0h]
    movdqu  xmm14, [rcx+0E0h]
    movdqu  xmm15, [rcx+0F0h]
resume_go:
    mov     rax, [g_guest_regs+000h]
    mov     rbx, [g_guest_regs+008h]
    mov     rcx, [g_guest_regs+010h]
    mov     rdx, [g_guest_regs+018h]
    mov     rsi, [g_guest_regs+020h]
    mov     rdi, [g_guest_regs+028h]
    mov     rbp, [g_guest_regs+030h]
    mov     r8,  [g_guest_regs+038h]
    mov     r9,  [g_guest_regs+040h]
    mov     r10, [g_guest_regs+048h]
    mov     r11, [g_guest_regs+050h]
    mov     r12, [g_guest_regs+058h]
    mov     r13, [g_guest_regs+060h]
    mov     r14, [g_guest_regs+068h]
    mov     r15, [g_guest_regs+070h]

    vmresume
    ; resume failed - try a fresh launch, otherwise park the CPU
    vmlaunch
    jmp     $
hv_guest_resume ENDP

; void hv_invept(u64 eptp) - all-context invalidation, type 2.
PUBLIC hv_invept
hv_invept PROC
    mov     [g_invept_desc], rcx
    mov     qword ptr [g_invept_desc+8], 0
    mov     rax, 2
    lea     rdx, [g_invept_desc]
    invept  rax, xmmword ptr [rdx]
    ret
hv_invept ENDP

; u64 hv_xgetbv(void) - XCR0, requires CR4.OSXSAVE.
PUBLIC hv_xgetbv
hv_xgetbv PROC
    xor     ecx, ecx
    xgetbv
    shl     rdx, 32
    or      rax, rdx
    ret
hv_xgetbv ENDP

; void hv_xsetbv(u32 index, u64 value) - requires CR4.OSXSAVE and ring 0.
PUBLIC hv_xsetbv
hv_xsetbv PROC
    mov     r8, rdx
    mov     rax, rdx
    shr     r8, 32
    mov     rdx, r8
    xsetbv
    ret
hv_xsetbv ENDP

END

