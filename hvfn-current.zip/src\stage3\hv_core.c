/* hv_core.c - Stage-3 VMX bring-up, VMCS programming, VM-exit handling and the
 * hypercall dispatcher.
 *
 * Everything in this file executes either
 *   (a) during UEFI boot, from the self-relocated copy of the image that lives
 *       in EfiRuntimeServicesCode pages, or
 *   (b) in VMX root operation inside the VM-exit handler.
 * There is no CRT and no further use of boot services once the guest is
 * launched, so nothing here may allocate or call firmware.
 */
#include <intrin.h>
#include "hv.h"

/* Zero-initialised globals live in the relocated image, i.e. in memory that
 * firmware marks as runtime code/data and the OS never repurposes. */
HvContext  g_ctx;
GuestRegs  g_guest_regs;
HvContext* g_hv = &g_ctx;

EFI_BOOT_SERVICES* g_bs;
EFI_SYSTEM_TABLE*  g_st;

int _fltused = 0;   /* the optimiser references this even in integer-only code */

static u64 g_arena_cur;
static u64 g_arena_end;

static u64 arena_alloc(u64 bytes)
{
    u64 p;
    bytes = (bytes + HV_PAGE - 1) & ~(HV_PAGE - 1);
    if (!bytes || g_arena_cur + bytes > g_arena_end)
        return 0;
    p = g_arena_cur;
    g_arena_cur += bytes;
    mm_memset((void*)p, 0, bytes);
    return p;
}

static u64 rdmsr(u32 msr)         { return __readmsr((int)msr); }
static void wrmsr(u32 msr, u64 v) { __writemsr((int)msr, v); }

static u32 vmcs_ctl_adjust(u32 msr, u32 desired)
{
    u64 cap = rdmsr(msr);
    desired |= (u32)cap;               /* bits that must be 1 */
    desired &= (u32)(cap >> 32);       /* bits that must be 0 */
    return desired;
}

/* ------------------------------------------------------------- paging setup */

#define EPT_RWX     0x7ull
#define EPT_LARGE   0x80ull
#define EPT_MT_WB   (6ull << 3)          /* EPT memory type: write-back        */

/* Host page tables: identity map, 2 MiB leaves, first HV_HOST_COVER bytes.
 * Layout: PML4[k] -> PDPT -> one PD per GiB.  The host address space has to
 * cover physical RAM only: the exit handler never dereferences MMIO. */
static u64 build_host_tables(void)
{
    u64 pml4 = arena_alloc(HV_PAGE);
    u64 n_gib = HV_HOST_COVER >> 30;
    u64 g;

    if (!pml4 || !n_gib)
        return 0;

    for (g = 0; g < n_gib; ++g) {
        u64 k = g >> 9;                  /* PML4 index: one entry per 512 GiB */
        u64 pdpt = ((u64*)pml4)[k] & ~(HV_PAGE - 1);
        u64 pd;

        if (!pdpt) {
            pdpt = arena_alloc(HV_PAGE);
            if (!pdpt)
                return 0;
            ((u64*)pml4)[k] = pdpt | 0x3;   /* present | rw */
        }

        pd = arena_alloc(HV_PAGE);
        if (!pd)
            return 0;
        ((u64*)pdpt)[g & 511] = pd | 0x3;

        {
            u32 i;
            for (i = 0; i < 512; ++i)
                ((u64*)pd)[i] = ((g << 30) | ((u64)i << 21)) | 0x83;  /* p|rw|ps */
        }
    }
    return pml4;
}

/* EPT: identity map covering every physical address the guest can touch,
 * including 64-bit PCIe BARs, R/W/X on everything.  Uses 1 GiB leaves when the
 * CPU advertises them, otherwise 2 MiB leaves (one PD page per GiB).  Leaves
 * are marked write-back; the default (0) is uncacheable and turns all guest
 * RAM into MMIO-speed memory. */
static u64 build_ept(void)
{
    u64 pml4 = arena_alloc(HV_PAGE);
    u64 pdpt[2] = { 0, 0 };
    u64 n_gb = HV_EPT_COVER >> 30;
    u64 n_pdpt = (n_gb + 511) >> 9;
    u64 i, k;

    if (!pml4 || n_pdpt > 2)
        return 0;

    g_hv->ept_1g = (u32)((rdmsr(0x48C) >> 17) & 1);

    for (k = 0; k < n_pdpt; ++k) {
        pdpt[k] = arena_alloc(HV_PAGE);
        if (!pdpt[k])
            return 0;
        ((u64*)pml4)[k] = pdpt[k] | EPT_RWX;
    }

    if (g_hv->ept_1g) {
        for (i = 0; i < n_gb; ++i)
            ((u64*)pdpt[i >> 9])[i & 511] =
                (i << 30) | EPT_RWX | EPT_MT_WB | EPT_LARGE;
    } else {
        for (i = 0; i < n_gb; ++i) {
            u64 pd = arena_alloc(HV_PAGE);
            u32 j;
            if (!pd)
                return 0;
            ((u64*)pdpt[i >> 9])[i & 511] = pd | EPT_RWX;
            for (j = 0; j < 512; ++j)
                ((u64*)pd)[j] = ((i << 30) | ((u64)j << 21)) |
                                EPT_RWX | EPT_MT_WB | EPT_LARGE;
        }
    }
    return pml4;
}

/* Map the region containing gpa on demand.  Returns 1 when the instruction
 * that faulted can be retried, 0 when it is unrecoverable. */
static int ept_map_region(u64 gpa)
{
    u64 gib = gpa >> 30;
    u64 pi = gib >> 9;
    u64 pj = gib & 511;
    u64* pml4 = (u64*)g_hv->ept_pml4;
    u64 pdpt, entry;

    if (!pml4 || pi >= 512)
        return 0;

    pdpt = pml4[pi] & ~(HV_PAGE - 1);
    if (!pdpt) {
        pdpt = arena_alloc(HV_PAGE);
        if (!pdpt)
            return 0;
        pml4[pi] = pdpt | EPT_RWX;
    }

    entry = ((u64*)pdpt)[pj];
    if (entry & 1)
        return 0;                        /* already covered: the retry would loop */

    if (g_hv->ept_1g) {
        ((u64*)pdpt)[pj] = (gib << 30) | EPT_RWX | EPT_MT_WB | EPT_LARGE;
    } else {
        u64 pd = arena_alloc(HV_PAGE);
        u32 j;
        if (!pd)
            return 0;
        for (j = 0; j < 512; ++j)
            ((u64*)pd)[j] = ((gib << 30) | ((u64)j << 21)) |
                            EPT_RWX | EPT_MT_WB | EPT_LARGE;
        ((u64*)pdpt)[pj] = pd | EPT_RWX;
    }

    hv_invept(g_hv->eptp);
    return 1;
}

/* -------------------------------------------------------------- VMCS helpers */

#pragma pack(push, 1)
typedef struct { u16 limit; u64 base; } DescPtr;
#pragma pack(pop)

typedef struct { u16 sel; u64 base; u32 limit; u32 ar; } SegInfo;

static void seg_decode(u64 gdt_base, u16 sel, SegInfo* out)
{
    u64 raw;

    out->sel = sel;
    if (!sel) {
        out->base = 0;
        out->limit = 0;
        out->ar = 0x10000;                 /* unusable */
        return;
    }
    raw = *(const u64*)(gdt_base + (sel & ~7));
    out->base  = ((raw >> 16) & 0xFFFFFFull) | (((raw >> 56) & 0xFFull) << 24);
    out->limit = (u32)((raw & 0xFFFFull) | (((raw >> 48) & 0xFull) << 16));
    /* VMCS access-rights bits 11:8 are reserved; the descriptor's limit-high
     * nibble lives at 51:48 and must not leak into them.  Bits 15:12 are the
     * descriptor flags (G/D-B/L/AVL). */
    out->ar    = (u32)((raw >> 40) & 0xFFull) | (u32)(((raw >> 52) & 0xFull) << 12);
}

#pragma pack(push, 1)
typedef struct {
    u16 off0;
    u16 sel;
    u8  ist;
    u8  type;
    u16 off1;
    u32 off2;
    u32 zero;
} IdtGate;
#pragma pack(pop)

static void idt_gate(IdtGate* idt, u32 vec, u64 handler, u16 sel)
{
    idt[vec].off0 = (u16)(handler & 0xFFFF);
    idt[vec].sel = sel;
    idt[vec].ist = 0;
    idt[vec].type = 0x8E;            /* present, DPL 0, 64-bit interrupt gate */
    idt[vec].off1 = (u16)((handler >> 16) & 0xFFFF);
    idt[vec].off2 = (u32)(handler >> 32);
    idt[vec].zero = 0;
}

static void vmcs_seg(u32 sel_field, u32 base_field, u32 limit_field,
                     u32 ar_field, const SegInfo* s)
{
    hv_vmwrite(sel_field, s->sel);
    hv_vmwrite(base_field, s->base);
    hv_vmwrite(limit_field, s->limit);
    hv_vmwrite(ar_field, s->ar);
}

/* ------------------------------------------------- host-private descriptors */

#define HOST_SEL_CODE 0x08
#define HOST_SEL_DATA 0x10
/* 64-bit TSS descriptors are 16 bytes.  VM entry checks that the whole
 * descriptor sits inside the host GDTR limit (the architectural default is
 * 0xFFFF, but a GDT that only contains what we wrote does not).  Selector
 * 0x18 plus a 16-byte descriptor ends at 0x28; 0x18 plus an 8-byte one ends
 * at 0x20 and the high half is read past the table — a host-state check that
 * shuts the processor down instead of returning from VMLAUNCH. */
#define HOST_SEL_TSS  0x18

/* GDT with flat 64-bit code/data plus a TSS, and an IDT whose every vector
 * lands on the recovery stub.  The host-state area loads segment descriptors
 * from the GDT on each VM exit, so these cannot point at firmware tables that
 * the OS reclaims at ExitBootServices. */
static int build_host_priv(void)
{
    u64 gdt = arena_alloc(HV_PAGE);
    u64 idt = arena_alloc(HV_PAGE);
    u64 tss = arena_alloc(HV_PAGE);
    u64 base;
    u32 i;

    if (!gdt || !idt || !tss)
        return 0;

    ((u64*)gdt)[0] = 0;
    ((u64*)gdt)[1] = 0x00AF9A000000FFFFull;  /* code64: P|DPL0|S|exec/read|L */
    ((u64*)gdt)[2] = 0x00CF92000000FFFFull;  /* data:   P|DPL0|S|rw, G, D/B   */

    base = tss;
    ((u64*)gdt)[3] = 0x67ull                             /* limit 0x67       */
                   | ((base & 0xFFFFFFull) << 16)
                   /* Access byte 0x8B = present, DPL 0, S=0, type 11 = BUSY
                    * 64-bit TSS.  This must be busy, not available (0x89): VM
                    * entry loads the host TR from this descriptor, and it
                    * validates that the host TR is a busy 64-bit TSS.  Using
                    * type 9 here is a host-state violation at VM entry.
                    *
                    * The reference implementation (Hypervisor-From-Scratch) gets
                    * a busy descriptor for free by reusing the live TR selector,
                    * because LTR sets the busy bit in the GDT.  We cannot do
                    * that - our private GDT exists precisely because the
                    * firmware's lives in boot-services memory the OS reclaims -
                    * so the bit has to be set by hand. */
                   | (0x8Bull << 40)
                   | (((base >> 24) & 0xFFull) << 56);
    ((u64*)gdt)[4] = base >> 32;

    /* TSS.RSP0.  An IST-0 exception taken from ring 3 in root mode would push
     * onto RSP0; leaving it zero turns that into a fault inside the fault
     * handler.  Root operation is always ring 0 so this should never be used,
     * but a zero here is a trap waiting to happen. */
    if (g_hv->host_stack_top)
        *(u64*)(tss + 4) = g_hv->host_stack_top;

    for (i = 0; i < 256; ++i)
        idt_gate((IdtGate*)idt, i, (u64)&hv_fatal_entry, HOST_SEL_CODE);

    g_hv->host_gdt = gdt;
    g_hv->host_idt = idt;
    g_hv->host_tss = tss;
    return 1;
}

/* ---------------------------------------------------------------------- init */

static u32 g_launch_error;
static int g_probe_mode;

void hv_set_probe(int on) { g_probe_mode = on; }

u32 hv_launch_error(void) { return g_launch_error; }

/* "tag: value" into the trace file, so a freeze can be located to one call. */
static void trace_step(const char* tag, u64 v)
{
    char buf[64];
    char rev[24];
    int i = 0, j = 0;

    while (*tag && i < 40)
        buf[i++] = *tag++;
    buf[i++] = ':';
    buf[i++] = ' ';
    if (!v) {
        buf[i++] = '0';
    } else {
        while (v && j < 20) { rev[j++] = (char)('0' + (v % 10)); v /= 10; }
        while (j) buf[i++] = rev[--j];
    }
    buf[i] = 0;
    hv_trace(buf);
}

/* Host control registers derived from the guest's.
 *
 * The host tables are 4-level, so CR4.LA57 must be clear even if the guest
 * turns on 5-level paging.  CR4.CET must be clear too: with it set, root-mode
 * CALL/RET would use the *guest's* shadow stack (CET state is not switched
 * unless the exit/entry controls ask for it).  CR0.TS/EM would make the exit
 * stub's SSE instructions fault, so they are cleared as well. */
static u64 host_cr0(u64 gcr0)
{
    return (gcr0 | 0x80000021ull) & ~0xCull;     /* |PG|NE|PE, ~(EM|TS) */
}

static u64 host_cr4(u64 gcr4)
{
    u64 cr4 = (gcr4 | 0x2000ull) & ~(0x1000ull | 0x800000ull);

    /* The exit stub XSAVEs before the handler can sync anything, so the host
     * side must never lose OSXSAVE once hv_init has turned it on. */
    if (g_use_xsave)
        cr4 |= 0x40000ull;
    return cr4;                                    /* |VMXE, ~(LA57|CET) */
}

/* Called by the trampoline with the RSP/RIP the guest must resume with. */
void hv_prepare_guest(u64 guest_rsp, u64 guest_rip){
    DescPtr gdtr, idtr;
    SegInfo cs, ds, es, ss, fs, gs, tr, ldtr;
    u16 sels[8];
    u64 cr0, cr3, cr4, efer, flags, gsbase, fsbase;

    /* Entry marker: the last boot's trace stopped at 05c prelaunch with no
     * field dump, which means the stop is in here or in hv_dump_vmcs.  These
     * trace_file markers answer which without anyone having to read the screen:
     * the file is the only channel I can reliably inspect after a power-cycle. */
    trace_step("05pg0 enter", 0);
    hv_say("HvFn: prepare guest - enter");

    hv_read_segments(sels);
    hv_read_gdtr(&gdtr);
    hv_read_idtr(&idtr);

    seg_decode(gdtr.base, sels[0], &cs);
    seg_decode(gdtr.base, sels[1], &ds);
    seg_decode(gdtr.base, sels[2], &es);
    seg_decode(gdtr.base, sels[3], &ss);
    seg_decode(gdtr.base, sels[4], &fs);
    seg_decode(gdtr.base, sels[5], &gs);
    seg_decode(gdtr.base, sels[6], &tr);
    seg_decode(gdtr.base, sels[7], &ldtr);

    cr0 = (__readcr0() | rdmsr(0x486)) & rdmsr(0x487);
    cr3 = __readcr3();
    cr4 = (__readcr4() | rdmsr(0x488)) & rdmsr(0x489);
    efer = rdmsr(0xC0000080);
    gsbase = rdmsr(0xC0000101);
    fsbase = rdmsr(0xC0000100);

    hv_vmwrite(VMCS_GUEST_RIP, guest_rip);
    hv_vmwrite(VMCS_GUEST_RSP, guest_rsp);
    hv_vmwrite(VMCS_GUEST_RFLAGS, (__readeflags() | 0x2ull));

    vmcs_seg(VMCS_GUEST_CS_SELECTOR, VMCS_GUEST_CS_BASE, VMCS_GUEST_CS_LIMIT,
             VMCS_GUEST_CS_ACCESS_RIGHTS, &cs);
    vmcs_seg(VMCS_GUEST_DS_SELECTOR, VMCS_GUEST_DS_BASE, VMCS_GUEST_DS_LIMIT,
             VMCS_GUEST_DS_ACCESS_RIGHTS, &ds);
    vmcs_seg(VMCS_GUEST_ES_SELECTOR, VMCS_GUEST_ES_BASE, VMCS_GUEST_ES_LIMIT,
             VMCS_GUEST_ES_ACCESS_RIGHTS, &es);
    vmcs_seg(VMCS_GUEST_SS_SELECTOR, VMCS_GUEST_SS_BASE, VMCS_GUEST_SS_LIMIT,
             VMCS_GUEST_SS_ACCESS_RIGHTS, &ss);
    vmcs_seg(VMCS_GUEST_FS_SELECTOR, VMCS_GUEST_FS_BASE, VMCS_GUEST_FS_LIMIT,
             VMCS_GUEST_FS_ACCESS_RIGHTS, &fs);
    vmcs_seg(VMCS_GUEST_GS_SELECTOR, VMCS_GUEST_GS_BASE, VMCS_GUEST_GS_LIMIT,
             VMCS_GUEST_GS_ACCESS_RIGHTS, &gs);
    vmcs_seg(VMCS_GUEST_TR_SELECTOR, VMCS_GUEST_TR_BASE, VMCS_GUEST_TR_LIMIT,
             VMCS_GUEST_TR_ACCESS_RIGHTS, &tr);
    hv_vmwrite(VMCS_GUEST_LDTR_SELECTOR, ldtr.sel);
    hv_vmwrite(VMCS_GUEST_LDTR_BASE, ldtr.base);
    hv_vmwrite(VMCS_GUEST_LDTR_LIMIT, ldtr.limit);
    hv_vmwrite(VMCS_GUEST_LDTR_ACCESS_RIGHTS, ldtr.ar);

    hv_vmwrite(VMCS_GUEST_FS_BASE, fsbase);
    hv_vmwrite(VMCS_GUEST_GS_BASE, gsbase);
    hv_vmwrite(VMCS_GUEST_GDTR_BASE, gdtr.base);
    hv_vmwrite(VMCS_GUEST_GDTR_LIMIT, gdtr.limit);
    hv_vmwrite(VMCS_GUEST_IDTR_BASE, idtr.base);
    hv_vmwrite(VMCS_GUEST_IDTR_LIMIT, idtr.limit);

    hv_vmwrite(VMCS_GUEST_CR0, cr0);
    hv_vmwrite(VMCS_GUEST_CR3, cr3);
    /* Keep VMXE set in the GUEST CR4 as well as the host's.  Clearing it made
     * the guest stop entering entirely on this part (the guest-state CR4 check
     * evidently requires VMXE=1 here).  The probe guest does NOT execute VMCALL
     * (which is the instruction whose behaviour changes under nested-VMX), so
     * leaving VMXE set is harmless: ud2 -> #UD -> exit 0 works either way. */
    hv_vmwrite(VMCS_GUEST_CR4, cr4);
    hv_vmwrite(VMCS_GUEST_EFER, efer);
    hv_vmwrite(VMCS_GUEST_DR7, 0x400);
    hv_vmwrite(VMCS_GUEST_ACTIVITY_STATE, 0);
    hv_vmwrite(VMCS_GUEST_INTERRUPTIBILITY_STATE, 0);
    hv_vmwrite(VMCS_GUEST_PENDING_DEBUG_EXCEPTIONS, 0);
    hv_vmwrite(VMCS_GUEST_VMCS_LINK_POINTER, ~0ull);
    hv_vmwrite(VMCS_GUEST_SYSENTER_CS, rdmsr(0x174));
    hv_vmwrite(VMCS_GUEST_SYSENTER_ESP, rdmsr(0x175));
    hv_vmwrite(VMCS_GUEST_SYSENTER_EIP, rdmsr(0x176));

    /* ---- give the guest a fully-consistent flat GDT ---------------------
     *
     * VM entry validates the guest TR by reading its descriptor OUT OF THE
     * GUEST GDT, not from the VMCS.  The firmware's STR returns 0 and its GDT
     * contains no TSS anywhere, so any TR selector we write into a GDT that is
     * still the firmware's is still invalid - which is why the first attempt
     * (TR=0x18 while gdtrbase stayed 0x39A00000) changed nothing.
     *
     * Switch the guest to our own flat GDT, already built in the arena and
     * identity-mapped so the guest reaches it exactly as the host does:
     *   [1] code64 @0x08   [2] data @0x10   [3] busy 64-bit TSS @0x18.
     * That forces every guest selector to be swapped to match, since the old
     * firmware selectors (CS 0x38, SS 0x30) would be out of range in a 6-entry
     * GDT.  For the probe guest - two stores and a VMCALL - the flat state is
     * all it needs. */
    hv_vmwrite(VMCS_GUEST_GDTR_BASE, g_hv->host_gdt);
    hv_vmwrite(VMCS_GUEST_GDTR_LIMIT, 0x2F);

    hv_vmwrite(VMCS_GUEST_CS_SELECTOR, HOST_SEL_CODE);       /* 0x08 */
    hv_vmwrite(VMCS_GUEST_CS_BASE, 0);
    hv_vmwrite(VMCS_GUEST_CS_LIMIT, 0xFFFFF);
    hv_vmwrite(VMCS_GUEST_CS_ACCESS_RIGHTS, 0xA09B);        /* code64, L=1 */

    hv_vmwrite(VMCS_GUEST_SS_SELECTOR, HOST_SEL_DATA);       /* 0x10 */
    hv_vmwrite(VMCS_GUEST_SS_BASE, 0);
    hv_vmwrite(VMCS_GUEST_SS_LIMIT, 0xFFFFF);
    hv_vmwrite(VMCS_GUEST_SS_ACCESS_RIGHTS, 0xC093);        /* r/w data */

    /* Flat-64 "null-everything-else" convention: in 64-bit mode ES/DS/FS/GS
     * are not used for addressing (FS/GS base comes from the base fields), so
     * the hidden descriptor cache wants them NULL with the unusable bit set,
     * not "usable data".  A usable FS/GS with a stale/non-canonical base is a
     * known zero-feedback microcode wedge on desktop Raptor Lake; nulling the
     * selector and marking it unusable removes the whole class. */
    hv_vmwrite(VMCS_GUEST_DS_SELECTOR, 0);
    hv_vmwrite(VMCS_GUEST_DS_BASE, 0);
    hv_vmwrite(VMCS_GUEST_DS_LIMIT, 0);
    hv_vmwrite(VMCS_GUEST_DS_ACCESS_RIGHTS, 0x10000);

    hv_vmwrite(VMCS_GUEST_ES_SELECTOR, 0);
    hv_vmwrite(VMCS_GUEST_ES_BASE, 0);
    hv_vmwrite(VMCS_GUEST_ES_LIMIT, 0);
    hv_vmwrite(VMCS_GUEST_ES_ACCESS_RIGHTS, 0x10000);

    hv_vmwrite(VMCS_GUEST_FS_SELECTOR, 0);
    hv_vmwrite(VMCS_GUEST_FS_BASE, 0);
    hv_vmwrite(VMCS_GUEST_FS_LIMIT, 0);
    hv_vmwrite(VMCS_GUEST_FS_ACCESS_RIGHTS, 0x10000);

    hv_vmwrite(VMCS_GUEST_GS_SELECTOR, 0);
    hv_vmwrite(VMCS_GUEST_GS_BASE, 0);
    hv_vmwrite(VMCS_GUEST_GS_LIMIT, 0);
    hv_vmwrite(VMCS_GUEST_GS_ACCESS_RIGHTS, 0x10000);

    hv_vmwrite(VMCS_GUEST_TR_SELECTOR, HOST_SEL_TSS);        /* 0x18 */
    hv_vmwrite(VMCS_GUEST_TR_BASE, g_hv->host_tss);
    hv_vmwrite(VMCS_GUEST_TR_LIMIT, 0x67);
    hv_vmwrite(VMCS_GUEST_TR_ACCESS_RIGHTS, 0x8B);           /* busy 64-bit TSS */

    hv_vmwrite(VMCS_GUEST_LDTR_SELECTOR, 0);
    hv_vmwrite(VMCS_GUEST_LDTR_BASE, 0);
    hv_vmwrite(VMCS_GUEST_LDTR_LIMIT, 0);
    hv_vmwrite(VMCS_GUEST_LDTR_ACCESS_RIGHTS, 0x10000);      /* unusable */

    /* host side: same context, our own address space and stack */
    hv_vmwrite(VMCS_HOST_CR0, host_cr0(cr0));
    hv_vmwrite(VMCS_HOST_CR3, g_hv->host_cr3);
    hv_vmwrite(VMCS_HOST_CR4, host_cr4(cr4));
    hv_vmwrite(VMCS_HOST_EFER, efer);
    /* Host selectors point at our own GDT in the arena.  The firmware's GDT
     * and IDT live in boot-services memory that the OS frees and reuses, so
     * using them would mean loading descriptors out of garbage after the
     * handover. */
    hv_vmwrite(VMCS_HOST_CS_SELECTOR, HOST_SEL_CODE);
    hv_vmwrite(VMCS_HOST_SS_SELECTOR, HOST_SEL_DATA);
    hv_vmwrite(VMCS_HOST_DS_SELECTOR, HOST_SEL_DATA);
    hv_vmwrite(VMCS_HOST_ES_SELECTOR, HOST_SEL_DATA);
    hv_vmwrite(VMCS_HOST_FS_SELECTOR, HOST_SEL_DATA);
    hv_vmwrite(VMCS_HOST_GS_SELECTOR, HOST_SEL_DATA);
    hv_vmwrite(VMCS_HOST_TR_SELECTOR, HOST_SEL_TSS);
    hv_vmwrite(VMCS_HOST_TR_BASE, g_hv->host_tss);
    hv_vmwrite(VMCS_HOST_FS_BASE, fsbase);
    hv_vmwrite(VMCS_HOST_GS_BASE, gsbase);
    hv_vmwrite(VMCS_HOST_GDTR_BASE, g_hv->host_gdt);
    hv_vmwrite(VMCS_HOST_IDTR_BASE, g_hv->host_idt);
    hv_vmwrite(VMCS_HOST_SYSENTER_CS, 0);
    hv_vmwrite(VMCS_HOST_SYSENTER_ESP, 0);
    hv_vmwrite(VMCS_HOST_SYSENTER_EIP, 0);
    hv_vmwrite(VMCS_HOST_RSP, g_hv->host_stack_top);
    if (g_stage_a) {
        /* Probe launch: the guest's first instruction is the probe stub, and
         * the host's first exit lands in the one-shot teardown stub.  That
         * removes both of the production paths that could be responsible - the
         * guest entry stub (a RET on the firmware stack) and the exit path
         * (which resumes the guest) - leaving VM entry itself as the only
         * variable. */
        hv_vmwrite(VMCS_GUEST_RIP, (u64)&hv_guest_probe);
        hv_vmwrite(VMCS_HOST_RIP,  (u64)&hv_probe_exit);
    } else {
        hv_vmwrite(VMCS_HOST_RIP, (u64)&hv_exit_entry);
    }

    flags = __readeflags();   /* keeps the stores above ordered before VMLAUNCH */
    (void)flags;

    /* Exit marker.  If the trace ends at "05pg0 enter", the stop is in the
     * segment reads / seg_decode.  If it reaches "05pg9 done", the stop is
     * downstream in hv_dump_vmcs. */
    trace_step("05pg9 done", 0);
    hv_say("HvFn: guest prepared");
}

static int vmcs_configure(void)
{
    u32 pin, proc, proc2, exitc, entryc;

    pin    = vmcs_ctl_adjust(0x481, (1u << 3));      /* NMI exiting           */
    /* Bit 28 is "use MSR bitmaps".  Without it every RDMSR/WRMSR in the guest
     * raises a VM exit and, since we do not emulate them, loops forever.  Bit
     * 9 (INVLPG exiting) is enabled only until the first kernel-context sample
     * is captured: it is the cheapest reliable way to observe a ring-0 exit
     * during Windows boot, and hv_handle_exit clears it afterwards. */
    proc   = vmcs_ctl_adjust(0x482, (1u << 31) | (1u << 28) | (1u << 9));
    /* RDTSCP, INVPCID, XSAVES/XRSTORS and USER_WAIT_PAUSE.  EPT (bit 1) is
     * deliberately OFF for the first resume: with no EPT the guest's own CR3 is
     * the only translation and EDK2's CPL0 identity map works unchanged.  EPT
     * adds isolation and speed but also a whole new failure class (EPT-violation
     * loops, EPTP misconfig, memory-type errors) - enable it only after Windows
     * boots.  With secondary clear these four all #UD in non-root while CPUID
     * advertises them, and the Windows loader uses INVPCID/XSAVES in TLB flushes
     * and context switches, so they MUST be on now. */
    proc2  = vmcs_ctl_adjust(0x48B, (1u << 3) | (1u << 12) | (1u << 20) | (1u << 26));
    exitc  = vmcs_ctl_adjust(0x483, (1u << 9) | (1u << 2) | (1u << 1) | (1u << 20) | (1u << 21));
    entryc = vmcs_ctl_adjust(0x484, (1u << 9) | (1u << 2));

    if (!(proc & (1u << 31)))
        return 0;                      /* secondary controls unavailable */
    if (!(proc & (1u << 28)))
        return 0;                      /* no MSR bitmaps: cannot run a guest */

    g_hv->have_rdtscp = (proc2 & (1u << 3)) ? 1 : 0;
    g_hv->have_invpcid = (proc2 & (1u << 12)) ? 1 : 0;
    g_hv->have_xsaves = (proc2 & (1u << 20)) ? 1 : 0;
    g_use_xsave = g_hv->have_xsaves;

    hv_vmwrite(VMCS_CTRL_PIN_BASED_VM_EXECUTION_CONTROLS, pin);
    hv_vmwrite(VMCS_CTRL_PROCESSOR_BASED_VM_EXECUTION_CONTROLS, proc);
    hv_vmwrite(VMCS_CTRL_SECONDARY_PROCESSOR_BASED_VM_EXECUTION_CONTROLS, proc2);
    hv_vmwrite(VMCS_CTRL_VMEXIT_CONTROLS, exitc);
    hv_vmwrite(VMCS_CTRL_VMENTRY_CONTROLS, entryc);

    /* CR0/CR4 guest-host masks: the capability-mandated must-be-1 bits plus
     * VMXE.  With the masks at 0 the guest's CR0/CR4 writes are never captured
     * and the VMCS control-register fields go stale; setting the masks to the
     * fixed bits makes a guest write to one of them exit so the handler can
     * update the read shadow and the VMCS fields. */
    hv_vmwrite(VMCS_CTRL_CR0_GUEST_HOST_MASK, rdmsr(0x486) & 0xFFFFFFFF);
    hv_vmwrite(VMCS_CTRL_CR4_GUEST_HOST_MASK, (rdmsr(0x488) & 0xFFFFFFFF) | (1ull << 13));
    hv_vmwrite(VMCS_CTRL_CR0_READ_SHADOW, __readcr0());
    hv_vmwrite(VMCS_CTRL_CR4_READ_SHADOW, __readcr4());

    if (g_stage_a) {
        /* Minimal VMCS for the probe launch.
         *
         * The probe guest writes one page and executes VMCALL; it needs no EPT,
         * no MSR bitmaps and no exception bitmap - and each of those is one
         * more field that could make VM entry fail.  With secondary controls
         * clear there is no EPT translation at all, so the guest's own page
         * tables produce host-physical addresses directly.  That is correct
         * here because the firmware runs identity-mapped.
         *
         * Starting minimal and adding one thing at a time is the only way to
         * tell "VM entry is broken" from "one of my extra fields is broken". */
        hv_vmwrite(VMCS_CTRL_SECONDARY_PROCESSOR_BASED_VM_EXECUTION_CONTROLS, 0);

        /* NO extra control bits here.
         *
         * The previous revision OR'd "unconditional I/O exiting" (bit 24) into
         * the primary controls WITHOUT sanitizing it against
         * IA32_VMX_PROCBASED_CTLS.  That is the one control bit in the entire
         * launch that never went through vmcs_ctl_adjust, and if bit 24 is not
         * an allowed-1 bit on this part it is a reserved control bit - which is
         * precisely the abort-class failure the hardware shows as a hang with
         * no error code rather than a clean rejection.
         *
         * It is also unnecessary: the probe guest's VMCALL is in the SDM
         * 25.1.2 unconditional-exit list and produces exit reason 18 with no
         * control bit at all.  The guest probe now relies on VMCALL alone. */
        /* All exceptions exit.  With the bitmap at 0, a guest #PF/#GP/#UD
         * vectors into the GUEST IDT while the CPU is still in non-root; the
         * firmware handler can then execute HLT (which, with HLT-exiting
         * clear, halts the logical processor forever - a silent 30s wedge with
         * no VM exit).  With every exception intercepted, any guest fault
         * becomes a clean exit (reason 0) that the one-shot stub records,
         * turning a wedge into a diagnosis. */
        hv_vmwrite(VMCS_CTRL_EXCEPTION_BITMAP, 0xFFFFFFFFu);
        return 1;
    }

    /* EPT is OFF for the first resume, so do NOT write the EPTP. */
    /* A zeroed bitmap intercepts nothing: RDMSR/WRMSR pass straight through,
     * including the APIC MSRs an x2APIC guest uses.  (MSR bitmap stays all-zero
     * until Windows is up - the guest must genuinely write EFER/PAT/SYSENTER/
     * APIC_BASE/MTRRs.) */
    hv_vmwrite(VMCS_CTRL_MSR_BITMAP_ADDRESS, g_hv->msr_bitmap);

    /* Intercept only the faults that matter during bring-up: #PF, #GP, #UD,
     * #DF, #TS, #MC.  NOT all-ones - a full bitmap means every legitimate
     * firmware fault round-trips through us before the guest has booted
     * anything, and one reinjection bug is an instant triple fault. */
    hv_vmwrite(VMCS_CTRL_EXCEPTION_BITMAP,
               (1u << 14) | (1u << 13) | (1u << 6) | (1u << 8) | (1u << 10) | (1u << 18));
    return 1;
}

/* Runs as the guest, in firmware ring 0, right after launch: a VMCALL round
 * trip proves that exits, the handler and the resume path all work. */
static int hv_selftest(void)
{
    HvRequest req;

    mm_memset(&req, 0, sizeof(req));
    req.op = HV_OP_PING;
    hv_vmcall(HVFN_MAGIC, (u64)&req);
    return (req.status == HV_OK && req.out[1] == HVFN_BUILD_ID) ? 1 : 0;
}

/* Every VMCS field that VM entry validates, dumped immediately before the
 * launch.
 *
 * A VM entry rejected for bad control, host or guest state is supposed to write
 * a reason into the VM-instruction-error field and return to the instruction
 * after VMLAUNCH.  On this machine it does not return at all, so the error path
 * is unreachable and the only way to find the offending field is to capture the
 * whole state and check it against the SDM's requirements by hand. */
typedef struct { u32 field; const char* tag; } VmcsDumpField;
static const VmcsDumpField kLaunchDump[] = {
    { VMCS_CTRL_PIN_BASED_VM_EXECUTION_CONTROLS,                 "c0 pinbased"   },
    { VMCS_CTRL_PROCESSOR_BASED_VM_EXECUTION_CONTROLS,           "c1 procbased"  },
    { VMCS_CTRL_SECONDARY_PROCESSOR_BASED_VM_EXECUTION_CONTROLS, "c2 procbased2" },
    { VMCS_CTRL_VMEXIT_CONTROLS,                                 "c3 exitctl"    },
    { VMCS_CTRL_VMENTRY_CONTROLS,                                "c4 entryctl"   },
    { VMCS_CTRL_EXCEPTION_BITMAP,                                "c5 excbitmap"  },
    { VMCS_CTRL_CR0_GUEST_HOST_MASK,                             "c6 cr0mask"    },
    { VMCS_CTRL_CR4_GUEST_HOST_MASK,                             "c7 cr4mask"    },
    { VMCS_CTRL_CR3_TARGET_COUNT,                                "c8 cr3tgtcnt"  },
    { VMCS_CTRL_VMENTRY_MSR_LOAD_COUNT,                          "c9 entrymsrcnt"},
    { VMCS_CTRL_VMEXIT_MSR_STORE_COUNT,                          "ca exmsrstore" },
    { VMCS_CTRL_VMEXIT_MSR_LOAD_COUNT,                           "cb exmsrload"  },
    { VMCS_CTRL_EPT_POINTER,                                     "cc eptp"       },
    { VMCS_CTRL_MSR_BITMAP_ADDRESS,                              "cd msrbitmap"  },
    { VMCS_GUEST_VMCS_LINK_POINTER,                              "d0 linkptr"    },
    { VMCS_GUEST_CR0,                                            "d1 guestcr0"   },
    { VMCS_GUEST_CR3,                                            "d2 guestcr3"   },
    { VMCS_GUEST_CR4,                                            "d3 guestcr4"   },
    { VMCS_GUEST_EFER,                                           "d4 guestefer"  },
    { VMCS_GUEST_DR7,                                            "d5 guestdr7"   },
    { VMCS_GUEST_RSP,                                            "d6 guestrsp"   },
    { VMCS_GUEST_RIP,                                            "d7 guestrip"   },
    { VMCS_GUEST_RFLAGS,                                         "d8 grflags"    },
    { VMCS_GUEST_ACTIVITY_STATE,                                 "d9 activity"   },
    { VMCS_GUEST_INTERRUPTIBILITY_STATE,                         "da intrstate"  },
    { VMCS_GUEST_PENDING_DEBUG_EXCEPTIONS,                       "db penddbg"    },
    { VMCS_GUEST_SYSENTER_CS,                                    "dc sysentercs" },
    { VMCS_GUEST_CS_SELECTOR,                                    "e0 cssel"      },
    { VMCS_GUEST_CS_BASE,                                        "e1 csbase"     },
    { VMCS_GUEST_CS_LIMIT,                                       "e2 cslimit"    },
    { VMCS_GUEST_CS_ACCESS_RIGHTS,                               "e3 csar"       },
    { VMCS_GUEST_SS_SELECTOR,                                    "e4 sssel"      },
    { VMCS_GUEST_SS_ACCESS_RIGHTS,                               "e5 ssar"       },
    { VMCS_GUEST_TR_SELECTOR,                                    "e6 trsel"      },
    { VMCS_GUEST_TR_BASE,                                        "e7 trbase"     },
    { VMCS_GUEST_TR_LIMIT,                                       "e8 trlimit"    },
    { VMCS_GUEST_TR_ACCESS_RIGHTS,                               "e9 trar"       },
    { VMCS_GUEST_LDTR_SELECTOR,                                  "ea ldtrsel"    },
    { VMCS_GUEST_LDTR_ACCESS_RIGHTS,                             "eb ldtrar"     },
    { VMCS_GUEST_GDTR_BASE,                                      "ec gdtrbase"   },
    { VMCS_GUEST_IDTR_BASE,                                      "ed idtrbase"   },
    { VMCS_HOST_CR0,                                             "f0 hostcr0"    },
    { VMCS_HOST_CR3,                                             "f1 hostcr3"    },
    { VMCS_HOST_CR4,                                             "f2 hostcr4"    },
    { VMCS_HOST_EFER,                                            "f3 hostefer"   },
    { VMCS_HOST_RSP,                                             "f4 hostrsp"    },
    { VMCS_HOST_RIP,                                             "f5 hostrip"    },
    { VMCS_HOST_CS_SELECTOR,                                     "f6 hostcs"     },
    { VMCS_HOST_TR_SELECTOR,                                     "f7 hosttr"     },
    { VMCS_HOST_TR_BASE,                                         "f8 hosttrbase" },
    { VMCS_HOST_GDTR_BASE,                                       "f9 hostgdtr"   },
    { VMCS_HOST_IDTR_BASE,                                       "fa hostidtr"   },
};

/* ------------------------------------------------------- console reporting
 *
 * The trace file cannot debug a hang.  It is written through the ESP via
 * SimpleFileSystem, so anything after the freeze is lost and every failure mode
 * looks identical from the outside - which is exactly why several reboots have
 * produced "the trace ends at 05c and nothing else".
 *
 * Text written to ConOut is emitted BEFORE the freeze and stays on screen, so
 * the last line visible names the stage that stopped.  This is the only
 * instrument here that survives the failure it is meant to diagnose.
 */
void hv_say(const char* msg)
{
    CHAR16 buf[176];
    int i = 0;

    if (!g_st || !g_st->ConOut || !g_st->ConOut->OutputString)
        return;

    while (msg[i] && i < 160) {
        buf[i] = (CHAR16)msg[i];
        ++i;
    }
    buf[i++] = (CHAR16)'\r';
    buf[i++] = (CHAR16)'\n';
    buf[i] = 0;
    g_st->ConOut->OutputString(g_st->ConOut, buf);
}

/* tag: 0x<hex> - hex because every one of these fields is inspected bitwise */
static void say_hex(const char* tag, u64 v)
{
    char b[192];
    char rev[24];
    int i = 0, j = 0;

    while (tag[i] && i < 56) { b[i] = tag[i]; ++i; }
    b[i++] = ':';
    b[i++] = ' ';
    b[i++] = '0';
    b[i++] = 'x';
    if (!v) {
        b[i++] = '0';
    } else {
        while (v && j < 20) { rev[j++] = (char)(v & 0xF); v >>= 4; }
        while (j) {
            char c = rev[--j];
            b[i++] = (char)(c < 10 ? ('0' + c) : ('a' + c - 10));
        }
    }
    b[i] = 0;
    hv_say(b);
}

/* Write every field VM entry validates to the trace.
 *
 * This MUST be called from inside the launch trampoline, immediately after
 * hv_prepare_guest and immediately before VMLAUNCH: hv_prepare_guest is what
 * fills the guest and host halves, so calling this any earlier reads zeros.
 * That is exactly the mistake the first dry run made - it dumped the state a
 * step before it existed and showed nothing but zeroes. */
void hv_dump_vmcs(void)
{
    /* Console FIRST, trace file LAST.
     *
     * The last boot reached 05c prelaunch and then wrote NO field dump to the
     * trace file.  That localises the stop to this function or hv_prepare_guest,
     * but the trace loop was running before any console output, so the two are
     * indistinguishable.  The console survives a hang; the trace file does not.
     * Print the fields and the launch marker first, then dump to the file - so
     * the screen always tells us how far we got even if the file write is the
     * thing that wedges. */
    trace_step("05dv0 enter", 0);
    hv_say("HvFn: launch state ------------");
    say_hex("linkptr",  hv_vmread(VMCS_GUEST_VMCS_LINK_POINTER));
    say_hex("cs.ar",    hv_vmread(VMCS_GUEST_CS_ACCESS_RIGHTS));
    say_hex("cs.base",  hv_vmread(VMCS_GUEST_CS_BASE));
    say_hex("ss.ar",    hv_vmread(VMCS_GUEST_SS_ACCESS_RIGHTS));
    say_hex("tr.sel",   hv_vmread(VMCS_GUEST_TR_SELECTOR));
    say_hex("tr.ar",    hv_vmread(VMCS_GUEST_TR_ACCESS_RIGHTS));
    say_hex("tr.limit", hv_vmread(VMCS_GUEST_TR_LIMIT));
    say_hex("tr.base",  hv_vmread(VMCS_GUEST_TR_BASE));
    say_hex("g.efer",   hv_vmread(VMCS_GUEST_EFER));
    say_hex("h.efer",   hv_vmread(VMCS_HOST_EFER));
    say_hex("g.cr0",    hv_vmread(VMCS_GUEST_CR0));
    say_hex("g.cr4",    hv_vmread(VMCS_GUEST_CR4));
    say_hex("h.cr0",    hv_vmread(VMCS_HOST_CR0));
    say_hex("h.cr4",    hv_vmread(VMCS_HOST_CR4));
    say_hex("h.rsp",    hv_vmread(VMCS_HOST_RSP));
    say_hex("h.rip",    hv_vmread(VMCS_HOST_RIP));
    say_hex("guestrip", hv_vmread(VMCS_GUEST_RIP));
    say_hex("entryctl", hv_vmread(VMCS_CTRL_VMENTRY_CONTROLS));
    say_hex("exitctl",  hv_vmread(VMCS_CTRL_VMEXIT_CONTROLS));
    say_hex("proc",     hv_vmread(VMCS_CTRL_PROCESSOR_BASED_VM_EXECUTION_CONTROLS));
    say_hex("proc2",    hv_vmread(VMCS_CTRL_SECONDARY_PROCESSOR_BASED_VM_EXECUTION_CONTROLS));
    say_hex("pin",      hv_vmread(VMCS_CTRL_PIN_BASED_VM_EXECUTION_CONTROLS));

    if (g_report) {
        g_report->launches++;
        say_hex("launch #", g_report->launches);
    }
    /* Console block done: the 21 fields are on screen.  Mark the file so we
     * know whether the stop is in the console block above or the trace loop
     * below. */
    trace_step("05dv1 console done", 0);

    /* Full 52-field dump to the trace file, for offline diffing.  Placed in the
     * MIDDLE: if this file I/O wedges, the field block above is already on
     * screen but the marker below never appears - which is how we tell a trace
     * hang apart from a genuine in-entry stop. */
    {
        u32 i;
        for (i = 0; i < (u32)(sizeof(kLaunchDump) / sizeof(kLaunchDump[0])); ++i)
            trace_step(kLaunchDump[i].tag, hv_vmread(kLaunchDump[i].field));
    }

    /* Last line before the launch.  If the screen shows this and then freezes,
     * the stop is inside VMLAUNCH - nothing in our code runs after it. */
    trace_step("05dv2 launching", 0);
    hv_say("HvFn: VMLAUNCHING NOW >>>>");
}

/* Called from the trampoline, after hv_dump_vmcs and instead of VMLAUNCH when
 * the diagnostic switch is on.  Leaving VMX and returning normally means the
 * boot always reaches Windows - there is no VM entry to fail.  GPRs are not
 * preserved across this, which is fine because the trampoline returns straight
 * afterwards rather than restoring them. */
static int g_dry_done;

/* The firmware's real IDT descriptor, captured before the pre-VMX catcher
 * temporarily replaces it.  The catcher is a window around VMXON only; once
 * VMXON has succeeded it MUST be unloaded, otherwise every subsequent fault
 * redirects through the stale g_fault_resume pointer (still aimed at the
 * probe's resume stub) and unwinds a frame it does not own - a hang that moves
 * around unpredictably, which is exactly what we were seeing. */
u8 g_fw_idtr[10];
u8 g_fw_gdtr[10];

HvReport* g_report;

/* Write the launch-probe report page to the trace.
 *
 * Called by the host after the first VM exit has torn VMX down, so boot
 * services are still available and the page is still intact.  `magic` set means
 * the guest executed its first instruction, i.e. VM entry succeeded - that is
 * the one fact this project has never been able to establish. */
void hv_publish_report(const char* tag)
{
    trace_step(tag, g_report ? g_report->magic : 0);
    if (!g_report)
        return;
    trace_step("r1 magic",         g_report->magic);
    trace_step("r2 guest_ran",     g_report->guest_ran);
    trace_step("r3 launches",      g_report->launches);
    trace_step("r4 exited",        g_report->exited);
    trace_step("r5 exit_reason",   g_report->exit_reason);
    trace_step("r6 exit_qual",     g_report->exit_qual);
    trace_step("r7 exit_rip",      g_report->exit_rip);
    trace_step("r8 vmcall_missed", g_report->vmcall_missed);
    trace_step("r9 intr_info",     g_report->exit_intr_info);
    trace_step("ra intr_err",      g_report->exit_intr_err);
    trace_step("rb cr2",           g_report->exit_cr2);
}

void hv_dry_bail(void)
{
    hv_trace("05c0 DRY RUN - launch state dumped, VMXOFF instead of VMLAUNCH");
    hv_vmxoff();
    {
        u64 cr4 = __readcr4();
        __writecr4(cr4 & ~0x2000ull);
    }
    g_dry_done = 1;
}

int hv_init(void)
{
    EFI_STATUS st;    EFI_PHYSICAL_ADDRESS arena = 0;
    u64 pages = (16ull * 1024 * 1024) >> 12;
    u64 vmxon, vmcs, msrbitmap, basic;
    int r[4];

    /* CMOS proof-of-entry verdict, written to the TRACE so it survives a
     * power-cycle without anyone having to read a screen.  The probe guest
     * wrote 0x5A to CMOS[0x4F] as its first instruction; 0x5A here means the
     * previous VMLAUNCH really entered the guest, anything else means it did
     * not.  Cleared after reading so the next cycle is clean. */
    {
        u8 cm;
        hv_outb(0x70, 0x4F);
        cm = hv_inb(0x71);
        trace_step("cmos prev", cm);
        hv_outb(0x70, 0x4F);
        hv_outb(0x71, 0x00);
    }

    __cpuid(r, 1);
    if (!((u32)r[2] & (1u << 5)))
        return -1;                      /* CPU has no VMX */
    trace_step("05a1 cpuid ok", (u32)r[2] & (1u << 5));

    {
        u64 fc = rdmsr(0x3A);
        trace_step("05a2 feature_control", fc);
        if (!(fc & 1)) {
            fc |= 1 | (1u << 2);
            wrmsr(0x3A, fc);
            fc = rdmsr(0x3A);
            trace_step("05a2b feature_control after write", fc);
        }
        if (!(fc & (1u << 2)))
            return -2;                  /* VT-x disabled in firmware */
    }

    st = g_bs->AllocatePages(AllocateAnyPages, EfiRuntimeServicesData, pages, &arena);
    trace_step("05a3 allocate status", (u64)st);
    if (EFI_ERROR(st) || !arena)
        return -3;

    g_arena_cur = arena;
    g_arena_end = arena + pages * HV_PAGE;
    g_hv->arena_base = arena;
    g_hv->arena_end = g_arena_end;
    g_hv->regs = &g_guest_regs;

    g_hv->host_cr3 = build_host_tables();
    trace_step("05a4 host tables", g_hv->host_cr3);
    if (!g_hv->host_cr3)
        return -4;

    g_hv->ept_pml4 = build_ept();
    trace_step("05a5 ept", g_hv->ept_pml4);
    if (!g_hv->ept_pml4)
        return -5;
    g_hv->eptp = g_hv->ept_pml4 | 6ull | (3ull << 3);

    vmxon = arena_alloc(HV_PAGE);
    vmcs = arena_alloc(HV_PAGE);
    msrbitmap = arena_alloc(HV_PAGE);
    {
        u64 stack = arena_alloc(HV_HOST_STACK_SIZE);
        /* The exit stub CALLs the handler without its own frame, so the
         * handler's 32-byte shadow space lives just above the initial RSP.
         * Leave room for it inside the allocation. */
        g_hv->host_stack_top = stack ? ((stack + HV_HOST_STACK_SIZE - 0x20) & ~0xFull) : 0;
    }
    trace_step("05a6 arena vmxon", vmxon);
    if (!vmxon || !vmcs || !msrbitmap || vmxon < arena || !g_hv->host_stack_top)
        return -6;

    basic = rdmsr(0x480);
    g_hv->vmx_revision = (u32)(basic & 0x7FFFFFFF);
    *(u32*)vmxon = g_hv->vmx_revision;
    *(u32*)vmcs = g_hv->vmx_revision;
    g_hv->vmxon_page = vmxon;
    g_hv->vmcs_page = vmcs;
    g_hv->msr_bitmap = msrbitmap;

    /* Private host GDT/TSS/IDT: on every VM exit hardware loads the host
     * segment descriptors from the GDT, and the firmware's tables live in
     * boot-services memory that the OS reclaims at ExitBootServices. */
    if (!build_host_priv())
        return -6;
    trace_step("05a7 host priv", g_hv->host_gdt);

    /* SIMD save area for the exit stub.  XSAVE is used only when the whole
     * state fits in HV_XSAVE_SIZE; otherwise the stub falls back to XMM. */
    {
        u64 xa = arena_alloc(HV_XSAVE_SIZE);

        if (!xa)
            return -6;
        g_hv->xsave_area = xa;
        g_xsave_area = xa;
        g_use_xsave = 0;

        __cpuid(r, 1);
        if ((u32)r[2] & (1u << 26)) {           /* CPUID.1:ECX.XSAVE */
            __cpuid(r, 0);
            if (r[0] >= 0x0D) {
                __cpuidex(r, 0x0D, 0);
                if ((u32)r[2] && (u32)r[2] <= HV_XSAVE_SIZE)
                    g_use_xsave = 1;
            }
        }

        if (g_use_xsave) {
            /* The exit stub must be able to XSAVE from the very first exit,
             * including before Windows has touched CR4, so enable OSXSAVE here
             * and make sure XCR0 covers x87 and SSE. */
            u64 cr4 = __readcr4();
            if (!(cr4 & 0x40000ull)) {
                cr4 |= 0x40000ull;              /* CR4.OSXSAVE */
                __writecr4(cr4);
            }
            if ((hv_xgetbv() & 3ull) != 3ull)
                hv_xsetbv(0, hv_xgetbv() | 3ull);
        }
        trace_step("05a8 xsave", g_use_xsave);
    }

    /* Probe mode is the same full launch, but the caller resets the machine
     * right after the self-test instead of booting Windows under it. */
    if (g_probe_mode)
        hv_trace("05a9 probe: full launch test");

    {
        u64 cr4 = __readcr4();
        if (!(cr4 & 0x2000)) {
            cr4 |= 0x2000;
            __writecr4(cr4);
        }
    }

    /* VMXON requires CR0.PE, CR0.NE and CR4.VMXE.  This firmware leaves CR0.NE
     * clear (it reports CR0 = 0x80010013), so set it before going anywhere near
     * the instruction - without it VMXON cannot succeed. */
    {
        u64 cr0 = __readcr0();
        if (!(cr0 & (1ull << 5))) {
            cr0 |= (1ull << 5);
            __writecr0(cr0);
        }
    }

    trace_step("05b0 vmxon region", vmxon);
    trace_step("05b0a vmx revision", g_hv->vmx_revision);

    /* ------------------------------------------------ pre-VMX fault catcher
     * Nothing of ours is loaded as the IDT at this point: build_host_priv()
     * only fills in the VMCS *host state*, which takes effect after a VM exit.
     * So a fault raised by VMXON vectors through the FIRMWARE's IDT, whose
     * handler cannot recover, re-faults and triple-faults - a dead machine
     * with no trace line, which is exactly the symptom every earlier boot on
     * this box showed.  Install a catcher for this window and prove it works
     * before trusting VMXON to it. */
    {
        u16 sels[8];
        DescPtr idtr;
        u64 cidt = arena_alloc(HV_PAGE);
        u8  cdesc[16];
        u64 resume = (u64)&hv_try_vmxon_resume;
        int rc;

        if (!cidt)
            return -6;

        /* Copy the FIRMWARE's IDT, then patch every EXCEPTION vector (0-31)
         * with our catcher and leave vectors 32+ alone.
         *
         * Two hard-won lessons are baked into that split.  Pointing *all* 256
         * vectors at the catcher killed the machine: an interrupt frame has no
         * error code, so the first timer tick misread the frame in the #GP stub
         * and triple-faulted.  And patching only #UD/#GP left a hole - the
         * deliberate #UD below is caught, but VMXON then stops the CPU with no
         * caught vector at all, which means we cannot currently tell a machine
         * check from a page fault from a genuine hang.  Exceptions only. */
        hv_read_idtr(&idtr);
        if (!idtr.base || idtr.limit < 0xFFF)
            return -6;
        mm_memcpy(g_fw_idtr, &idtr, 10);   /* keep the real IDTR to restore */
        {
            DescPtr gdtr;
            hv_read_gdtr(&gdtr);
            mm_memcpy(g_fw_gdtr, &gdtr, 10);   /* keep the real GDTR to restore */
        }
        mm_memcpy((void*)cidt, (const void*)idtr.base, 0x1000);

        /* Our gates must name a selector valid in the GDT actually loaded
         * (ours is never LGDT'd, only written into the VMCS) - reuse live CS. */
        hv_read_segments(sels);
        {
            /* vectors that push an error code; the stub must read RIP at
             * [rsp+8] for these and [rsp] for the rest */
            const u32 errmask = (1u << 8) | (1u << 10) | (1u << 11) | (1u << 12) |
                                (1u << 13) | (1u << 14) | (1u << 17) | (1u << 21) |
                                (1u << 29) | (1u << 30);
            u32 v;
            for (v = 0; v < 32; ++v) {
                if (v == 2)
                    continue;               /* leave NMI to the firmware */
                idt_gate((IdtGate*)cidt, v,
                         (errmask & (1u << v)) ? (u64)&hv_fault_gp : (u64)&hv_fault_ud,
                         sels[0]);
            }
        }

        mm_memset(cdesc, 0, sizeof(cdesc));
        *(u16*)cdesc = 0xFFF;                     /* limit */
        *(u64*)(cdesc + 2) = cidt;                /* base  */
        hv_load_idt(cdesc);
        trace_step("05b0b catcher idt", cidt);

        g_fault_code = 0;
        g_fault_rip = 0;
        rc = hv_try_ud2(resume);
        trace_step("05b0c ud2 probe rc", (u64)rc);
        trace_step("05b0d ud2 vector", g_fault_code);

        /* Everything below has to be logged BEFORE VMXON, because if VMXON
         * stops the processor there is no chance to write anything afterwards.
         * These are the inputs that decide whether a machine check is plausible:
         * the processor's control registers, and the memory attributes actually
         * in force over the region (VMXON requires write-back). */
        trace_step("05b0k cr0", __readcr0());
        trace_step("05b0l cr4", __readcr4());
        trace_step("05b0m efer", rdmsr(0xC0000080));
        trace_step("05b0n mtrr cap", rdmsr(0xFE));
        trace_step("05b0o mtrr def", rdmsr(0x2FF));
        trace_step("05b0p fn hv_init", (u64)&hv_init);
        {
            /* Only IA32_MTRRCAP.VCNT variable MTRRs exist.  Reading past the
             * last one raises #GP, and the catcher's resume stub then executes
             * a RET against a stack frame it does not own and unwinds into
             * garbage - which is exactly how this diagnostic managed to hang
             * the machine before VMXON was ever reached.  Bound the scan. */
            u32 vcnt = (u32)(rdmsr(0xFE) & 0xFF);
            u32 k;
            u64 hit = 0;
            if (vcnt > 16)
                vcnt = 16;
            trace_step("05b0n2 mtrr vcnt", vcnt);
            for (k = 0; k < vcnt; ++k) {
                u64 base = rdmsr(0x200 + k * 2);
                u64 mask = rdmsr(0x201 + k * 2);
                u64 phys;
                if (!(mask & (1ull << 11)))
                    continue;                       /* MTRR not valid */
                phys = mask & 0x000FFFFFFFFFF000ull;
                if ((vmxon & phys) == (base & phys)) {
                    trace_step("05b0q vmxon mtrr idx", k);
                    trace_step("05b0r vmxon mtrr type", base & 0xFF);
                    hit = 1;
                }
            }
            trace_step("05b0s vmxon mtrr hit", hit);
        }

        /* Try a region from a different pool first.  Boot-services data is
         * ordinary write-back RAM at a different physical address, so if the
         * arena's runtime pages are the problem this behaves differently -- and
         * because a hang here is unrecoverable, everything above is already on
         * disk before we find out. */
        {
            EFI_PHYSICAL_ADDRESS alt = 0;
            EFI_STATUS as = g_bs->AllocatePages(AllocateAnyPages, EfiBootServicesData,
                                                1, &alt);
            trace_step("05b0t alt alloc status", (u64)as);
            trace_step("05b0u alt region", (u64)alt);
            if (!EFI_ERROR(as) && alt) {
                *(u32*)alt = g_hv->vmx_revision;
                g_fault_code = 0;
                g_fault_rip = 0;
                rc = hv_try_vmxon((u64)alt, resume);
                trace_step("05b0v alt try_vmxon rc", (u64)rc);
                trace_step("05b0w alt vector", g_fault_code);
                trace_step("05b0x alt fault rip", g_fault_rip);
                if (rc == 0) {
                    /* Leave VMX operation but KEEP CR4.VMXE SET.  VMXON with
                     * VMXE clear raises #UD, and the next statement after this
                     * block is another VMXON on the arena region.  Clearing
                     * VMXE here is exactly why the previous run reported
                     * alt rc=0 and then arena rc=3 / vector 6, while the
                     * CR4 re-assert below never ran because of the early
                     * return in between. */
                    hv_vmxoff();
                    hv_trace("05b0y alt region VMXON ok");
                }
            }
        }

        /* Re-assert CR4.VMXE immediately before this second probe.  Either
         * path above may have left VMX operation, and VMXON with VMXE clear is
         * #UD.  Whatever happens, the arena-region attempt must start from a
         * state where VMXON is legal. */
        {
            u64 cr4c = __readcr4();
            if (!(cr4c & 0x2000)) {
                cr4c |= 0x2000;
                __writecr4(cr4c);
            }
        }

        g_fault_code = 0;
        g_fault_rip = 0;
        rc = hv_try_vmxon(vmxon, resume);
        trace_step("05b0f try_vmxon rc", (u64)rc);
        trace_step("05b0g vmxon vector", g_fault_code);
        trace_step("05b0h vmxon rip", g_fault_rip);

        if (rc != 0) {
            /* Refused or faulted, and now we know which.  Do NOT fall through
             * to the launch path: it would issue the same VMXON and take the
             * machine down the same way.  Bail out and let Windows boot with
             * the answer in the trace. */
            trace_step("05b0i vmxon abandoned", (u64)rc);
            return -7;
        }

        /* VMXON works.  Leave VMX so the launch path below runs exactly as it
         * always has, and keep the catcher armed in case it faults. */
        hv_vmxoff();
        {
            u64 cr4 = __readcr4();
            __writecr4(cr4 & ~0x2000ull);
        }
        hv_trace("05b0j catcher: vmxon works, re-running for real");
    }

    /* Re-assert CR4.VMXE before the real attempt.
     *
     * Both probe paths above leave VMX operation, and the successful one also
     * clears CR4.VMXE.  VMXON executed with VMXE clear raises #UD - which is
     * exactly how this failed on the run where the probe finally reported
     * success (try_vmxon rc=3, vector 6).  The probe proved VMXON works on this
     * hardware; this line is what lets the real one run. */
    {
        u64 cr4 = __readcr4();
        if (!(cr4 & 0x2000)) {
            cr4 |= 0x2000;
            __writecr4(cr4);
        }
    }

    hv_trace("05b1 calling vmxon");
    g_fault_resume = (u64)&hv_try_vmxon_resume;   /* stay catchable */
    if (hv_vmxon(vmxon))  return -7;
    hv_trace("05a vmxon ok");

    /* VMXON succeeded - the catcher has done its job and must be unloaded NOW.
     *
     * If it stays loaded, the rest of hv_init and the launch run with a stale
     * IDT whose every exception vector redirects through g_fault_resume (still
     * the probe's resume stub) and IRETs into `mov eax,3; ret`, unwinding a
     * stack frame it does not own.  That is a hang at a nondeterministic point
     * - precisely the moving freeze we observed.  Restoring the firmware IDT
     * also makes hv_prepare_guest read the real firmware IDTR into GUEST_IDTR
     * instead of the catcher's. */
    hv_load_idt(g_fw_idtr);
    hv_trace("05a1 idt restored");

    if (hv_vmclear(vmcs)) return -8;
    if (hv_vmptrld(vmcs)) return -9;
    if (!vmcs_configure()) return -10;
    hv_trace("05b vmcs ok");

    /* From here the CPU becomes a guest. hv_enter only returns 0 when VMLAUNCH
     * succeeded and the trampoline resumed us inside the VM. */
    if (g_bs && g_bs->SetWatchdogTimer)
        g_bs->SetWatchdogTimer(30, 0, 0, 0);   /* firmware resets us if we hang */

    /* Shared report page.  The guest writes its magic here as its very first
     * instruction, so this page is the only place that can prove VM entry
     * happened: the trace file cannot be written from inside the guest, and by
     * the time the host regains control the launch's fate is already decided. */
    {
        u64 rp = arena_alloc(HV_PAGE);
        if (!rp)
            return -6;
        g_report = (HvReport*)rp;
        /* Sentinel, not zero.  arena_alloc hands back a zeroed page, so filling
         * the magic slot with this makes "the guest wrote it" provable rather
         * than inferred - a zero could equally be a page nothing ever touched. */
        g_report->magic = 0xDEADBEEFDEADBEEFull;
        g_report_ptr = rp;
        trace_step("05b9 report page", rp);
    }

    hv_trace("05c prelaunch");
    if (g_stage_a) {
        /* Probe launch.
         *
         * hv_enter runs the minimal VMCS, the guest writes its magic and
         * VMCALLs, the one-shot exit stub records the exit and tears VMX down,
         * and control comes back here in the HOST.  The guest self-test must
         * not run - we are not in a VM any more - so this returns immediately
         * after publishing the report.
         *
         * Nothing resumes the guest, so this path cannot hang. */
        (void)hv_enter();

        /* marker: did the exit stub's RET actually land back here? */
        hv_outb(0x70, 0x4F);
        hv_outb(0x71, 0x60);

        if (g_report) {
            say_hex("probe magic",  g_report->magic);
            say_hex("probe ran",    g_report->guest_ran);
            say_hex("probe exited", g_report->exited);
            say_hex("probe reason", g_report->exit_reason);
            say_hex("probe rip",    g_report->exit_rip);
        }
        hv_publish_report("05da probe report");
        hv_say("HvFn: probe launch returned - VMX is off, booting on");
        return -21;
    }

    if (hv_enter() == 0) {
        int ok;

        /* The VMCALL self-test runs FIRST, before any other firmware call.
         *
         * It forces exactly one VM exit, and the exit handler logs from root
         * mode where boot services are still alive - so it separates three
         * things a hang here would otherwise conflate:
         *   no "05d1 first vm exit"  -> VM entry or the exit stub itself fails
         *   "05d1" but no "05e"      -> the handler ran, the resume path fails
         *   "05e selftest returned"  -> entry, exit, handler and resume all work
         * A firmware file write placed before this could itself trigger a CPUID
         * exit and blur that picture, so nothing does. */
        ok = hv_selftest();
        hv_trace("05e selftest returned");

        if (ok) {
            hv_trace("05d guest resumed, exits round-tripped");
            if (g_bs && g_bs->SetWatchdogTimer)
                g_bs->SetWatchdogTimer(0, 0, 0, 0);
            return 0;
        }

        /* Exits did not round-trip.  VMXOFF is a VMX instruction and cannot be
         * executed from inside the guest (it would #UD), so there is no clean
         * way to leave VMX here.  Keep the firmware watchdog armed: if the
         * machine really is broken it resets in 60 s and the failed-boot guard
         * counts the attempt; if Windows still boots, nothing is lost. */
        /* These four counters separate the ways the self-test can fail: exits
         * that never happened at all (exits=0 means the intercepts are not
         * firing), exits that happened but were not recognised (bad_ud rising
         * means the doorbell matched but the request was rejected), and exits
         * that faulted in root mode (fault_recoveries). */
        trace_step("07b exits", g_hv->exits_total);
        trace_step("07c hypercalls", g_hv->hypercalls_total);
        trace_step("07d bad_ud", g_hv->bad_ud);
        trace_step("07e fault_recov", g_hv->fault_recoveries);
        return -12;
    }

    if (g_bs && g_bs->SetWatchdogTimer)
        g_bs->SetWatchdogTimer(0, 0, 0, 0);

    if (g_dry_done)
        return -20;                     /* diagnostic: never launched */

    /* VMLAUNCH was rejected, so we are still in VMX root, not in a guest.
     * VMXOFF is legal here and is the only clean way to hand the machine back
     * to firmware. */
    g_launch_error = (u32)(hv_vmread(VMCS_VMEXIT_INSTRUCTION_ERROR) & 0xFFFF);
    /* VMLAUNCH accepting its state is the single unproven step in this design.
     * A bare "rc=-11" in the trace says nothing about why it failed; the
     * VM-instruction error number does: 4 = non-clear VMCS, 5 = non-launched
     * VMCS, 7 = invalid control field, 8 = invalid host-state field. */
    trace_step("06b vmlaunch err", g_launch_error);
    hv_vmxoff();
    {
        u64 cr4 = __readcr4();
        __writecr4(cr4 & ~0x2000ull);
    }
    return -11;
}

u64 hv_get_context_addr(void) { return (u64)g_hv; }

/* ----------------------------------------------------------- hypercalls */

static u8 g_bounce[HV_MAX_XFER_BYTES];

static void dispatch(HvRequest* req, u64 caller_cr3)
{
    u64 len;

    switch (req->op) {
    case HV_OP_PING:
        req->out[0] = HVFN_MAGIC;
        req->out[1] = HVFN_BUILD_ID;
        req->out[2] = g_hv->vmx_revision;
        req->out[3] = g_hv->ept_1g;
        req->status = HV_OK;
        break;

    case HV_OP_READ:
        len = req->arg[3];
        if (!len || len > HV_MAX_XFER_BYTES) { req->status = HV_ERR_TOO_BIG; break; }
        if (!mm_read(req->arg[0], req->arg[1], g_bounce, len)) {
            req->status = HV_ERR_NOT_MAPPED; break;
        }
        if (!mm_write(caller_cr3, req->arg[2], g_bounce, len)) {
            req->status = HV_ERR_NOT_MAPPED; break;
        }
        req->size = (u32)len;
        req->status = HV_OK;
        break;

    case HV_OP_WRITE:
        len = req->arg[3];
        if (!len || len > HV_MAX_XFER_BYTES) { req->status = HV_ERR_TOO_BIG; break; }
        if (!mm_read(caller_cr3, req->arg[2], g_bounce, len)) {
            req->status = HV_ERR_NOT_MAPPED; break;
        }
        if (!mm_write(req->arg[0], req->arg[1], g_bounce, len)) {
            req->status = HV_ERR_NOT_MAPPED; break;
        }
        req->size = (u32)len;
        req->status = HV_OK;
        break;

    case HV_OP_TRANSLATE:
        req->out[0] = mm_translate(req->arg[0], req->arg[1]);
        req->status = req->out[0] ? HV_OK : HV_ERR_NOT_MAPPED;
        break;

    case HV_OP_RESOLVE:
        /* caller_cr3 is the fallback when no kernel-mode sample was captured:
         * on systems without KVA shadowing it still maps the kernel. */
        req->status = hv_resolve_target((u32)req->arg[0], caller_cr3);
        if (req->status == HV_OK) {
            req->out[0] = g_hv->target_cr3;
            req->out[1] = g_hv->target_base;
            req->out[2] = g_hv->target_peb;
            req->out[3] = g_hv->target_pid;
        }
        break;

    case HV_OP_STATS:
        req->out[0] = g_hv->exits_total;
        req->out[1] = g_hv->hypercalls_total;
        req->out[2] = g_hv->kernel_samples;
        req->out[3] = g_hv->target_state;
        req->out[4] = g_hv->resolve_attempts;
        req->out[5] = g_hv->resolve_last_error;
        req->status = HV_OK;
        break;

    case HV_OP_FLUSH_TARGET:
        g_hv->target_state = HV_TARGET_NONE;
        g_hv->target_cr3 = 0;
        g_hv->target_base = 0;
        g_hv->target_peb = 0;
        req->status = HV_OK;
        break;

    default:
        req->status = HV_ERR_ARGS;
        break;
    }
}

/* 1 = consumed (no #UD re-injected), 0 = not ours */
static int handle_hypercall(void)
{
    u64 rip = hv_vmread(VMCS_GUEST_RIP);
    u64 cr3 = hv_vmread(VMCS_GUEST_CR3);
    u8 insn[3];
    HvRequest req;
    int consumed = 0;

    /* If anything in here faults in root mode, hv_fault_recover steps over the
     * VMCALL so the caller sees a failed request instead of a hung machine. */
    g_hv->pending_advance = 3;

    if (!mm_read(cr3, rip, insn, 3))
        goto out;
    if (insn[0] != 0x0F || insn[1] != 0x01 || insn[2] != 0xC1)   /* VMCALL */
        goto out;
    if (g_guest_regs.rax != HVFN_MAGIC)
        goto out;
    if (!mm_read(cr3, g_guest_regs.rcx, &req, sizeof(req)))
        goto out;
    if (req.op == 0 || req.op > 64)
        goto out;

    req.status = HV_OK;
    req.size = 0;
    mm_memset(req.out, 0, sizeof(req.out));

    dispatch(&req, cr3);
    mm_write(cr3, g_guest_regs.rcx, &req, sizeof(req));

    hv_vmwrite(VMCS_GUEST_RIP, rip + 3);
    g_hv->hypercalls_total++;
    consumed = 1;
out:
    g_hv->pending_advance = 0;
    return consumed;
}

static void handle_cpuid(void)
{
    int r[4];
    u64 rip = hv_vmread(VMCS_GUEST_RIP);
    u32 leaf = (u32)g_guest_regs.rax;
    u32 sub = (u32)g_guest_regs.rcx;

    __cpuidex(r, (int)leaf, (int)sub);
    if (leaf == 1) {
        r[2] &= ~(1 << 31);            /* hide "hypervisor present" */
        if (!g_use_xsave) {
            /* No XSAVE area big enough: hide the whole SIMD extension set so
             * the guest cannot create state the exit stub would destroy. */
            r[2] &= ~((1 << 26) | (1 << 27) | (1 << 28));  /* XSAVE/OSXSAVE/AVX */
        }
    }
    if (leaf == 7 && sub == 0) {
        if (!g_hv->have_invpcid)
            r[1] &= ~(1 << 10);        /* INVPCID */
        if (!g_use_xsave)
            r[1] &= ~((1 << 5) | (1 << 16) | (1 << 30));   /* AVX2/AVX512F/AVX512BW */
    }
    if (leaf == 0x0D && sub == 1 && !g_hv->have_xsaves)
        r[0] &= ~(1 << 3);             /* XSAVES/XRSTORS gated by VMCS control 20 */
    if (leaf == 0x80000001u && !g_hv->have_rdtscp)
        r[3] &= ~(1 << 27);            /* RDTSCP */

    g_guest_regs.rax = (u32)r[0];
    g_guest_regs.rbx = (u32)r[1];
    g_guest_regs.rcx = (u32)r[2];
    g_guest_regs.rdx = (u32)r[3];
    hv_vmwrite(VMCS_GUEST_RIP, rip + 2);
}

static void inject_exception(u32 vector)
{
    u64 info = 0x80000000ull | ((u64)3 << 8) | vector;
    hv_vmwrite(VMCS_CTRL_VMENTRY_INTERRUPTION_INFO, info);
}

/* VMCALL executed in ring 0 (firmware / our self-test) exits with basic exit
 * reason 18.
 *
 * Instruction-caused exits are fault-like: the guest RIP in the VMCS still
 * points AT the instruction, and hardware supplies the instruction length in
 * the VM-exit instruction length field.  Advancing by that field is the
 * canonical idiom.  The previous code instead sniffed the three bytes behind
 * RIP for the VMCALL opcode to guess whether hardware had advanced - which is
 * not merely redundant but a hang: if those three bytes happen to be 0F 01 C1
 * the sniff concludes RIP already moved, leaves it alone, and the guest
 * re-executes the same VMCALL in an unbreakable exit loop. */
static void handle_ring0_call(void)
{
    u64 rip = hv_vmread(VMCS_GUEST_RIP);
    u64 cr3 = hv_vmread(VMCS_GUEST_CR3);
    u64 len = hv_vmread(VMCS_VMEXIT_INSTRUCTION_LENGTH);
    HvRequest req;

    /* VMCALL is 0F 01 C1 (3 bytes); fall back to that if the field is not
     * populated for this exit reason.  A valid x86 instruction is 1..15. */
    if (len < 1 || len > 15)
        len = 3;

    if (g_guest_regs.rax == HVFN_MAGIC &&
        mm_read(cr3, g_guest_regs.rcx, &req, sizeof(req)) &&
        req.op > 0 && req.op <= 64) {
        req.status = HV_OK;
        req.size = 0;
        mm_memset(req.out, 0, sizeof(req.out));
        g_hv->pending_advance = len;
        dispatch(&req, cr3);
        mm_write(cr3, g_guest_regs.rcx, &req, sizeof(req));
        g_hv->pending_advance = 0;
        g_hv->hypercalls_total++;
    }

    hv_vmwrite(VMCS_GUEST_RIP, rip + len);
}

/* Give the event that caused this exit back to the guest unchanged.  Used for
 * NMI (pin-based exiting is on) and for anything else the exception bitmap
 * intercepts that is not the hypercall doorbell. */
static void reinject_exit_event(u64 info)
{
    u32 type = (u32)((info >> 8) & 7);
    u32 vec  = (u32)(info & 0xFF);

    if (!(info & 0x80000000ull))
        return;

    /* VM entry with an NMI injection fails while the guest is blocking NMIs
     * (it is inside an NMI handler).  Dropping that one NMI is the only safe
     * option; a failed VM entry would park the CPU. */
    if (type == 2 && (hv_vmread(VMCS_GUEST_INTERRUPTIBILITY_STATE) & 8ull)) {
        g_hv->irq_reinjects++;
        return;
    }

    hv_vmwrite(VMCS_CTRL_VMENTRY_INTERRUPTION_INFO, info);
    if (type == 3 && (vec == 8 || vec == 10 || vec == 11 || vec == 12 ||
                      vec == 13 || vec == 14 || vec == 17 || vec == 21 ||
                      vec == 29 || vec == 30)) {
        hv_vmwrite(VMCS_CTRL_VMENTRY_EXCEPTION_ERROR_CODE,
                   hv_vmread(VMCS_VMEXIT_INTERRUPTION_ERROR_CODE));
    }
    if (type == 2)
        g_hv->irq_reinjects++;
}

/* Reasons 31/32 only happen if the MSR bitmap ever fails to load.  Emulate the
 * access instead of letting the same instruction exit forever.  pending_advance
 * makes a faulting MSR access skip the instruction rather than hang. */
static void handle_msr(void)
{
    u32 msr = (u32)g_guest_regs.rcx;
    u64 rip = hv_vmread(VMCS_GUEST_RIP);
    int is_write = ((hv_vmread(VMCS_VMEXIT_REASON) & 0xFFFF) == 32);

    g_hv->pending_advance = 2;
    if (is_write) {
        wrmsr(msr, (g_guest_regs.rdx << 32) | (u32)g_guest_regs.rax);
    } else {
        u64 v = rdmsr(msr);
        g_guest_regs.rax = (u32)v;
        g_guest_regs.rdx = (u32)(v >> 32);
    }
    g_hv->pending_advance = 0;
    hv_vmwrite(VMCS_GUEST_RIP, rip + 2);
}

/* EPT violation: extend the identity map to cover the page and retry.  The
 * initial map stops at HV_EPT_COVER; a device BAR above it lands here.  If the
 * page cannot be mapped, deny the access with #GP instead of re-executing the
 * faulting instruction forever. */
static void handle_ept_violation(void)
{
    u64 gpa = hv_vmread(VMCS_VMEXIT_GUEST_PHYSICAL_ADDRESS);

    g_hv->ept_violations++;
    g_hv->last_violation_gpa = gpa;

    if (g_hv->violation_retries < 64 && ept_map_region(gpa & ~0xFFFull)) {
        g_hv->violation_retries++;
        return;                          /* retry the faulting instruction */
    }

    hv_vmwrite(VMCS_CTRL_VMENTRY_INTERRUPTION_INFO,
               0x80000000ull | ((u64)3 << 8) | 13);
    hv_vmwrite(VMCS_CTRL_VMENTRY_EXCEPTION_ERROR_CODE, 0);
}

/* CR access (exit reason 28): the guest moved to/from CR0/CR3/CR4 (or CLTS/
 * LMSW).  With the CR0/CR4 masks set to the fixed bits, these exits fire when
 * the guest touches a control bit we must shadow.  Update the VMCS field and
 * the read shadow so the guest's change is not reverted on the next entry. */
static void handle_cr(void)
{
    u64 qual = hv_vmread(VMCS_VMEXIT_QUALIFICATION);
    u32 cr   = (u32)(qual & 0xF);
    u32 type = (u32)((qual >> 4) & 3);
    u32 reg  = (u32)((qual >> 8) & 0xF);
    u64 rip  = hv_vmread(VMCS_GUEST_RIP);
    u32 len  = (u32)hv_vmread(VMCS_VMEXIT_INSTRUCTION_LENGTH);
    u64* gregs = (u64*)&g_guest_regs;
    u64 val;

    if (!len || len > 15)
        len = 3;

    switch (type) {
    case 0: /* MOV to CR */
        val = gregs[reg];
        if (cr == 0) {
            hv_vmwrite(VMCS_GUEST_CR0, val);
            hv_vmwrite(VMCS_CTRL_CR0_READ_SHADOW, val);
        } else if (cr == 4) {
            hv_vmwrite(VMCS_GUEST_CR4, val);
            hv_vmwrite(VMCS_CTRL_CR4_READ_SHADOW, val);
        } else if (cr == 3) {
            hv_vmwrite(VMCS_GUEST_CR3, val);
        }
        break;
    case 1: /* MOV from CR */
        val = 0;
        if (cr == 0)       val = hv_vmread(VMCS_CTRL_CR0_READ_SHADOW);
        else if (cr == 4)  val = hv_vmread(VMCS_CTRL_CR4_READ_SHADOW);
        else if (cr == 3)  val = hv_vmread(VMCS_GUEST_CR3);
        gregs[reg] = val;
        break;
    case 2: /* CLTS */
        val = hv_vmread(VMCS_GUEST_CR0) & ~(1ull << 3);
        hv_vmwrite(VMCS_GUEST_CR0, val);
        hv_vmwrite(VMCS_CTRL_CR0_READ_SHADOW, val);
        break;
    case 3: /* LMSW */
        val = gregs[reg] & 0xF;
        {
            u64 cr0 = (hv_vmread(VMCS_GUEST_CR0) & ~0xF) | val;
            hv_vmwrite(VMCS_GUEST_CR0, cr0);
            hv_vmwrite(VMCS_CTRL_CR0_READ_SHADOW, cr0);
        }
        break;
    default:
        break;
    }
    hv_vmwrite(VMCS_GUEST_RIP, rip + len);
}

/* XSETBV (exit reason 55): the guest writes an XCR.  XCR0 is shared between
 * root and non-root, so apply the guest's value for real and step over the
 * instruction.  bootmgfw/winload use this for XSAVE; without it they wedge. */
static void handle_xsetbv(void)
{
    u32 xcr = (u32)g_guest_regs.rcx;
    u64 val = ((u64)(u32)g_guest_regs.rdx << 32) | (u32)g_guest_regs.rax;
    u64 rip = hv_vmread(VMCS_GUEST_RIP);
    u32 len = (u32)hv_vmread(VMCS_VMEXIT_INSTRUCTION_LENGTH);

    if (!len || len > 15)
        len = 3;

    if (xcr == 0)
        hv_xsetbv(0, val);

    hv_vmwrite(VMCS_GUEST_RIP, rip + len);
}

/* INVLPG exiting is only a sampling aid: it gives us a ring-0 exit during
 * Windows boot so the resolver learns a kernel CR3 (needed when KVA shadowing
 * makes kernel globals unmapped in user CR3s).  Once a sample validates, drop
 * the intercept so the guest's TLB flushes stop costing a VM exit. */
static void stop_invlpg_exits(void)
{
    u64 proc = hv_vmread(VMCS_CTRL_PROCESSOR_BASED_VM_EXECUTION_CONTROLS);

    if (proc & (1ull << 9)) {
        proc &= ~(1ull << 9);
        hv_vmwrite(VMCS_CTRL_PROCESSOR_BASED_VM_EXECUTION_CONTROLS, proc);
    }
}

static u32 g_sample_attempts;

void hv_handle_exit(void)
{
    u32 reason;
    u64 guest_cr3;

    g_hv->exits_total++;

    /* A stale interruption field would be re-injected on the next entry. */
    hv_vmwrite(VMCS_CTRL_VMENTRY_INTERRUPTION_INFO, 0);

    reason = (u32)(hv_vmread(VMCS_VMEXIT_REASON) & 0xFFFF);
    guest_cr3 = hv_vmread(VMCS_GUEST_CR3);

    /* Diagnostic: record the exit reason in CMOS so the NEXT boot reports the
     * last exit before a hang.  Root-mode trace writes to the ESP fail silently
     * (SimpleFileSystem needs the firmware context), but port I/O does not.
     * Reading back 0x4F after a wedge therefore names the stuck exit. */
    hv_outb(0x70, 0x4F);
    hv_outb(0x71, (u8)reason);

    /* Infinite-exit-loop detector: same reason + unchanged GUEST_RIP = a
     * handler failed to advance the guest.  Halt with the reason in CMOS so it
     * is visible next boot, instead of spinning forever. */
    if (reason == g_hv->last_reason && hv_vmread(VMCS_GUEST_RIP) == g_hv->last_rip) {
        g_hv->loop_reason = reason;
        g_hv->loop_rip = hv_vmread(VMCS_GUEST_RIP);
        hv_outb(0x70, 0x4F);
        hv_outb(0x71, (u8)(0x80 | (reason & 0x7F)));   /* high bit = loop; low 7 = reason */
        for (;;)
            __halt();
    }
    g_hv->last_reason = reason;
    g_hv->last_rip = hv_vmread(VMCS_GUEST_RIP);

    /* The very first VM exit this hypervisor ever takes.  Reaching this line
     * proves three separate things at once: VM entry was accepted, the exit
     * stub ran to completion on the host stack, and control reached C with
     * usable page tables and an IDT.  Logged from root mode while boot services
     * are still alive, so it is the earliest evidence a launch can produce. */
    if (g_hv->exits_total == 1)
        trace_step("05d1 first vm exit, reason", (u64)reason);

    if (reason != 48)
        g_hv->violation_retries = 0;

    /* INVLPG exits before executing; if anything below faults, resume past it
     * instead of re-entering the same exit forever.  INVLPG is basic exit
     * reason 14, NOT 28 (28 is CR_ACCESS).  The distinction is fatal: an INVLPG
     * exit does not execute the instruction, so if reason 14 reaches the
     * default case the guest re-executes the same INVLPG and the CPU spins in
     * this exit forever - the first TLB flush after VMLAUNCH hangs the boot. */
    if (reason == 14) {
        u32 len = (u32)hv_vmread(VMCS_VMEXIT_INSTRUCTION_LENGTH);
        g_hv->pending_advance = len ? len : 3;
    }

    /* Keep the host context in sync with the guest.  The control registers are
     * copied through host_cr0()/host_cr4(), which keep the features root mode
     * must not inherit (5-level paging, CET shadow stacks, CR0.TS/EM) off. */
    hv_vmwrite(VMCS_HOST_CR0, host_cr0(hv_vmread(VMCS_GUEST_CR0)));
    hv_vmwrite(VMCS_HOST_CR4, host_cr4(hv_vmread(VMCS_GUEST_CR4)));
    hv_vmwrite(VMCS_HOST_EFER, hv_vmread(VMCS_GUEST_EFER));

    /* Remember one kernel-mode context: KPCR -> CurrentThread -> Process.  The
     * exit was CPL0, so guest_cr3 is a kernel CR3 regardless of what
     * DirectoryTableBase says (KVA shadowing stores the user CR3 there). */
    if (!g_hv->kern_cr3 && (hv_vmread(VMCS_GUEST_CS_SELECTOR) & 3) == 0) {
        u64 gs = hv_vmread(VMCS_GUEST_GS_BASE);
        if (gs && hv_capture_kernel_sample(guest_cr3, gs)) {
            stop_invlpg_exits();
        } else if (++g_sample_attempts >= 64) {
            /* The offsets did not fit this build; stop taxing every TLB flush
             * and let the resolver try the hypercall caller's CR3 instead. */
            stop_invlpg_exits();
        }
    }

    switch (reason) {
    case 0: {
        u64 info = hv_vmread(VMCS_VMEXIT_INTERRUPTION_INFO);
        u32 vec = (u32)(info & 0xFF);
        u32 type = (u32)((info >> 8) & 7);
        if (type == 3 && vec == 6) {
            if (handle_hypercall())
                return;
            g_hv->bad_ud++;
            inject_exception(6);
        } else {
            /* NMI and any other intercepted event: give it back to the guest
             * exactly as hardware delivered it. */
            reinject_exit_event(info);
        }
        break;
    }
    case 10:
        handle_cpuid();
        break;
    case 18:
        handle_ring0_call();
        break;
    case 14:                            /* INVLPG (28 is CR_ACCESS) */
        hv_vmwrite(VMCS_GUEST_RIP,
                   hv_vmread(VMCS_GUEST_RIP) + g_hv->pending_advance);
        g_hv->pending_advance = 0;
        break;
    case 31:
    case 32:
        handle_msr();
        break;
    case 28:
        handle_cr();
        break;
    case 55:
        handle_xsetbv();
        break;
    case 48:
        handle_ept_violation();
        break;
    default:
        break;
    }
}

/* --------------------------------------------------------- fault recovery */

/* Entered from hv_fatal_entry after a fault in VMX root operation.  The VMCS
 * still describes the guest exactly as it was at exit time, so the only thing
 * to fix is the instruction pointer when the fault happened inside a handler
 * that was emulating a guest instruction. */
void hv_fault_recover(void)
{
    u64 adv = g_hv->pending_advance;
    u64 rip = hv_vmread(VMCS_GUEST_RIP);

    g_hv->fault_recoveries++;
    g_hv->last_fault_rip = g_fatal_frame1;
    g_hv->pending_advance = 0;
    hv_vmwrite(VMCS_CTRL_VMENTRY_INTERRUPTION_INFO, 0);

    if (adv) {
        hv_vmwrite(VMCS_GUEST_RIP, rip + adv);
    } else {
        /* No emulated instruction to step over: resume the guest where it
         * stopped.  If the same exit faults again it will be visible in the
         * counters instead of taking the machine down. */
        g_hv->panic_code = 1;
    }
}

void hv_panic(u32 code)
{
    g_hv->panic_code = code;
    for (;;)
        __halt();
}

/* ------------------------------------------------------------------- memory */

void* mm_memset(void* dst, int c, u64 n)
{
    u8* p = (u8*)dst;
    while (n--)
        *p++ = (u8)c;
    return dst;
}

void* mm_memcpy(void* dst, const void* src, u64 n)
{
    u8* d = (u8*)dst;
    const u8* s = (const u8*)src;
    while (n--)
        *d++ = *s++;
    return dst;
}

/* The optimiser emits calls to these for struct copies / zero fills.  The
 * pragmas stop MSVC from treating the definitions as redeclarations of the
 * built-in intrinsics. */
#pragma function(memset)
#pragma function(memcpy)
void* __cdecl memset(void* d, int c, unsigned __int64 n) { return mm_memset(d, c, n); }
void* __cdecl memcpy(void* d, const void* s, unsigned __int64 n) { return mm_memcpy(d, s, n); }
