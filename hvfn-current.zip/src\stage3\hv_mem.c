/* hv_mem.c - physical access and a four-level page-table walker.
 *
 * The host page tables built in hv_core.c identity-map the low 1 TiB, so for
 * RAM (and for the MMIO ranges inside that window) "physical address" is a
 * valid pointer in VMX root operation.  Guest virtual addresses are resolved by
 * walking the CR3 handed to us, which is what makes cross-process reads work
 * without ever switching CR3.
 */
#include "hv.h"

#define HV_MAX_WALK_BYTES 0x1000000ull

u8  phys_read8(u64 pa)  { return *(volatile u8*)pa; }
u16 phys_read16(u64 pa) { return *(volatile u16*)pa; }
u32 phys_read32(u64 pa) { return *(volatile u32*)pa; }
u64 phys_read64(u64 pa) { return *(volatile u64*)pa; }

static int pte_present(u64 e) { return (e & 1) != 0; }
static u64 pte_addr(u64 e)    { return e & 0x000FFFFFFFFFF000ull; }

/* Every physical address touched here is dereferenced directly, so it has to
 * be inside the identity-mapped host window.  A bogus CR3 or PTE outside it
 * would fault in root mode; this turns that into a clean "not mapped". */
static int host_covered(u64 pa, u64 len)
{
    return pa < HV_HOST_COVER && len <= HV_HOST_COVER - pa;
}

static u64 walk_read64(u64 pa)
{
    if (!host_covered(pa, 8))
        return 0;
    return phys_read64(pa);
}

u64 mm_translate(u64 cr3, u64 va)
{
    u64 e, table;

    if (!cr3)
        return 0;

    table = cr3 & 0x000FFFFFFFFFF000ull;
    if (!host_covered(table, HV_PAGE))
        return 0;

    e = walk_read64(table + ((va >> 39) & 0x1FF) * 8);
    if (!pte_present(e))
        return 0;
    if (e & 0x80)                     /* 1 GiB at PML4 level: not legal */
        return 0;
    table = pte_addr(e);
    if (!host_covered(table, HV_PAGE))
        return 0;

    e = walk_read64(table + ((va >> 30) & 0x1FF) * 8);
    if (!pte_present(e))
        return 0;
    if (e & 0x80) {                   /* 1 GiB page */
        u64 pa = pte_addr(e) | (va & 0x3FFFFFFFull);
        return host_covered(pa, 1) ? pa : 0;
    }
    table = pte_addr(e);
    if (!host_covered(table, HV_PAGE))
        return 0;

    e = walk_read64(table + ((va >> 21) & 0x1FF) * 8);
    if (!pte_present(e))
        return 0;
    if (e & 0x80) {                   /* 2 MiB page */
        u64 pa = pte_addr(e) | (va & 0x1FFFFFull);
        return host_covered(pa, 1) ? pa : 0;
    }
    table = pte_addr(e);
    if (!host_covered(table, HV_PAGE))
        return 0;

    e = walk_read64(table + ((va >> 12) & 0x1FF) * 8);
    if (!pte_present(e))
        return 0;
    {
        u64 pa = pte_addr(e) | (va & 0xFFFull);
        return host_covered(pa, 1) ? pa : 0;
    }
}

int mm_read(u64 cr3, u64 va, void* dst, u64 len)
{
    u8* out = (u8*)dst;

    if (!cr3 || !dst || !len || len > HV_MAX_WALK_BYTES)
        return 0;

    while (len) {
        u64 pa = mm_translate(cr3, va);
        u64 chunk = HV_PAGE - (va & 0xFFFull);
        if (!pa)
            return 0;
        if (chunk > len)
            chunk = len;
        if (!host_covered(pa, chunk))
            return 0;
        mm_memcpy(out, (const void*)pa, chunk);
        out += chunk;
        va += chunk;
        len -= chunk;
    }
    return 1;
}

int mm_write(u64 cr3, u64 va, const void* src, u64 len)
{
    const u8* in = (const u8*)src;

    if (!cr3 || !src || !len || len > HV_MAX_WALK_BYTES)
        return 0;

    while (len) {
        u64 pa = mm_translate(cr3, va);
        u64 chunk = HV_PAGE - (va & 0xFFFull);
        if (!pa)
            return 0;
        if (chunk > len)
            chunk = len;
        if (!host_covered(pa, chunk))
            return 0;
        mm_memcpy((void*)pa, in, chunk);
        in += chunk;
        va += chunk;
        len -= chunk;
    }
    return 1;
}
