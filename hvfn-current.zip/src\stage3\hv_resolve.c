/* hv_resolve.c - find the game process from inside VMX root.
 *
 * The hypervisor never runs in the game's context, so it cannot simply read
 * CR3 from the VMCS.  Instead it takes one kernel-mode VM exit on the BSP,
 * which yields:
 *
 *      GS base  ->  KPCR  ->  CurrentThread (0x188)  ->  KTHREAD.Process (0xB8)
 *                                                        ->  EPROCESS
 *
 * and records the CR3 that exit ran on: by definition a kernel CR3, so kernel
 * globals are mapped through it even when KVA shadowing is enabled.  ntoskrnl
 * is located by scanning down from an IDT handler for a PE image that exports
 * PsInitialSystemProcess.  That export is a data pointer to the System
 * EPROCESS, from which the ActiveProcessLinks offset is derived - not assumed.
 *
 * If no kernel exit was captured (INVLPG exiting unavailable or all samples
 * failed), the resolver falls back to the hypercall caller's CR3.  That works
 * on systems without KVA shadowing, where user page tables still map the
 * kernel.
 */
#include "hv.h"

#define EPROCESS_SCAN   0x1000u
#define IDT_SCAN_LIMIT  0x4000000ull        /* 64 MiB below the IDT handler */
#define MAX_PROCEDURES  8192

static u8 g_scratch[EPROCESS_SCAN];

static int canonical(u64 a)
{
    u64 hi = a >> 47;
    return hi == 0 || hi == 0x1FFFF;
}

static u32 r32(u64 cr3, u64 va)
{
    u32 v = 0;
    mm_read(cr3, va, &v, 4);
    return v;
}

static u16 r16(u64 cr3, u64 va)
{
    u16 v = 0;
    mm_read(cr3, va, &v, 2);
    return v;
}

static u64 r64(u64 cr3, u64 va)
{
    u64 v = 0;
    mm_read(cr3, va, &v, 8);
    return v;
}

/* Read as much as the target maps, stopping at the first hole. */
static u64 read_best(u64 cr3, u64 va, void* dst, u64 len)
{
    u8* out = (u8*)dst;
    u64 got = 0;

    while (got < len) {
        u64 pa = mm_translate(cr3, va + got);
        u64 chunk = HV_PAGE - ((va + got) & 0xFFFull);
        if (!pa)
            break;
        if (chunk > len - got)
            chunk = len - got;
        if (pa >= HV_HOST_COVER)
            break;
        if (chunk > HV_HOST_COVER - pa)
            chunk = HV_HOST_COVER - pa;
        mm_memcpy(out + got, (const void*)pa, chunk);
        got += chunk;
    }
    return got;
}

static int bytes_equal(const u8* a, const char* b, u32 n)
{
    u32 i;
    for (i = 0; i < n; ++i)
        if (a[i] != (u8)b[i])
            return 0;
    return 1;
}

static int mem_contains(const u8* hay, u64 hay_len, const char* needle, u32 needle_len)
{
    u64 i;
    if (hay_len < needle_len)
        return 0;
    for (i = 0; i + needle_len <= hay_len; ++i)
        if (bytes_equal(hay + i, needle, needle_len))
            return 1;
    return 0;
}

static u32 str_len(const char* s)
{
    u32 n = 0;
    while (s[n])
        ++n;
    return n;
}

static int pe_header_ok(u64 cr3, u64 base)
{
    u32 lfanew, sig;

    if (!base || (base & 0xFFF) || !canonical(base))
        return 0;
    if (r16(cr3, base) != 0x5A4D)            /* "MZ" */
        return 0;
    lfanew = r32(cr3, base + 0x3C);
    if (!lfanew || lfanew > 0x1000)
        return 0;
    sig = r32(cr3, base + lfanew);
    return sig == 0x00004550;                /* "PE\0\0" */
}

/* ------------------------------------------------------------------ exports */

static u64 pe_export(u64 cr3, u64 base, const char* name)
{
    u32 lfanew, magic, exp_rva, nnames, names_rva, ords_rva, funcs_rva;
    u64 opt, dir;
    u32 i, want = str_len(name);

    if (!pe_header_ok(cr3, base))
        return 0;

    lfanew = r32(cr3, base + 0x3C);
    opt = base + lfanew + 24;
    magic = r16(cr3, opt);
    if (magic != 0x20B)                      /* PE32+ only */
        return 0;

    exp_rva = r32(cr3, opt + 112);
    if (!exp_rva)
        return 0;

    dir = base + exp_rva;
    nnames    = r32(cr3, dir + 24);
    funcs_rva = r32(cr3, dir + 28);
    names_rva = r32(cr3, dir + 32);
    ords_rva  = r32(cr3, dir + 36);

    if (!nnames || nnames > 0x10000 || !names_rva || !ords_rva || !funcs_rva)
        return 0;

    for (i = 0; i < nnames; ++i) {
        u32 name_rva = r32(cr3, base + names_rva + (u64)i * 4);
        char buf[80];
        u32 nlen = 0;
        u64 got;

        if (!name_rva)
            continue;
        mm_memset(buf, 0, sizeof(buf));
        got = read_best(cr3, base + name_rva, buf, sizeof(buf) - 1);
        if (!got)
            continue;
        while (nlen < got && buf[nlen])
            ++nlen;
        /* Exact match, including length: a prefix comparison would let
         * "PsInitialSystemProcessX" match the real export. */
        if (nlen == want && bytes_equal((const u8*)buf, name, want)) {
            u16 ord = r16(cr3, base + ords_rva + (u64)i * 2);
            u32 fn = r32(cr3, base + funcs_rva + (u64)ord * 4);
            if (!fn)
                return 0;
            return base + fn;
        }
    }
    return 0;
}

/* --------------------------------------------------------------- kernel ctx */

int hv_capture_kernel_sample(u64 guest_cr3, u64 gs_base)
{
    u64 thread, eprocess, dtb;

    if (!guest_cr3 || !gs_base || !canonical(gs_base))
        return 0;

    thread = r64(guest_cr3, gs_base + 0x188);        /* KPCR.CurrentThread */
    if (!canonical(thread) || (thread & 7))
        return 0;

    eprocess = r64(guest_cr3, thread + 0xB8);        /* KTHREAD.Process */
    if (!canonical(eprocess) || (eprocess & 7))
        return 0;

    dtb = r64(guest_cr3, eprocess + 0x28);           /* KPROCESS.DirectoryTableBase */
    if ((dtb & 0xFFFull) || dtb < 0x100000)
        return 0;

    /* Do NOT require dtb == guest_cr3.  With KVA shadowing the value in
     * DirectoryTableBase is the user CR3 while the exit ran on the per-process
     * kernel CR3; requiring equality would discard every valid sample there.
     * The exit itself was CPL0, so guest_cr3 is a kernel CR3 by construction. */
    g_hv->kern_cr3 = guest_cr3;
    g_hv->kern_eprocess = eprocess;
    g_hv->kernel_samples++;
    return 1;
}

static int find_nt(u64 cr3)
{
    u64 idt = hv_vmread(VMCS_GUEST_IDTR_BASE);
    u64 handler, p, i;
    u8 e[16];

    if (!idt || !canonical(idt))
        return HV_ERR_NO_KERNEL;
    if (!mm_read(cr3, idt, e, 16))
        return HV_ERR_NO_KERNEL;

    handler = (u64)(*(u16*)(e + 0))
            | ((u64)(*(u16*)(e + 6)) << 16)
            | ((u64)(*(u32*)(e + 8)) << 32);
    if (!canonical(handler))
        return HV_ERR_NO_KERNEL;

    p = handler & ~0xFFFull;
    for (i = 0; i < IDT_SCAN_LIMIT && p > 0x10000; i += HV_PAGE, p -= HV_PAGE) {
        if (pe_header_ok(cr3, p)) {
            /* Many images sit between the handler and the kernel base; only
             * the one that exports PsInitialSystemProcess is ntoskrnl. */
            u64 sys = pe_export(cr3, p, "PsInitialSystemProcess");
            if (sys) {
                g_hv->nt_base = p;
                g_hv->nt_initial_system = sys;
                return HV_OK;
            }
        }
    }
    return HV_ERR_NO_KERNEL;
}

/* Derive the ActiveProcessLinks offset.  EPROCESS contains several LIST_ENTRY
 * fields, so self-consistency alone is not enough: for the real process list,
 * the node after System must belong to an EPROCESS whose DirectoryTableBase
 * maps the System list node back.  That also validates the derived offset. */
static int derive_offsets(u64 cr3)
{
    u64 sys = g_hv->system_eprocess;
    u64 x;

    if (!sys || !canonical(sys) || (sys & 7))
        return HV_ERR_NO_KERNEL;

    /* PsInitialSystemProcess must really point at the System EPROCESS. */
    {
        u64 got = read_best(cr3, sys, g_scratch, EPROCESS_SCAN);
        if (!mem_contains(g_scratch, got, "System", 6))
            return HV_ERR_NO_KERNEL;
    }

    for (x = 0x100; x < 0x900; x += 8) {
        u64 link = sys + x;
        u64 flink = r64(cr3, link);
        u64 blink = r64(cr3, link + 8);
        u64 ep, dtb;

        if (!canonical(flink) || !canonical(blink) || flink == link)
            continue;
        /* Both directions of the circle must agree. */
        if (r64(cr3, flink + 8) != link || r64(cr3, blink) != link)
            continue;

        ep = flink - x;
        if (!canonical(ep) || (ep & 7))
            continue;
        dtb = r64(cr3, ep + 0x28);
        if ((dtb & 0xFFFull) || dtb < 0x100000)
            continue;
        /* Every process's DTB maps the kernel, so the list node must
         * translate to the same Flink through it.  A wrong x yields a value
         * that is not a CR3 at all, and this check rejects it. */
        if (!mm_translate(dtb, link) || r64(dtb, link) != flink)
            continue;

        g_hv->eproc_links_off = x;
        g_hv->eproc_dtb_off = 0x28;
        return HV_OK;
    }
    return HV_ERR_NO_KERNEL;
}

/* Locate the PEB by looking for a plausible PEB pointer inside EPROCESS: a
 * page-aligned canonical pointer whose +0x10 is a PE image base with a sane
 * SizeOfImage.  Offset-free, so it survives Windows struct reshuffles.
 *
 * kern_cr3 reads the EPROCESS itself (kernel memory); dtb reads the PEB, which
 * lives in the target's user address space and is not mapped by the kernel
 * page tables. */
static u64 find_peb(u64 kern_cr3, u64 dtb, u64 eprocess)
{
    u64 got = read_best(kern_cr3, eprocess, g_scratch, EPROCESS_SCAN);
    u64 off;

    for (off = 0; off + 8 <= got; off += 8) {
        u64 peb = *(u64*)(g_scratch + off);
        u64 imgbase = 0;
        u32 lfanew, size;

        if (!canonical(peb) || (peb & 0xFFF) || peb < 0x10000)
            continue;
        if (!mm_read(dtb, peb + 0x10, &imgbase, 8))
            continue;
        if (!canonical(imgbase) || (imgbase & 0xFFF))
            continue;
        if (!pe_header_ok(dtb, imgbase))
            continue;
        lfanew = r32(dtb, imgbase + 0x3C);
        size = r32(dtb, imgbase + lfanew + 0x50);      /* SizeOfImage */
        if (size < 0x400000)                           /* < 4 MiB: not the game */
            continue;
        return peb;
    }
    return 0;
}

int hv_resolve_target(u32 pid, u64 fallback_cr3)
{
    u64 cr3 = g_hv->kern_cr3 ? g_hv->kern_cr3 : fallback_cr3;
    u64 head, link;
    int rc;
    int i;

    (void)pid;

    if (g_hv->target_state == HV_TARGET_READY)
        return HV_OK;

    g_hv->resolve_attempts++;

    if (!cr3) {
        g_hv->resolve_last_error = HV_ERR_PENDING;
        return HV_ERR_PENDING;
    }

    if (!g_hv->nt_base) {
        rc = find_nt(cr3);
        if (rc != HV_OK) {
            g_hv->resolve_last_error = (u64)rc;
            return rc;
        }
    }

    if (!g_hv->system_eprocess) {
        u64 var = g_hv->nt_initial_system;
        u64 sys;

        if (!var) {
            var = pe_export(cr3, g_hv->nt_base, "PsInitialSystemProcess");
            if (!var) {
                g_hv->resolve_last_error = HV_ERR_NO_KERNEL;
                return HV_ERR_NO_KERNEL;
            }
            g_hv->nt_initial_system = var;
        }
        sys = r64(cr3, var);
        if (!sys || !canonical(sys) || (sys & 7)) {
            g_hv->resolve_last_error = HV_ERR_NO_KERNEL;
            return HV_ERR_NO_KERNEL;
        }
        g_hv->system_eprocess = sys;
    }

    if (!g_hv->eproc_links_off) {
        rc = derive_offsets(cr3);
        if (rc != HV_OK) {
            g_hv->resolve_last_error = (u64)rc;
            return rc;
        }
    }

    head = g_hv->system_eprocess + g_hv->eproc_links_off;
    link = r64(cr3, head);
    if (!link || !canonical(link)) {
        g_hv->resolve_last_error = HV_ERR_NO_KERNEL;
        return HV_ERR_NO_KERNEL;
    }

    for (i = 0; i < MAX_PROCEDURES && link != head; ++i) {
        u64 ep = link - g_hv->eproc_links_off;

        if (canonical(ep)) {
            u64 got = read_best(cr3, ep, g_scratch, EPROCESS_SCAN);
            if (mem_contains(g_scratch, got, "FortniteClient", 14)) {
                u64 dtb = r64(cr3, ep + g_hv->eproc_dtb_off);
                if ((dtb & 0xFFFull) == 0 && dtb) {
                    u64 peb = find_peb(cr3, dtb, ep);
                    if (peb) {
                        u64 base = 0;
                        mm_read(dtb, peb + 0x10, &base, 8);
                        if (canonical(base) && pe_header_ok(dtb, base)) {
                            g_hv->target_cr3 = dtb;
                            g_hv->target_peb = peb;
                            g_hv->target_base = base;
                            g_hv->target_pid = 0;
                            g_hv->target_state = HV_TARGET_READY;
                            g_hv->resolve_last_error = 0;
                            return HV_OK;
                        }
                    }
                }
            }
        }
        link = r64(cr3, link);
        if (!link || !canonical(link))
            break;
    }

    g_hv->resolve_last_error = HV_ERR_NO_TARGET;
    return HV_ERR_NO_TARGET;
}
